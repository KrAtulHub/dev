var pc = (e) => {
  throw TypeError(e);
};
var ol = (e, t, n) => t.has(e) || pc("Cannot " + n);
var N = (e, t, n) => (
    ol(e, t, "read from private field"), n ? n.call(e) : t.get(e)
  ),
  q = (e, t, n) =>
    t.has(e)
      ? pc("Cannot add the same private member more than once")
      : t instanceof WeakSet
      ? t.add(e)
      : t.set(e, n),
  V = (e, t, n, r) => (
    ol(e, t, "write to private field"), r ? r.call(e, n) : t.set(e, n), n
  ),
  Ne = (e, t, n) => (ol(e, t, "access private method"), n);
var ci = (e, t, n, r) => ({
  set _(o) {
    V(e, t, o, n);
  },
  get _() {
    return N(e, t, r);
  },
});
function Rg(e, t) {
  for (var n = 0; n < t.length; n++) {
    const r = t[n];
    if (typeof r != "string" && !Array.isArray(r)) {
      for (const o in r)
        if (o !== "default" && !(o in e)) {
          const i = Object.getOwnPropertyDescriptor(r, o);
          i &&
            Object.defineProperty(
              e,
              o,
              i.get ? i : { enumerable: !0, get: () => r[o] }
            );
        }
    }
  }
  return Object.freeze(
    Object.defineProperty(e, Symbol.toStringTag, { value: "Module" })
  );
}
(function () {
  const t = document.createElement("link").relList;
  if (t && t.supports && t.supports("modulepreload")) return;
  for (const o of document.querySelectorAll('link[rel="modulepreload"]')) r(o);
  new MutationObserver((o) => {
    for (const i of o)
      if (i.type === "childList")
        for (const s of i.addedNodes)
          s.tagName === "LINK" && s.rel === "modulepreload" && r(s);
  }).observe(document, { childList: !0, subtree: !0 });
  function n(o) {
    const i = {};
    return (
      o.integrity && (i.integrity = o.integrity),
      o.referrerPolicy && (i.referrerPolicy = o.referrerPolicy),
      o.crossOrigin === "use-credentials"
        ? (i.credentials = "include")
        : o.crossOrigin === "anonymous"
        ? (i.credentials = "omit")
        : (i.credentials = "same-origin"),
      i
    );
  }
  function r(o) {
    if (o.ep) return;
    o.ep = !0;
    const i = n(o);
    fetch(o.href, i);
  }
})();
function hf(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default")
    ? e.default
    : e;
}
var mf = { exports: {} },
  Ns = {},
  gf = { exports: {} },
  G = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var qo = Symbol.for("react.element"),
  Ag = Symbol.for("react.portal"),
  jg = Symbol.for("react.fragment"),
  _g = Symbol.for("react.strict_mode"),
  Og = Symbol.for("react.profiler"),
  Mg = Symbol.for("react.provider"),
  Lg = Symbol.for("react.context"),
  Ig = Symbol.for("react.forward_ref"),
  Dg = Symbol.for("react.suspense"),
  zg = Symbol.for("react.memo"),
  Fg = Symbol.for("react.lazy"),
  hc = Symbol.iterator;
function $g(e) {
  return e === null || typeof e != "object"
    ? null
    : ((e = (hc && e[hc]) || e["@@iterator"]),
      typeof e == "function" ? e : null);
}
var vf = {
    isMounted: function () {
      return !1;
    },
    enqueueForceUpdate: function () {},
    enqueueReplaceState: function () {},
    enqueueSetState: function () {},
  },
  yf = Object.assign,
  xf = {};
function Kr(e, t, n) {
  (this.props = e),
    (this.context = t),
    (this.refs = xf),
    (this.updater = n || vf);
}
Kr.prototype.isReactComponent = {};
Kr.prototype.setState = function (e, t) {
  if (typeof e != "object" && typeof e != "function" && e != null)
    throw Error(
      "setState(...): takes an object of state variables to update or a function which returns an object of state variables."
    );
  this.updater.enqueueSetState(this, e, t, "setState");
};
Kr.prototype.forceUpdate = function (e) {
  this.updater.enqueueForceUpdate(this, e, "forceUpdate");
};
function wf() {}
wf.prototype = Kr.prototype;
function Ga(e, t, n) {
  (this.props = e),
    (this.context = t),
    (this.refs = xf),
    (this.updater = n || vf);
}
var Ya = (Ga.prototype = new wf());
Ya.constructor = Ga;
yf(Ya, Kr.prototype);
Ya.isPureReactComponent = !0;
var mc = Array.isArray,
  Sf = Object.prototype.hasOwnProperty,
  Xa = { current: null },
  kf = { key: !0, ref: !0, __self: !0, __source: !0 };
function Ef(e, t, n) {
  var r,
    o = {},
    i = null,
    s = null;
  if (t != null)
    for (r in (t.ref !== void 0 && (s = t.ref),
    t.key !== void 0 && (i = "" + t.key),
    t))
      Sf.call(t, r) && !kf.hasOwnProperty(r) && (o[r] = t[r]);
  var l = arguments.length - 2;
  if (l === 1) o.children = n;
  else if (1 < l) {
    for (var a = Array(l), u = 0; u < l; u++) a[u] = arguments[u + 2];
    o.children = a;
  }
  if (e && e.defaultProps)
    for (r in ((l = e.defaultProps), l)) o[r] === void 0 && (o[r] = l[r]);
  return {
    $$typeof: qo,
    type: e,
    key: i,
    ref: s,
    props: o,
    _owner: Xa.current,
  };
}
function Ug(e, t) {
  return {
    $$typeof: qo,
    type: e.type,
    key: t,
    ref: e.ref,
    props: e.props,
    _owner: e._owner,
  };
}
function qa(e) {
  return typeof e == "object" && e !== null && e.$$typeof === qo;
}
function Bg(e) {
  var t = { "=": "=0", ":": "=2" };
  return (
    "$" +
    e.replace(/[=:]/g, function (n) {
      return t[n];
    })
  );
}
var gc = /\/+/g;
function il(e, t) {
  return typeof e == "object" && e !== null && e.key != null
    ? Bg("" + e.key)
    : t.toString(36);
}
function Oi(e, t, n, r, o) {
  var i = typeof e;
  (i === "undefined" || i === "boolean") && (e = null);
  var s = !1;
  if (e === null) s = !0;
  else
    switch (i) {
      case "string":
      case "number":
        s = !0;
        break;
      case "object":
        switch (e.$$typeof) {
          case qo:
          case Ag:
            s = !0;
        }
    }
  if (s)
    return (
      (s = e),
      (o = o(s)),
      (e = r === "" ? "." + il(s, 0) : r),
      mc(o)
        ? ((n = ""),
          e != null && (n = e.replace(gc, "$&/") + "/"),
          Oi(o, t, n, "", function (u) {
            return u;
          }))
        : o != null &&
          (qa(o) &&
            (o = Ug(
              o,
              n +
                (!o.key || (s && s.key === o.key)
                  ? ""
                  : ("" + o.key).replace(gc, "$&/") + "/") +
                e
            )),
          t.push(o)),
      1
    );
  if (((s = 0), (r = r === "" ? "." : r + ":"), mc(e)))
    for (var l = 0; l < e.length; l++) {
      i = e[l];
      var a = r + il(i, l);
      s += Oi(i, t, n, a, o);
    }
  else if (((a = $g(e)), typeof a == "function"))
    for (e = a.call(e), l = 0; !(i = e.next()).done; )
      (i = i.value), (a = r + il(i, l++)), (s += Oi(i, t, n, a, o));
  else if (i === "object")
    throw (
      ((t = String(e)),
      Error(
        "Objects are not valid as a React child (found: " +
          (t === "[object Object]"
            ? "object with keys {" + Object.keys(e).join(", ") + "}"
            : t) +
          "). If you meant to render a collection of children, use an array instead."
      ))
    );
  return s;
}
function di(e, t, n) {
  if (e == null) return e;
  var r = [],
    o = 0;
  return (
    Oi(e, r, "", "", function (i) {
      return t.call(n, i, o++);
    }),
    r
  );
}
function Wg(e) {
  if (e._status === -1) {
    var t = e._result;
    (t = t()),
      t.then(
        function (n) {
          (e._status === 0 || e._status === -1) &&
            ((e._status = 1), (e._result = n));
        },
        function (n) {
          (e._status === 0 || e._status === -1) &&
            ((e._status = 2), (e._result = n));
        }
      ),
      e._status === -1 && ((e._status = 0), (e._result = t));
  }
  if (e._status === 1) return e._result.default;
  throw e._result;
}
var De = { current: null },
  Mi = { transition: null },
  Vg = {
    ReactCurrentDispatcher: De,
    ReactCurrentBatchConfig: Mi,
    ReactCurrentOwner: Xa,
  };
function Cf() {
  throw Error("act(...) is not supported in production builds of React.");
}
G.Children = {
  map: di,
  forEach: function (e, t, n) {
    di(
      e,
      function () {
        t.apply(this, arguments);
      },
      n
    );
  },
  count: function (e) {
    var t = 0;
    return (
      di(e, function () {
        t++;
      }),
      t
    );
  },
  toArray: function (e) {
    return (
      di(e, function (t) {
        return t;
      }) || []
    );
  },
  only: function (e) {
    if (!qa(e))
      throw Error(
        "React.Children.only expected to receive a single React element child."
      );
    return e;
  },
};
G.Component = Kr;
G.Fragment = jg;
G.Profiler = Og;
G.PureComponent = Ga;
G.StrictMode = _g;
G.Suspense = Dg;
G.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Vg;
G.act = Cf;
G.cloneElement = function (e, t, n) {
  if (e == null)
    throw Error(
      "React.cloneElement(...): The argument must be a React element, but you passed " +
        e +
        "."
    );
  var r = yf({}, e.props),
    o = e.key,
    i = e.ref,
    s = e._owner;
  if (t != null) {
    if (
      (t.ref !== void 0 && ((i = t.ref), (s = Xa.current)),
      t.key !== void 0 && (o = "" + t.key),
      e.type && e.type.defaultProps)
    )
      var l = e.type.defaultProps;
    for (a in t)
      Sf.call(t, a) &&
        !kf.hasOwnProperty(a) &&
        (r[a] = t[a] === void 0 && l !== void 0 ? l[a] : t[a]);
  }
  var a = arguments.length - 2;
  if (a === 1) r.children = n;
  else if (1 < a) {
    l = Array(a);
    for (var u = 0; u < a; u++) l[u] = arguments[u + 2];
    r.children = l;
  }
  return { $$typeof: qo, type: e.type, key: o, ref: i, props: r, _owner: s };
};
G.createContext = function (e) {
  return (
    (e = {
      $$typeof: Lg,
      _currentValue: e,
      _currentValue2: e,
      _threadCount: 0,
      Provider: null,
      Consumer: null,
      _defaultValue: null,
      _globalName: null,
    }),
    (e.Provider = { $$typeof: Mg, _context: e }),
    (e.Consumer = e)
  );
};
G.createElement = Ef;
G.createFactory = function (e) {
  var t = Ef.bind(null, e);
  return (t.type = e), t;
};
G.createRef = function () {
  return { current: null };
};
G.forwardRef = function (e) {
  return { $$typeof: Ig, render: e };
};
G.isValidElement = qa;
G.lazy = function (e) {
  return { $$typeof: Fg, _payload: { _status: -1, _result: e }, _init: Wg };
};
G.memo = function (e, t) {
  return { $$typeof: zg, type: e, compare: t === void 0 ? null : t };
};
G.startTransition = function (e) {
  var t = Mi.transition;
  Mi.transition = {};
  try {
    e();
  } finally {
    Mi.transition = t;
  }
};
G.unstable_act = Cf;
G.useCallback = function (e, t) {
  return De.current.useCallback(e, t);
};
G.useContext = function (e) {
  return De.current.useContext(e);
};
G.useDebugValue = function () {};
G.useDeferredValue = function (e) {
  return De.current.useDeferredValue(e);
};
G.useEffect = function (e, t) {
  return De.current.useEffect(e, t);
};
G.useId = function () {
  return De.current.useId();
};
G.useImperativeHandle = function (e, t, n) {
  return De.current.useImperativeHandle(e, t, n);
};
G.useInsertionEffect = function (e, t) {
  return De.current.useInsertionEffect(e, t);
};
G.useLayoutEffect = function (e, t) {
  return De.current.useLayoutEffect(e, t);
};
G.useMemo = function (e, t) {
  return De.current.useMemo(e, t);
};
G.useReducer = function (e, t, n) {
  return De.current.useReducer(e, t, n);
};
G.useRef = function (e) {
  return De.current.useRef(e);
};
G.useState = function (e) {
  return De.current.useState(e);
};
G.useSyncExternalStore = function (e, t, n) {
  return De.current.useSyncExternalStore(e, t, n);
};
G.useTransition = function () {
  return De.current.useTransition();
};
G.version = "18.3.1";
gf.exports = G;
var y = gf.exports;
const j = hf(y),
  Hg = Rg({ __proto__: null, default: j }, [y]);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Qg = y,
  Kg = Symbol.for("react.element"),
  Gg = Symbol.for("react.fragment"),
  Yg = Object.prototype.hasOwnProperty,
  Xg = Qg.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
  qg = { key: !0, ref: !0, __self: !0, __source: !0 };
function bf(e, t, n) {
  var r,
    o = {},
    i = null,
    s = null;
  n !== void 0 && (i = "" + n),
    t.key !== void 0 && (i = "" + t.key),
    t.ref !== void 0 && (s = t.ref);
  for (r in t) Yg.call(t, r) && !qg.hasOwnProperty(r) && (o[r] = t[r]);
  if (e && e.defaultProps)
    for (r in ((t = e.defaultProps), t)) o[r] === void 0 && (o[r] = t[r]);
  return {
    $$typeof: Kg,
    type: e,
    key: i,
    ref: s,
    props: o,
    _owner: Xg.current,
  };
}
Ns.Fragment = Gg;
Ns.jsx = bf;
Ns.jsxs = bf;
mf.exports = Ns;
var w = mf.exports,
  Pf = { exports: {} },
  Ze = {},
  Nf = { exports: {} },
  Tf = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ (function (e) {
  function t(C, A) {
    var z = C.length;
    C.push(A);
    e: for (; 0 < z; ) {
      var L = (z - 1) >>> 1,
        F = C[L];
      if (0 < o(F, A)) (C[L] = A), (C[z] = F), (z = L);
      else break e;
    }
  }
  function n(C) {
    return C.length === 0 ? null : C[0];
  }
  function r(C) {
    if (C.length === 0) return null;
    var A = C[0],
      z = C.pop();
    if (z !== A) {
      C[0] = z;
      e: for (var L = 0, F = C.length, Y = F >>> 1; L < Y; ) {
        var le = 2 * (L + 1) - 1,
          Ve = C[le],
          J = le + 1,
          at = C[J];
        if (0 > o(Ve, z))
          J < F && 0 > o(at, Ve)
            ? ((C[L] = at), (C[J] = z), (L = J))
            : ((C[L] = Ve), (C[le] = z), (L = le));
        else if (J < F && 0 > o(at, z)) (C[L] = at), (C[J] = z), (L = J);
        else break e;
      }
    }
    return A;
  }
  function o(C, A) {
    var z = C.sortIndex - A.sortIndex;
    return z !== 0 ? z : C.id - A.id;
  }
  if (typeof performance == "object" && typeof performance.now == "function") {
    var i = performance;
    e.unstable_now = function () {
      return i.now();
    };
  } else {
    var s = Date,
      l = s.now();
    e.unstable_now = function () {
      return s.now() - l;
    };
  }
  var a = [],
    u = [],
    d = 1,
    f = null,
    c = 3,
    v = !1,
    x = !1,
    g = !1,
    S = typeof setTimeout == "function" ? setTimeout : null,
    h = typeof clearTimeout == "function" ? clearTimeout : null,
    p = typeof setImmediate < "u" ? setImmediate : null;
  typeof navigator < "u" &&
    navigator.scheduling !== void 0 &&
    navigator.scheduling.isInputPending !== void 0 &&
    navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function m(C) {
    for (var A = n(u); A !== null; ) {
      if (A.callback === null) r(u);
      else if (A.startTime <= C)
        r(u), (A.sortIndex = A.expirationTime), t(a, A);
      else break;
      A = n(u);
    }
  }
  function k(C) {
    if (((g = !1), m(C), !x))
      if (n(a) !== null) (x = !0), U(E);
      else {
        var A = n(u);
        A !== null && K(k, A.startTime - C);
      }
  }
  function E(C, A) {
    (x = !1), g && ((g = !1), h(T), (T = -1)), (v = !0);
    var z = c;
    try {
      for (
        m(A), f = n(a);
        f !== null && (!(f.expirationTime > A) || (C && !$()));

      ) {
        var L = f.callback;
        if (typeof L == "function") {
          (f.callback = null), (c = f.priorityLevel);
          var F = L(f.expirationTime <= A);
          (A = e.unstable_now()),
            typeof F == "function" ? (f.callback = F) : f === n(a) && r(a),
            m(A);
        } else r(a);
        f = n(a);
      }
      if (f !== null) var Y = !0;
      else {
        var le = n(u);
        le !== null && K(k, le.startTime - A), (Y = !1);
      }
      return Y;
    } finally {
      (f = null), (c = z), (v = !1);
    }
  }
  var b = !1,
    P = null,
    T = -1,
    I = 5,
    _ = -1;
  function $() {
    return !(e.unstable_now() - _ < I);
  }
  function D() {
    if (P !== null) {
      var C = e.unstable_now();
      _ = C;
      var A = !0;
      try {
        A = P(!0, C);
      } finally {
        A ? H() : ((b = !1), (P = null));
      }
    } else b = !1;
  }
  var H;
  if (typeof p == "function")
    H = function () {
      p(D);
    };
  else if (typeof MessageChannel < "u") {
    var O = new MessageChannel(),
      Q = O.port2;
    (O.port1.onmessage = D),
      (H = function () {
        Q.postMessage(null);
      });
  } else
    H = function () {
      S(D, 0);
    };
  function U(C) {
    (P = C), b || ((b = !0), H());
  }
  function K(C, A) {
    T = S(function () {
      C(e.unstable_now());
    }, A);
  }
  (e.unstable_IdlePriority = 5),
    (e.unstable_ImmediatePriority = 1),
    (e.unstable_LowPriority = 4),
    (e.unstable_NormalPriority = 3),
    (e.unstable_Profiling = null),
    (e.unstable_UserBlockingPriority = 2),
    (e.unstable_cancelCallback = function (C) {
      C.callback = null;
    }),
    (e.unstable_continueExecution = function () {
      x || v || ((x = !0), U(E));
    }),
    (e.unstable_forceFrameRate = function (C) {
      0 > C || 125 < C
        ? console.error(
            "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"
          )
        : (I = 0 < C ? Math.floor(1e3 / C) : 5);
    }),
    (e.unstable_getCurrentPriorityLevel = function () {
      return c;
    }),
    (e.unstable_getFirstCallbackNode = function () {
      return n(a);
    }),
    (e.unstable_next = function (C) {
      switch (c) {
        case 1:
        case 2:
        case 3:
          var A = 3;
          break;
        default:
          A = c;
      }
      var z = c;
      c = A;
      try {
        return C();
      } finally {
        c = z;
      }
    }),
    (e.unstable_pauseExecution = function () {}),
    (e.unstable_requestPaint = function () {}),
    (e.unstable_runWithPriority = function (C, A) {
      switch (C) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          C = 3;
      }
      var z = c;
      c = C;
      try {
        return A();
      } finally {
        c = z;
      }
    }),
    (e.unstable_scheduleCallback = function (C, A, z) {
      var L = e.unstable_now();
      switch (
        (typeof z == "object" && z !== null
          ? ((z = z.delay), (z = typeof z == "number" && 0 < z ? L + z : L))
          : (z = L),
        C)
      ) {
        case 1:
          var F = -1;
          break;
        case 2:
          F = 250;
          break;
        case 5:
          F = 1073741823;
          break;
        case 4:
          F = 1e4;
          break;
        default:
          F = 5e3;
      }
      return (
        (F = z + F),
        (C = {
          id: d++,
          callback: A,
          priorityLevel: C,
          startTime: z,
          expirationTime: F,
          sortIndex: -1,
        }),
        z > L
          ? ((C.sortIndex = z),
            t(u, C),
            n(a) === null &&
              C === n(u) &&
              (g ? (h(T), (T = -1)) : (g = !0), K(k, z - L)))
          : ((C.sortIndex = F), t(a, C), x || v || ((x = !0), U(E))),
        C
      );
    }),
    (e.unstable_shouldYield = $),
    (e.unstable_wrapCallback = function (C) {
      var A = c;
      return function () {
        var z = c;
        c = A;
        try {
          return C.apply(this, arguments);
        } finally {
          c = z;
        }
      };
    });
})(Tf);
Nf.exports = Tf;
var Jg = Nf.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Zg = y,
  Je = Jg;
function R(e) {
  for (
    var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1;
    n < arguments.length;
    n++
  )
    t += "&args[]=" + encodeURIComponent(arguments[n]);
  return (
    "Minified React error #" +
    e +
    "; visit " +
    t +
    " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
  );
}
var Rf = new Set(),
  Po = {};
function er(e, t) {
  zr(e, t), zr(e + "Capture", t);
}
function zr(e, t) {
  for (Po[e] = t, e = 0; e < t.length; e++) Rf.add(t[e]);
}
var Bt = !(
    typeof window > "u" ||
    typeof window.document > "u" ||
    typeof window.document.createElement > "u"
  ),
  $l = Object.prototype.hasOwnProperty,
  e0 =
    /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
  vc = {},
  yc = {};
function t0(e) {
  return $l.call(yc, e)
    ? !0
    : $l.call(vc, e)
    ? !1
    : e0.test(e)
    ? (yc[e] = !0)
    : ((vc[e] = !0), !1);
}
function n0(e, t, n, r) {
  if (n !== null && n.type === 0) return !1;
  switch (typeof t) {
    case "function":
    case "symbol":
      return !0;
    case "boolean":
      return r
        ? !1
        : n !== null
        ? !n.acceptsBooleans
        : ((e = e.toLowerCase().slice(0, 5)), e !== "data-" && e !== "aria-");
    default:
      return !1;
  }
}
function r0(e, t, n, r) {
  if (t === null || typeof t > "u" || n0(e, t, n, r)) return !0;
  if (r) return !1;
  if (n !== null)
    switch (n.type) {
      case 3:
        return !t;
      case 4:
        return t === !1;
      case 5:
        return isNaN(t);
      case 6:
        return isNaN(t) || 1 > t;
    }
  return !1;
}
function ze(e, t, n, r, o, i, s) {
  (this.acceptsBooleans = t === 2 || t === 3 || t === 4),
    (this.attributeName = r),
    (this.attributeNamespace = o),
    (this.mustUseProperty = n),
    (this.propertyName = e),
    (this.type = t),
    (this.sanitizeURL = i),
    (this.removeEmptyString = s);
}
var Ce = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
  .split(" ")
  .forEach(function (e) {
    Ce[e] = new ze(e, 0, !1, e, null, !1, !1);
  });
[
  ["acceptCharset", "accept-charset"],
  ["className", "class"],
  ["htmlFor", "for"],
  ["httpEquiv", "http-equiv"],
].forEach(function (e) {
  var t = e[0];
  Ce[t] = new ze(t, 1, !1, e[1], null, !1, !1);
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function (e) {
  Ce[e] = new ze(e, 2, !1, e.toLowerCase(), null, !1, !1);
});
[
  "autoReverse",
  "externalResourcesRequired",
  "focusable",
  "preserveAlpha",
].forEach(function (e) {
  Ce[e] = new ze(e, 2, !1, e, null, !1, !1);
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
  .split(" ")
  .forEach(function (e) {
    Ce[e] = new ze(e, 3, !1, e.toLowerCase(), null, !1, !1);
  });
["checked", "multiple", "muted", "selected"].forEach(function (e) {
  Ce[e] = new ze(e, 3, !0, e, null, !1, !1);
});
["capture", "download"].forEach(function (e) {
  Ce[e] = new ze(e, 4, !1, e, null, !1, !1);
});
["cols", "rows", "size", "span"].forEach(function (e) {
  Ce[e] = new ze(e, 6, !1, e, null, !1, !1);
});
["rowSpan", "start"].forEach(function (e) {
  Ce[e] = new ze(e, 5, !1, e.toLowerCase(), null, !1, !1);
});
var Ja = /[\-:]([a-z])/g;
function Za(e) {
  return e[1].toUpperCase();
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
  .split(" ")
  .forEach(function (e) {
    var t = e.replace(Ja, Za);
    Ce[t] = new ze(t, 1, !1, e, null, !1, !1);
  });
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
  .split(" ")
  .forEach(function (e) {
    var t = e.replace(Ja, Za);
    Ce[t] = new ze(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
  });
["xml:base", "xml:lang", "xml:space"].forEach(function (e) {
  var t = e.replace(Ja, Za);
  Ce[t] = new ze(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
});
["tabIndex", "crossOrigin"].forEach(function (e) {
  Ce[e] = new ze(e, 1, !1, e.toLowerCase(), null, !1, !1);
});
Ce.xlinkHref = new ze(
  "xlinkHref",
  1,
  !1,
  "xlink:href",
  "http://www.w3.org/1999/xlink",
  !0,
  !1
);
["src", "href", "action", "formAction"].forEach(function (e) {
  Ce[e] = new ze(e, 1, !1, e.toLowerCase(), null, !0, !0);
});
function eu(e, t, n, r) {
  var o = Ce.hasOwnProperty(t) ? Ce[t] : null;
  (o !== null
    ? o.type !== 0
    : r ||
      !(2 < t.length) ||
      (t[0] !== "o" && t[0] !== "O") ||
      (t[1] !== "n" && t[1] !== "N")) &&
    (r0(t, n, o, r) && (n = null),
    r || o === null
      ? t0(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n))
      : o.mustUseProperty
      ? (e[o.propertyName] = n === null ? (o.type === 3 ? !1 : "") : n)
      : ((t = o.attributeName),
        (r = o.attributeNamespace),
        n === null
          ? e.removeAttribute(t)
          : ((o = o.type),
            (n = o === 3 || (o === 4 && n === !0) ? "" : "" + n),
            r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
}
var Yt = Zg.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
  fi = Symbol.for("react.element"),
  ur = Symbol.for("react.portal"),
  cr = Symbol.for("react.fragment"),
  tu = Symbol.for("react.strict_mode"),
  Ul = Symbol.for("react.profiler"),
  Af = Symbol.for("react.provider"),
  jf = Symbol.for("react.context"),
  nu = Symbol.for("react.forward_ref"),
  Bl = Symbol.for("react.suspense"),
  Wl = Symbol.for("react.suspense_list"),
  ru = Symbol.for("react.memo"),
  sn = Symbol.for("react.lazy"),
  _f = Symbol.for("react.offscreen"),
  xc = Symbol.iterator;
function to(e) {
  return e === null || typeof e != "object"
    ? null
    : ((e = (xc && e[xc]) || e["@@iterator"]),
      typeof e == "function" ? e : null);
}
var ce = Object.assign,
  sl;
function fo(e) {
  if (sl === void 0)
    try {
      throw Error();
    } catch (n) {
      var t = n.stack.trim().match(/\n( *(at )?)/);
      sl = (t && t[1]) || "";
    }
  return (
    `
` +
    sl +
    e
  );
}
var ll = !1;
function al(e, t) {
  if (!e || ll) return "";
  ll = !0;
  var n = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (t)
      if (
        ((t = function () {
          throw Error();
        }),
        Object.defineProperty(t.prototype, "props", {
          set: function () {
            throw Error();
          },
        }),
        typeof Reflect == "object" && Reflect.construct)
      ) {
        try {
          Reflect.construct(t, []);
        } catch (u) {
          var r = u;
        }
        Reflect.construct(e, [], t);
      } else {
        try {
          t.call();
        } catch (u) {
          r = u;
        }
        e.call(t.prototype);
      }
    else {
      try {
        throw Error();
      } catch (u) {
        r = u;
      }
      e();
    }
  } catch (u) {
    if (u && r && typeof u.stack == "string") {
      for (
        var o = u.stack.split(`
`),
          i = r.stack.split(`
`),
          s = o.length - 1,
          l = i.length - 1;
        1 <= s && 0 <= l && o[s] !== i[l];

      )
        l--;
      for (; 1 <= s && 0 <= l; s--, l--)
        if (o[s] !== i[l]) {
          if (s !== 1 || l !== 1)
            do
              if ((s--, l--, 0 > l || o[s] !== i[l])) {
                var a =
                  `
` + o[s].replace(" at new ", " at ");
                return (
                  e.displayName &&
                    a.includes("<anonymous>") &&
                    (a = a.replace("<anonymous>", e.displayName)),
                  a
                );
              }
            while (1 <= s && 0 <= l);
          break;
        }
    }
  } finally {
    (ll = !1), (Error.prepareStackTrace = n);
  }
  return (e = e ? e.displayName || e.name : "") ? fo(e) : "";
}
function o0(e) {
  switch (e.tag) {
    case 5:
      return fo(e.type);
    case 16:
      return fo("Lazy");
    case 13:
      return fo("Suspense");
    case 19:
      return fo("SuspenseList");
    case 0:
    case 2:
    case 15:
      return (e = al(e.type, !1)), e;
    case 11:
      return (e = al(e.type.render, !1)), e;
    case 1:
      return (e = al(e.type, !0)), e;
    default:
      return "";
  }
}
function Vl(e) {
  if (e == null) return null;
  if (typeof e == "function") return e.displayName || e.name || null;
  if (typeof e == "string") return e;
  switch (e) {
    case cr:
      return "Fragment";
    case ur:
      return "Portal";
    case Ul:
      return "Profiler";
    case tu:
      return "StrictMode";
    case Bl:
      return "Suspense";
    case Wl:
      return "SuspenseList";
  }
  if (typeof e == "object")
    switch (e.$$typeof) {
      case jf:
        return (e.displayName || "Context") + ".Consumer";
      case Af:
        return (e._context.displayName || "Context") + ".Provider";
      case nu:
        var t = e.render;
        return (
          (e = e.displayName),
          e ||
            ((e = t.displayName || t.name || ""),
            (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
          e
        );
      case ru:
        return (
          (t = e.displayName || null), t !== null ? t : Vl(e.type) || "Memo"
        );
      case sn:
        (t = e._payload), (e = e._init);
        try {
          return Vl(e(t));
        } catch {}
    }
  return null;
}
function i0(e) {
  var t = e.type;
  switch (e.tag) {
    case 24:
      return "Cache";
    case 9:
      return (t.displayName || "Context") + ".Consumer";
    case 10:
      return (t._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return (
        (e = t.render),
        (e = e.displayName || e.name || ""),
        t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")
      );
    case 7:
      return "Fragment";
    case 5:
      return t;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return Vl(t);
    case 8:
      return t === tu ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if (typeof t == "function") return t.displayName || t.name || null;
      if (typeof t == "string") return t;
  }
  return null;
}
function Nn(e) {
  switch (typeof e) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return e;
    case "object":
      return e;
    default:
      return "";
  }
}
function Of(e) {
  var t = e.type;
  return (
    (e = e.nodeName) &&
    e.toLowerCase() === "input" &&
    (t === "checkbox" || t === "radio")
  );
}
function s0(e) {
  var t = Of(e) ? "checked" : "value",
    n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
    r = "" + e[t];
  if (
    !e.hasOwnProperty(t) &&
    typeof n < "u" &&
    typeof n.get == "function" &&
    typeof n.set == "function"
  ) {
    var o = n.get,
      i = n.set;
    return (
      Object.defineProperty(e, t, {
        configurable: !0,
        get: function () {
          return o.call(this);
        },
        set: function (s) {
          (r = "" + s), i.call(this, s);
        },
      }),
      Object.defineProperty(e, t, { enumerable: n.enumerable }),
      {
        getValue: function () {
          return r;
        },
        setValue: function (s) {
          r = "" + s;
        },
        stopTracking: function () {
          (e._valueTracker = null), delete e[t];
        },
      }
    );
  }
}
function pi(e) {
  e._valueTracker || (e._valueTracker = s0(e));
}
function Mf(e) {
  if (!e) return !1;
  var t = e._valueTracker;
  if (!t) return !0;
  var n = t.getValue(),
    r = "";
  return (
    e && (r = Of(e) ? (e.checked ? "true" : "false") : e.value),
    (e = r),
    e !== n ? (t.setValue(e), !0) : !1
  );
}
function Yi(e) {
  if (((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u"))
    return null;
  try {
    return e.activeElement || e.body;
  } catch {
    return e.body;
  }
}
function Hl(e, t) {
  var n = t.checked;
  return ce({}, t, {
    defaultChecked: void 0,
    defaultValue: void 0,
    value: void 0,
    checked: n ?? e._wrapperState.initialChecked,
  });
}
function wc(e, t) {
  var n = t.defaultValue == null ? "" : t.defaultValue,
    r = t.checked != null ? t.checked : t.defaultChecked;
  (n = Nn(t.value != null ? t.value : n)),
    (e._wrapperState = {
      initialChecked: r,
      initialValue: n,
      controlled:
        t.type === "checkbox" || t.type === "radio"
          ? t.checked != null
          : t.value != null,
    });
}
function Lf(e, t) {
  (t = t.checked), t != null && eu(e, "checked", t, !1);
}
function Ql(e, t) {
  Lf(e, t);
  var n = Nn(t.value),
    r = t.type;
  if (n != null)
    r === "number"
      ? ((n === 0 && e.value === "") || e.value != n) && (e.value = "" + n)
      : e.value !== "" + n && (e.value = "" + n);
  else if (r === "submit" || r === "reset") {
    e.removeAttribute("value");
    return;
  }
  t.hasOwnProperty("value")
    ? Kl(e, t.type, n)
    : t.hasOwnProperty("defaultValue") && Kl(e, t.type, Nn(t.defaultValue)),
    t.checked == null &&
      t.defaultChecked != null &&
      (e.defaultChecked = !!t.defaultChecked);
}
function Sc(e, t, n) {
  if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
    var r = t.type;
    if (
      !(
        (r !== "submit" && r !== "reset") ||
        (t.value !== void 0 && t.value !== null)
      )
    )
      return;
    (t = "" + e._wrapperState.initialValue),
      n || t === e.value || (e.value = t),
      (e.defaultValue = t);
  }
  (n = e.name),
    n !== "" && (e.name = ""),
    (e.defaultChecked = !!e._wrapperState.initialChecked),
    n !== "" && (e.name = n);
}
function Kl(e, t, n) {
  (t !== "number" || Yi(e.ownerDocument) !== e) &&
    (n == null
      ? (e.defaultValue = "" + e._wrapperState.initialValue)
      : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
}
var po = Array.isArray;
function Sr(e, t, n, r) {
  if (((e = e.options), t)) {
    t = {};
    for (var o = 0; o < n.length; o++) t["$" + n[o]] = !0;
    for (n = 0; n < e.length; n++)
      (o = t.hasOwnProperty("$" + e[n].value)),
        e[n].selected !== o && (e[n].selected = o),
        o && r && (e[n].defaultSelected = !0);
  } else {
    for (n = "" + Nn(n), t = null, o = 0; o < e.length; o++) {
      if (e[o].value === n) {
        (e[o].selected = !0), r && (e[o].defaultSelected = !0);
        return;
      }
      t !== null || e[o].disabled || (t = e[o]);
    }
    t !== null && (t.selected = !0);
  }
}
function Gl(e, t) {
  if (t.dangerouslySetInnerHTML != null) throw Error(R(91));
  return ce({}, t, {
    value: void 0,
    defaultValue: void 0,
    children: "" + e._wrapperState.initialValue,
  });
}
function kc(e, t) {
  var n = t.value;
  if (n == null) {
    if (((n = t.children), (t = t.defaultValue), n != null)) {
      if (t != null) throw Error(R(92));
      if (po(n)) {
        if (1 < n.length) throw Error(R(93));
        n = n[0];
      }
      t = n;
    }
    t == null && (t = ""), (n = t);
  }
  e._wrapperState = { initialValue: Nn(n) };
}
function If(e, t) {
  var n = Nn(t.value),
    r = Nn(t.defaultValue);
  n != null &&
    ((n = "" + n),
    n !== e.value && (e.value = n),
    t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
    r != null && (e.defaultValue = "" + r);
}
function Ec(e) {
  var t = e.textContent;
  t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t);
}
function Df(e) {
  switch (e) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function Yl(e, t) {
  return e == null || e === "http://www.w3.org/1999/xhtml"
    ? Df(t)
    : e === "http://www.w3.org/2000/svg" && t === "foreignObject"
    ? "http://www.w3.org/1999/xhtml"
    : e;
}
var hi,
  zf = (function (e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
      ? function (t, n, r, o) {
          MSApp.execUnsafeLocalFunction(function () {
            return e(t, n, r, o);
          });
        }
      : e;
  })(function (e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
      e.innerHTML = t;
    else {
      for (
        hi = hi || document.createElement("div"),
          hi.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
          t = hi.firstChild;
        e.firstChild;

      )
        e.removeChild(e.firstChild);
      for (; t.firstChild; ) e.appendChild(t.firstChild);
    }
  });
function No(e, t) {
  if (t) {
    var n = e.firstChild;
    if (n && n === e.lastChild && n.nodeType === 3) {
      n.nodeValue = t;
      return;
    }
  }
  e.textContent = t;
}
var go = {
    animationIterationCount: !0,
    aspectRatio: !0,
    borderImageOutset: !0,
    borderImageSlice: !0,
    borderImageWidth: !0,
    boxFlex: !0,
    boxFlexGroup: !0,
    boxOrdinalGroup: !0,
    columnCount: !0,
    columns: !0,
    flex: !0,
    flexGrow: !0,
    flexPositive: !0,
    flexShrink: !0,
    flexNegative: !0,
    flexOrder: !0,
    gridArea: !0,
    gridRow: !0,
    gridRowEnd: !0,
    gridRowSpan: !0,
    gridRowStart: !0,
    gridColumn: !0,
    gridColumnEnd: !0,
    gridColumnSpan: !0,
    gridColumnStart: !0,
    fontWeight: !0,
    lineClamp: !0,
    lineHeight: !0,
    opacity: !0,
    order: !0,
    orphans: !0,
    tabSize: !0,
    widows: !0,
    zIndex: !0,
    zoom: !0,
    fillOpacity: !0,
    floodOpacity: !0,
    stopOpacity: !0,
    strokeDasharray: !0,
    strokeDashoffset: !0,
    strokeMiterlimit: !0,
    strokeOpacity: !0,
    strokeWidth: !0,
  },
  l0 = ["Webkit", "ms", "Moz", "O"];
Object.keys(go).forEach(function (e) {
  l0.forEach(function (t) {
    (t = t + e.charAt(0).toUpperCase() + e.substring(1)), (go[t] = go[e]);
  });
});
function Ff(e, t, n) {
  return t == null || typeof t == "boolean" || t === ""
    ? ""
    : n || typeof t != "number" || t === 0 || (go.hasOwnProperty(e) && go[e])
    ? ("" + t).trim()
    : t + "px";
}
function $f(e, t) {
  e = e.style;
  for (var n in t)
    if (t.hasOwnProperty(n)) {
      var r = n.indexOf("--") === 0,
        o = Ff(n, t[n], r);
      n === "float" && (n = "cssFloat"), r ? e.setProperty(n, o) : (e[n] = o);
    }
}
var a0 = ce(
  { menuitem: !0 },
  {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0,
  }
);
function Xl(e, t) {
  if (t) {
    if (a0[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
      throw Error(R(137, e));
    if (t.dangerouslySetInnerHTML != null) {
      if (t.children != null) throw Error(R(60));
      if (
        typeof t.dangerouslySetInnerHTML != "object" ||
        !("__html" in t.dangerouslySetInnerHTML)
      )
        throw Error(R(61));
    }
    if (t.style != null && typeof t.style != "object") throw Error(R(62));
  }
}
function ql(e, t) {
  if (e.indexOf("-") === -1) return typeof t.is == "string";
  switch (e) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return !1;
    default:
      return !0;
  }
}
var Jl = null;
function ou(e) {
  return (
    (e = e.target || e.srcElement || window),
    e.correspondingUseElement && (e = e.correspondingUseElement),
    e.nodeType === 3 ? e.parentNode : e
  );
}
var Zl = null,
  kr = null,
  Er = null;
function Cc(e) {
  if ((e = ei(e))) {
    if (typeof Zl != "function") throw Error(R(280));
    var t = e.stateNode;
    t && ((t = _s(t)), Zl(e.stateNode, e.type, t));
  }
}
function Uf(e) {
  kr ? (Er ? Er.push(e) : (Er = [e])) : (kr = e);
}
function Bf() {
  if (kr) {
    var e = kr,
      t = Er;
    if (((Er = kr = null), Cc(e), t)) for (e = 0; e < t.length; e++) Cc(t[e]);
  }
}
function Wf(e, t) {
  return e(t);
}
function Vf() {}
var ul = !1;
function Hf(e, t, n) {
  if (ul) return e(t, n);
  ul = !0;
  try {
    return Wf(e, t, n);
  } finally {
    (ul = !1), (kr !== null || Er !== null) && (Vf(), Bf());
  }
}
function To(e, t) {
  var n = e.stateNode;
  if (n === null) return null;
  var r = _s(n);
  if (r === null) return null;
  n = r[t];
  e: switch (t) {
    case "onClick":
    case "onClickCapture":
    case "onDoubleClick":
    case "onDoubleClickCapture":
    case "onMouseDown":
    case "onMouseDownCapture":
    case "onMouseMove":
    case "onMouseMoveCapture":
    case "onMouseUp":
    case "onMouseUpCapture":
    case "onMouseEnter":
      (r = !r.disabled) ||
        ((e = e.type),
        (r = !(
          e === "button" ||
          e === "input" ||
          e === "select" ||
          e === "textarea"
        ))),
        (e = !r);
      break e;
    default:
      e = !1;
  }
  if (e) return null;
  if (n && typeof n != "function") throw Error(R(231, t, typeof n));
  return n;
}
var ea = !1;
if (Bt)
  try {
    var no = {};
    Object.defineProperty(no, "passive", {
      get: function () {
        ea = !0;
      },
    }),
      window.addEventListener("test", no, no),
      window.removeEventListener("test", no, no);
  } catch {
    ea = !1;
  }
function u0(e, t, n, r, o, i, s, l, a) {
  var u = Array.prototype.slice.call(arguments, 3);
  try {
    t.apply(n, u);
  } catch (d) {
    this.onError(d);
  }
}
var vo = !1,
  Xi = null,
  qi = !1,
  ta = null,
  c0 = {
    onError: function (e) {
      (vo = !0), (Xi = e);
    },
  };
function d0(e, t, n, r, o, i, s, l, a) {
  (vo = !1), (Xi = null), u0.apply(c0, arguments);
}
function f0(e, t, n, r, o, i, s, l, a) {
  if ((d0.apply(this, arguments), vo)) {
    if (vo) {
      var u = Xi;
      (vo = !1), (Xi = null);
    } else throw Error(R(198));
    qi || ((qi = !0), (ta = u));
  }
}
function tr(e) {
  var t = e,
    n = e;
  if (e.alternate) for (; t.return; ) t = t.return;
  else {
    e = t;
    do (t = e), t.flags & 4098 && (n = t.return), (e = t.return);
    while (e);
  }
  return t.tag === 3 ? n : null;
}
function Qf(e) {
  if (e.tag === 13) {
    var t = e.memoizedState;
    if (
      (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
      t !== null)
    )
      return t.dehydrated;
  }
  return null;
}
function bc(e) {
  if (tr(e) !== e) throw Error(R(188));
}
function p0(e) {
  var t = e.alternate;
  if (!t) {
    if (((t = tr(e)), t === null)) throw Error(R(188));
    return t !== e ? null : e;
  }
  for (var n = e, r = t; ; ) {
    var o = n.return;
    if (o === null) break;
    var i = o.alternate;
    if (i === null) {
      if (((r = o.return), r !== null)) {
        n = r;
        continue;
      }
      break;
    }
    if (o.child === i.child) {
      for (i = o.child; i; ) {
        if (i === n) return bc(o), e;
        if (i === r) return bc(o), t;
        i = i.sibling;
      }
      throw Error(R(188));
    }
    if (n.return !== r.return) (n = o), (r = i);
    else {
      for (var s = !1, l = o.child; l; ) {
        if (l === n) {
          (s = !0), (n = o), (r = i);
          break;
        }
        if (l === r) {
          (s = !0), (r = o), (n = i);
          break;
        }
        l = l.sibling;
      }
      if (!s) {
        for (l = i.child; l; ) {
          if (l === n) {
            (s = !0), (n = i), (r = o);
            break;
          }
          if (l === r) {
            (s = !0), (r = i), (n = o);
            break;
          }
          l = l.sibling;
        }
        if (!s) throw Error(R(189));
      }
    }
    if (n.alternate !== r) throw Error(R(190));
  }
  if (n.tag !== 3) throw Error(R(188));
  return n.stateNode.current === n ? e : t;
}
function Kf(e) {
  return (e = p0(e)), e !== null ? Gf(e) : null;
}
function Gf(e) {
  if (e.tag === 5 || e.tag === 6) return e;
  for (e = e.child; e !== null; ) {
    var t = Gf(e);
    if (t !== null) return t;
    e = e.sibling;
  }
  return null;
}
var Yf = Je.unstable_scheduleCallback,
  Pc = Je.unstable_cancelCallback,
  h0 = Je.unstable_shouldYield,
  m0 = Je.unstable_requestPaint,
  pe = Je.unstable_now,
  g0 = Je.unstable_getCurrentPriorityLevel,
  iu = Je.unstable_ImmediatePriority,
  Xf = Je.unstable_UserBlockingPriority,
  Ji = Je.unstable_NormalPriority,
  v0 = Je.unstable_LowPriority,
  qf = Je.unstable_IdlePriority,
  Ts = null,
  At = null;
function y0(e) {
  if (At && typeof At.onCommitFiberRoot == "function")
    try {
      At.onCommitFiberRoot(Ts, e, void 0, (e.current.flags & 128) === 128);
    } catch {}
}
var mt = Math.clz32 ? Math.clz32 : S0,
  x0 = Math.log,
  w0 = Math.LN2;
function S0(e) {
  return (e >>>= 0), e === 0 ? 32 : (31 - ((x0(e) / w0) | 0)) | 0;
}
var mi = 64,
  gi = 4194304;
function ho(e) {
  switch (e & -e) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return e & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return e & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return e;
  }
}
function Zi(e, t) {
  var n = e.pendingLanes;
  if (n === 0) return 0;
  var r = 0,
    o = e.suspendedLanes,
    i = e.pingedLanes,
    s = n & 268435455;
  if (s !== 0) {
    var l = s & ~o;
    l !== 0 ? (r = ho(l)) : ((i &= s), i !== 0 && (r = ho(i)));
  } else (s = n & ~o), s !== 0 ? (r = ho(s)) : i !== 0 && (r = ho(i));
  if (r === 0) return 0;
  if (
    t !== 0 &&
    t !== r &&
    !(t & o) &&
    ((o = r & -r), (i = t & -t), o >= i || (o === 16 && (i & 4194240) !== 0))
  )
    return t;
  if ((r & 4 && (r |= n & 16), (t = e.entangledLanes), t !== 0))
    for (e = e.entanglements, t &= r; 0 < t; )
      (n = 31 - mt(t)), (o = 1 << n), (r |= e[n]), (t &= ~o);
  return r;
}
function k0(e, t) {
  switch (e) {
    case 1:
    case 2:
    case 4:
      return t + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return t + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1;
  }
}
function E0(e, t) {
  for (
    var n = e.suspendedLanes,
      r = e.pingedLanes,
      o = e.expirationTimes,
      i = e.pendingLanes;
    0 < i;

  ) {
    var s = 31 - mt(i),
      l = 1 << s,
      a = o[s];
    a === -1
      ? (!(l & n) || l & r) && (o[s] = k0(l, t))
      : a <= t && (e.expiredLanes |= l),
      (i &= ~l);
  }
}
function na(e) {
  return (
    (e = e.pendingLanes & -1073741825),
    e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
  );
}
function Jf() {
  var e = mi;
  return (mi <<= 1), !(mi & 4194240) && (mi = 64), e;
}
function cl(e) {
  for (var t = [], n = 0; 31 > n; n++) t.push(e);
  return t;
}
function Jo(e, t, n) {
  (e.pendingLanes |= t),
    t !== 536870912 && ((e.suspendedLanes = 0), (e.pingedLanes = 0)),
    (e = e.eventTimes),
    (t = 31 - mt(t)),
    (e[t] = n);
}
function C0(e, t) {
  var n = e.pendingLanes & ~t;
  (e.pendingLanes = t),
    (e.suspendedLanes = 0),
    (e.pingedLanes = 0),
    (e.expiredLanes &= t),
    (e.mutableReadLanes &= t),
    (e.entangledLanes &= t),
    (t = e.entanglements);
  var r = e.eventTimes;
  for (e = e.expirationTimes; 0 < n; ) {
    var o = 31 - mt(n),
      i = 1 << o;
    (t[o] = 0), (r[o] = -1), (e[o] = -1), (n &= ~i);
  }
}
function su(e, t) {
  var n = (e.entangledLanes |= t);
  for (e = e.entanglements; n; ) {
    var r = 31 - mt(n),
      o = 1 << r;
    (o & t) | (e[r] & t) && (e[r] |= t), (n &= ~o);
  }
}
var Z = 0;
function Zf(e) {
  return (e &= -e), 1 < e ? (4 < e ? (e & 268435455 ? 16 : 536870912) : 4) : 1;
}
var ep,
  lu,
  tp,
  np,
  rp,
  ra = !1,
  vi = [],
  yn = null,
  xn = null,
  wn = null,
  Ro = new Map(),
  Ao = new Map(),
  an = [],
  b0 =
    "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
      " "
    );
function Nc(e, t) {
  switch (e) {
    case "focusin":
    case "focusout":
      yn = null;
      break;
    case "dragenter":
    case "dragleave":
      xn = null;
      break;
    case "mouseover":
    case "mouseout":
      wn = null;
      break;
    case "pointerover":
    case "pointerout":
      Ro.delete(t.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      Ao.delete(t.pointerId);
  }
}
function ro(e, t, n, r, o, i) {
  return e === null || e.nativeEvent !== i
    ? ((e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: i,
        targetContainers: [o],
      }),
      t !== null && ((t = ei(t)), t !== null && lu(t)),
      e)
    : ((e.eventSystemFlags |= r),
      (t = e.targetContainers),
      o !== null && t.indexOf(o) === -1 && t.push(o),
      e);
}
function P0(e, t, n, r, o) {
  switch (t) {
    case "focusin":
      return (yn = ro(yn, e, t, n, r, o)), !0;
    case "dragenter":
      return (xn = ro(xn, e, t, n, r, o)), !0;
    case "mouseover":
      return (wn = ro(wn, e, t, n, r, o)), !0;
    case "pointerover":
      var i = o.pointerId;
      return Ro.set(i, ro(Ro.get(i) || null, e, t, n, r, o)), !0;
    case "gotpointercapture":
      return (
        (i = o.pointerId), Ao.set(i, ro(Ao.get(i) || null, e, t, n, r, o)), !0
      );
  }
  return !1;
}
function op(e) {
  var t = Fn(e.target);
  if (t !== null) {
    var n = tr(t);
    if (n !== null) {
      if (((t = n.tag), t === 13)) {
        if (((t = Qf(n)), t !== null)) {
          (e.blockedOn = t),
            rp(e.priority, function () {
              tp(n);
            });
          return;
        }
      } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
        e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
        return;
      }
    }
  }
  e.blockedOn = null;
}
function Li(e) {
  if (e.blockedOn !== null) return !1;
  for (var t = e.targetContainers; 0 < t.length; ) {
    var n = oa(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
    if (n === null) {
      n = e.nativeEvent;
      var r = new n.constructor(n.type, n);
      (Jl = r), n.target.dispatchEvent(r), (Jl = null);
    } else return (t = ei(n)), t !== null && lu(t), (e.blockedOn = n), !1;
    t.shift();
  }
  return !0;
}
function Tc(e, t, n) {
  Li(e) && n.delete(t);
}
function N0() {
  (ra = !1),
    yn !== null && Li(yn) && (yn = null),
    xn !== null && Li(xn) && (xn = null),
    wn !== null && Li(wn) && (wn = null),
    Ro.forEach(Tc),
    Ao.forEach(Tc);
}
function oo(e, t) {
  e.blockedOn === t &&
    ((e.blockedOn = null),
    ra ||
      ((ra = !0),
      Je.unstable_scheduleCallback(Je.unstable_NormalPriority, N0)));
}
function jo(e) {
  function t(o) {
    return oo(o, e);
  }
  if (0 < vi.length) {
    oo(vi[0], e);
    for (var n = 1; n < vi.length; n++) {
      var r = vi[n];
      r.blockedOn === e && (r.blockedOn = null);
    }
  }
  for (
    yn !== null && oo(yn, e),
      xn !== null && oo(xn, e),
      wn !== null && oo(wn, e),
      Ro.forEach(t),
      Ao.forEach(t),
      n = 0;
    n < an.length;
    n++
  )
    (r = an[n]), r.blockedOn === e && (r.blockedOn = null);
  for (; 0 < an.length && ((n = an[0]), n.blockedOn === null); )
    op(n), n.blockedOn === null && an.shift();
}
var Cr = Yt.ReactCurrentBatchConfig,
  es = !0;
function T0(e, t, n, r) {
  var o = Z,
    i = Cr.transition;
  Cr.transition = null;
  try {
    (Z = 1), au(e, t, n, r);
  } finally {
    (Z = o), (Cr.transition = i);
  }
}
function R0(e, t, n, r) {
  var o = Z,
    i = Cr.transition;
  Cr.transition = null;
  try {
    (Z = 4), au(e, t, n, r);
  } finally {
    (Z = o), (Cr.transition = i);
  }
}
function au(e, t, n, r) {
  if (es) {
    var o = oa(e, t, n, r);
    if (o === null) wl(e, t, r, ts, n), Nc(e, r);
    else if (P0(o, e, t, n, r)) r.stopPropagation();
    else if ((Nc(e, r), t & 4 && -1 < b0.indexOf(e))) {
      for (; o !== null; ) {
        var i = ei(o);
        if (
          (i !== null && ep(i),
          (i = oa(e, t, n, r)),
          i === null && wl(e, t, r, ts, n),
          i === o)
        )
          break;
        o = i;
      }
      o !== null && r.stopPropagation();
    } else wl(e, t, r, null, n);
  }
}
var ts = null;
function oa(e, t, n, r) {
  if (((ts = null), (e = ou(r)), (e = Fn(e)), e !== null))
    if (((t = tr(e)), t === null)) e = null;
    else if (((n = t.tag), n === 13)) {
      if (((e = Qf(t)), e !== null)) return e;
      e = null;
    } else if (n === 3) {
      if (t.stateNode.current.memoizedState.isDehydrated)
        return t.tag === 3 ? t.stateNode.containerInfo : null;
      e = null;
    } else t !== e && (e = null);
  return (ts = e), null;
}
function ip(e) {
  switch (e) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (g0()) {
        case iu:
          return 1;
        case Xf:
          return 4;
        case Ji:
        case v0:
          return 16;
        case qf:
          return 536870912;
        default:
          return 16;
      }
    default:
      return 16;
  }
}
var mn = null,
  uu = null,
  Ii = null;
function sp() {
  if (Ii) return Ii;
  var e,
    t = uu,
    n = t.length,
    r,
    o = "value" in mn ? mn.value : mn.textContent,
    i = o.length;
  for (e = 0; e < n && t[e] === o[e]; e++);
  var s = n - e;
  for (r = 1; r <= s && t[n - r] === o[i - r]; r++);
  return (Ii = o.slice(e, 1 < r ? 1 - r : void 0));
}
function Di(e) {
  var t = e.keyCode;
  return (
    "charCode" in e
      ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
      : (e = t),
    e === 10 && (e = 13),
    32 <= e || e === 13 ? e : 0
  );
}
function yi() {
  return !0;
}
function Rc() {
  return !1;
}
function et(e) {
  function t(n, r, o, i, s) {
    (this._reactName = n),
      (this._targetInst = o),
      (this.type = r),
      (this.nativeEvent = i),
      (this.target = s),
      (this.currentTarget = null);
    for (var l in e)
      e.hasOwnProperty(l) && ((n = e[l]), (this[l] = n ? n(i) : i[l]));
    return (
      (this.isDefaultPrevented = (
        i.defaultPrevented != null ? i.defaultPrevented : i.returnValue === !1
      )
        ? yi
        : Rc),
      (this.isPropagationStopped = Rc),
      this
    );
  }
  return (
    ce(t.prototype, {
      preventDefault: function () {
        this.defaultPrevented = !0;
        var n = this.nativeEvent;
        n &&
          (n.preventDefault
            ? n.preventDefault()
            : typeof n.returnValue != "unknown" && (n.returnValue = !1),
          (this.isDefaultPrevented = yi));
      },
      stopPropagation: function () {
        var n = this.nativeEvent;
        n &&
          (n.stopPropagation
            ? n.stopPropagation()
            : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
          (this.isPropagationStopped = yi));
      },
      persist: function () {},
      isPersistent: yi,
    }),
    t
  );
}
var Gr = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function (e) {
      return e.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0,
  },
  cu = et(Gr),
  Zo = ce({}, Gr, { view: 0, detail: 0 }),
  A0 = et(Zo),
  dl,
  fl,
  io,
  Rs = ce({}, Zo, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: du,
    button: 0,
    buttons: 0,
    relatedTarget: function (e) {
      return e.relatedTarget === void 0
        ? e.fromElement === e.srcElement
          ? e.toElement
          : e.fromElement
        : e.relatedTarget;
    },
    movementX: function (e) {
      return "movementX" in e
        ? e.movementX
        : (e !== io &&
            (io && e.type === "mousemove"
              ? ((dl = e.screenX - io.screenX), (fl = e.screenY - io.screenY))
              : (fl = dl = 0),
            (io = e)),
          dl);
    },
    movementY: function (e) {
      return "movementY" in e ? e.movementY : fl;
    },
  }),
  Ac = et(Rs),
  j0 = ce({}, Rs, { dataTransfer: 0 }),
  _0 = et(j0),
  O0 = ce({}, Zo, { relatedTarget: 0 }),
  pl = et(O0),
  M0 = ce({}, Gr, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
  L0 = et(M0),
  I0 = ce({}, Gr, {
    clipboardData: function (e) {
      return "clipboardData" in e ? e.clipboardData : window.clipboardData;
    },
  }),
  D0 = et(I0),
  z0 = ce({}, Gr, { data: 0 }),
  jc = et(z0),
  F0 = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified",
  },
  $0 = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta",
  },
  U0 = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey",
  };
function B0(e) {
  var t = this.nativeEvent;
  return t.getModifierState ? t.getModifierState(e) : (e = U0[e]) ? !!t[e] : !1;
}
function du() {
  return B0;
}
var W0 = ce({}, Zo, {
    key: function (e) {
      if (e.key) {
        var t = F0[e.key] || e.key;
        if (t !== "Unidentified") return t;
      }
      return e.type === "keypress"
        ? ((e = Di(e)), e === 13 ? "Enter" : String.fromCharCode(e))
        : e.type === "keydown" || e.type === "keyup"
        ? $0[e.keyCode] || "Unidentified"
        : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: du,
    charCode: function (e) {
      return e.type === "keypress" ? Di(e) : 0;
    },
    keyCode: function (e) {
      return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    },
    which: function (e) {
      return e.type === "keypress"
        ? Di(e)
        : e.type === "keydown" || e.type === "keyup"
        ? e.keyCode
        : 0;
    },
  }),
  V0 = et(W0),
  H0 = ce({}, Rs, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0,
  }),
  _c = et(H0),
  Q0 = ce({}, Zo, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: du,
  }),
  K0 = et(Q0),
  G0 = ce({}, Gr, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
  Y0 = et(G0),
  X0 = ce({}, Rs, {
    deltaX: function (e) {
      return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
    },
    deltaY: function (e) {
      return "deltaY" in e
        ? e.deltaY
        : "wheelDeltaY" in e
        ? -e.wheelDeltaY
        : "wheelDelta" in e
        ? -e.wheelDelta
        : 0;
    },
    deltaZ: 0,
    deltaMode: 0,
  }),
  q0 = et(X0),
  J0 = [9, 13, 27, 32],
  fu = Bt && "CompositionEvent" in window,
  yo = null;
Bt && "documentMode" in document && (yo = document.documentMode);
var Z0 = Bt && "TextEvent" in window && !yo,
  lp = Bt && (!fu || (yo && 8 < yo && 11 >= yo)),
  Oc = " ",
  Mc = !1;
function ap(e, t) {
  switch (e) {
    case "keyup":
      return J0.indexOf(t.keyCode) !== -1;
    case "keydown":
      return t.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return !0;
    default:
      return !1;
  }
}
function up(e) {
  return (e = e.detail), typeof e == "object" && "data" in e ? e.data : null;
}
var dr = !1;
function ev(e, t) {
  switch (e) {
    case "compositionend":
      return up(t);
    case "keypress":
      return t.which !== 32 ? null : ((Mc = !0), Oc);
    case "textInput":
      return (e = t.data), e === Oc && Mc ? null : e;
    default:
      return null;
  }
}
function tv(e, t) {
  if (dr)
    return e === "compositionend" || (!fu && ap(e, t))
      ? ((e = sp()), (Ii = uu = mn = null), (dr = !1), e)
      : null;
  switch (e) {
    case "paste":
      return null;
    case "keypress":
      if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
        if (t.char && 1 < t.char.length) return t.char;
        if (t.which) return String.fromCharCode(t.which);
      }
      return null;
    case "compositionend":
      return lp && t.locale !== "ko" ? null : t.data;
    default:
      return null;
  }
}
var nv = {
  color: !0,
  date: !0,
  datetime: !0,
  "datetime-local": !0,
  email: !0,
  month: !0,
  number: !0,
  password: !0,
  range: !0,
  search: !0,
  tel: !0,
  text: !0,
  time: !0,
  url: !0,
  week: !0,
};
function Lc(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return t === "input" ? !!nv[e.type] : t === "textarea";
}
function cp(e, t, n, r) {
  Uf(r),
    (t = ns(t, "onChange")),
    0 < t.length &&
      ((n = new cu("onChange", "change", null, n, r)),
      e.push({ event: n, listeners: t }));
}
var xo = null,
  _o = null;
function rv(e) {
  Sp(e, 0);
}
function As(e) {
  var t = hr(e);
  if (Mf(t)) return e;
}
function ov(e, t) {
  if (e === "change") return t;
}
var dp = !1;
if (Bt) {
  var hl;
  if (Bt) {
    var ml = "oninput" in document;
    if (!ml) {
      var Ic = document.createElement("div");
      Ic.setAttribute("oninput", "return;"),
        (ml = typeof Ic.oninput == "function");
    }
    hl = ml;
  } else hl = !1;
  dp = hl && (!document.documentMode || 9 < document.documentMode);
}
function Dc() {
  xo && (xo.detachEvent("onpropertychange", fp), (_o = xo = null));
}
function fp(e) {
  if (e.propertyName === "value" && As(_o)) {
    var t = [];
    cp(t, _o, e, ou(e)), Hf(rv, t);
  }
}
function iv(e, t, n) {
  e === "focusin"
    ? (Dc(), (xo = t), (_o = n), xo.attachEvent("onpropertychange", fp))
    : e === "focusout" && Dc();
}
function sv(e) {
  if (e === "selectionchange" || e === "keyup" || e === "keydown")
    return As(_o);
}
function lv(e, t) {
  if (e === "click") return As(t);
}
function av(e, t) {
  if (e === "input" || e === "change") return As(t);
}
function uv(e, t) {
  return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
}
var vt = typeof Object.is == "function" ? Object.is : uv;
function Oo(e, t) {
  if (vt(e, t)) return !0;
  if (typeof e != "object" || e === null || typeof t != "object" || t === null)
    return !1;
  var n = Object.keys(e),
    r = Object.keys(t);
  if (n.length !== r.length) return !1;
  for (r = 0; r < n.length; r++) {
    var o = n[r];
    if (!$l.call(t, o) || !vt(e[o], t[o])) return !1;
  }
  return !0;
}
function zc(e) {
  for (; e && e.firstChild; ) e = e.firstChild;
  return e;
}
function Fc(e, t) {
  var n = zc(e);
  e = 0;
  for (var r; n; ) {
    if (n.nodeType === 3) {
      if (((r = e + n.textContent.length), e <= t && r >= t))
        return { node: n, offset: t - e };
      e = r;
    }
    e: {
      for (; n; ) {
        if (n.nextSibling) {
          n = n.nextSibling;
          break e;
        }
        n = n.parentNode;
      }
      n = void 0;
    }
    n = zc(n);
  }
}
function pp(e, t) {
  return e && t
    ? e === t
      ? !0
      : e && e.nodeType === 3
      ? !1
      : t && t.nodeType === 3
      ? pp(e, t.parentNode)
      : "contains" in e
      ? e.contains(t)
      : e.compareDocumentPosition
      ? !!(e.compareDocumentPosition(t) & 16)
      : !1
    : !1;
}
function hp() {
  for (var e = window, t = Yi(); t instanceof e.HTMLIFrameElement; ) {
    try {
      var n = typeof t.contentWindow.location.href == "string";
    } catch {
      n = !1;
    }
    if (n) e = t.contentWindow;
    else break;
    t = Yi(e.document);
  }
  return t;
}
function pu(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return (
    t &&
    ((t === "input" &&
      (e.type === "text" ||
        e.type === "search" ||
        e.type === "tel" ||
        e.type === "url" ||
        e.type === "password")) ||
      t === "textarea" ||
      e.contentEditable === "true")
  );
}
function cv(e) {
  var t = hp(),
    n = e.focusedElem,
    r = e.selectionRange;
  if (
    t !== n &&
    n &&
    n.ownerDocument &&
    pp(n.ownerDocument.documentElement, n)
  ) {
    if (r !== null && pu(n)) {
      if (
        ((t = r.start),
        (e = r.end),
        e === void 0 && (e = t),
        "selectionStart" in n)
      )
        (n.selectionStart = t), (n.selectionEnd = Math.min(e, n.value.length));
      else if (
        ((e = ((t = n.ownerDocument || document) && t.defaultView) || window),
        e.getSelection)
      ) {
        e = e.getSelection();
        var o = n.textContent.length,
          i = Math.min(r.start, o);
        (r = r.end === void 0 ? i : Math.min(r.end, o)),
          !e.extend && i > r && ((o = r), (r = i), (i = o)),
          (o = Fc(n, i));
        var s = Fc(n, r);
        o &&
          s &&
          (e.rangeCount !== 1 ||
            e.anchorNode !== o.node ||
            e.anchorOffset !== o.offset ||
            e.focusNode !== s.node ||
            e.focusOffset !== s.offset) &&
          ((t = t.createRange()),
          t.setStart(o.node, o.offset),
          e.removeAllRanges(),
          i > r
            ? (e.addRange(t), e.extend(s.node, s.offset))
            : (t.setEnd(s.node, s.offset), e.addRange(t)));
      }
    }
    for (t = [], e = n; (e = e.parentNode); )
      e.nodeType === 1 &&
        t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
    for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
      (e = t[n]),
        (e.element.scrollLeft = e.left),
        (e.element.scrollTop = e.top);
  }
}
var dv = Bt && "documentMode" in document && 11 >= document.documentMode,
  fr = null,
  ia = null,
  wo = null,
  sa = !1;
function $c(e, t, n) {
  var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
  sa ||
    fr == null ||
    fr !== Yi(r) ||
    ((r = fr),
    "selectionStart" in r && pu(r)
      ? (r = { start: r.selectionStart, end: r.selectionEnd })
      : ((r = (
          (r.ownerDocument && r.ownerDocument.defaultView) ||
          window
        ).getSelection()),
        (r = {
          anchorNode: r.anchorNode,
          anchorOffset: r.anchorOffset,
          focusNode: r.focusNode,
          focusOffset: r.focusOffset,
        })),
    (wo && Oo(wo, r)) ||
      ((wo = r),
      (r = ns(ia, "onSelect")),
      0 < r.length &&
        ((t = new cu("onSelect", "select", null, t, n)),
        e.push({ event: t, listeners: r }),
        (t.target = fr))));
}
function xi(e, t) {
  var n = {};
  return (
    (n[e.toLowerCase()] = t.toLowerCase()),
    (n["Webkit" + e] = "webkit" + t),
    (n["Moz" + e] = "moz" + t),
    n
  );
}
var pr = {
    animationend: xi("Animation", "AnimationEnd"),
    animationiteration: xi("Animation", "AnimationIteration"),
    animationstart: xi("Animation", "AnimationStart"),
    transitionend: xi("Transition", "TransitionEnd"),
  },
  gl = {},
  mp = {};
Bt &&
  ((mp = document.createElement("div").style),
  "AnimationEvent" in window ||
    (delete pr.animationend.animation,
    delete pr.animationiteration.animation,
    delete pr.animationstart.animation),
  "TransitionEvent" in window || delete pr.transitionend.transition);
function js(e) {
  if (gl[e]) return gl[e];
  if (!pr[e]) return e;
  var t = pr[e],
    n;
  for (n in t) if (t.hasOwnProperty(n) && n in mp) return (gl[e] = t[n]);
  return e;
}
var gp = js("animationend"),
  vp = js("animationiteration"),
  yp = js("animationstart"),
  xp = js("transitionend"),
  wp = new Map(),
  Uc =
    "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
      " "
    );
function On(e, t) {
  wp.set(e, t), er(t, [e]);
}
for (var vl = 0; vl < Uc.length; vl++) {
  var yl = Uc[vl],
    fv = yl.toLowerCase(),
    pv = yl[0].toUpperCase() + yl.slice(1);
  On(fv, "on" + pv);
}
On(gp, "onAnimationEnd");
On(vp, "onAnimationIteration");
On(yp, "onAnimationStart");
On("dblclick", "onDoubleClick");
On("focusin", "onFocus");
On("focusout", "onBlur");
On(xp, "onTransitionEnd");
zr("onMouseEnter", ["mouseout", "mouseover"]);
zr("onMouseLeave", ["mouseout", "mouseover"]);
zr("onPointerEnter", ["pointerout", "pointerover"]);
zr("onPointerLeave", ["pointerout", "pointerover"]);
er(
  "onChange",
  "change click focusin focusout input keydown keyup selectionchange".split(" ")
);
er(
  "onSelect",
  "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
    " "
  )
);
er("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
er(
  "onCompositionEnd",
  "compositionend focusout keydown keypress keyup mousedown".split(" ")
);
er(
  "onCompositionStart",
  "compositionstart focusout keydown keypress keyup mousedown".split(" ")
);
er(
  "onCompositionUpdate",
  "compositionupdate focusout keydown keypress keyup mousedown".split(" ")
);
var mo =
    "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
      " "
    ),
  hv = new Set("cancel close invalid load scroll toggle".split(" ").concat(mo));
function Bc(e, t, n) {
  var r = e.type || "unknown-event";
  (e.currentTarget = n), f0(r, t, void 0, e), (e.currentTarget = null);
}
function Sp(e, t) {
  t = (t & 4) !== 0;
  for (var n = 0; n < e.length; n++) {
    var r = e[n],
      o = r.event;
    r = r.listeners;
    e: {
      var i = void 0;
      if (t)
        for (var s = r.length - 1; 0 <= s; s--) {
          var l = r[s],
            a = l.instance,
            u = l.currentTarget;
          if (((l = l.listener), a !== i && o.isPropagationStopped())) break e;
          Bc(o, l, u), (i = a);
        }
      else
        for (s = 0; s < r.length; s++) {
          if (
            ((l = r[s]),
            (a = l.instance),
            (u = l.currentTarget),
            (l = l.listener),
            a !== i && o.isPropagationStopped())
          )
            break e;
          Bc(o, l, u), (i = a);
        }
    }
  }
  if (qi) throw ((e = ta), (qi = !1), (ta = null), e);
}
function oe(e, t) {
  var n = t[da];
  n === void 0 && (n = t[da] = new Set());
  var r = e + "__bubble";
  n.has(r) || (kp(t, e, 2, !1), n.add(r));
}
function xl(e, t, n) {
  var r = 0;
  t && (r |= 4), kp(n, e, r, t);
}
var wi = "_reactListening" + Math.random().toString(36).slice(2);
function Mo(e) {
  if (!e[wi]) {
    (e[wi] = !0),
      Rf.forEach(function (n) {
        n !== "selectionchange" && (hv.has(n) || xl(n, !1, e), xl(n, !0, e));
      });
    var t = e.nodeType === 9 ? e : e.ownerDocument;
    t === null || t[wi] || ((t[wi] = !0), xl("selectionchange", !1, t));
  }
}
function kp(e, t, n, r) {
  switch (ip(t)) {
    case 1:
      var o = T0;
      break;
    case 4:
      o = R0;
      break;
    default:
      o = au;
  }
  (n = o.bind(null, t, n, e)),
    (o = void 0),
    !ea ||
      (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
      (o = !0),
    r
      ? o !== void 0
        ? e.addEventListener(t, n, { capture: !0, passive: o })
        : e.addEventListener(t, n, !0)
      : o !== void 0
      ? e.addEventListener(t, n, { passive: o })
      : e.addEventListener(t, n, !1);
}
function wl(e, t, n, r, o) {
  var i = r;
  if (!(t & 1) && !(t & 2) && r !== null)
    e: for (;;) {
      if (r === null) return;
      var s = r.tag;
      if (s === 3 || s === 4) {
        var l = r.stateNode.containerInfo;
        if (l === o || (l.nodeType === 8 && l.parentNode === o)) break;
        if (s === 4)
          for (s = r.return; s !== null; ) {
            var a = s.tag;
            if (
              (a === 3 || a === 4) &&
              ((a = s.stateNode.containerInfo),
              a === o || (a.nodeType === 8 && a.parentNode === o))
            )
              return;
            s = s.return;
          }
        for (; l !== null; ) {
          if (((s = Fn(l)), s === null)) return;
          if (((a = s.tag), a === 5 || a === 6)) {
            r = i = s;
            continue e;
          }
          l = l.parentNode;
        }
      }
      r = r.return;
    }
  Hf(function () {
    var u = i,
      d = ou(n),
      f = [];
    e: {
      var c = wp.get(e);
      if (c !== void 0) {
        var v = cu,
          x = e;
        switch (e) {
          case "keypress":
            if (Di(n) === 0) break e;
          case "keydown":
          case "keyup":
            v = V0;
            break;
          case "focusin":
            (x = "focus"), (v = pl);
            break;
          case "focusout":
            (x = "blur"), (v = pl);
            break;
          case "beforeblur":
          case "afterblur":
            v = pl;
            break;
          case "click":
            if (n.button === 2) break e;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            v = Ac;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            v = _0;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            v = K0;
            break;
          case gp:
          case vp:
          case yp:
            v = L0;
            break;
          case xp:
            v = Y0;
            break;
          case "scroll":
            v = A0;
            break;
          case "wheel":
            v = q0;
            break;
          case "copy":
          case "cut":
          case "paste":
            v = D0;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            v = _c;
        }
        var g = (t & 4) !== 0,
          S = !g && e === "scroll",
          h = g ? (c !== null ? c + "Capture" : null) : c;
        g = [];
        for (var p = u, m; p !== null; ) {
          m = p;
          var k = m.stateNode;
          if (
            (m.tag === 5 &&
              k !== null &&
              ((m = k),
              h !== null && ((k = To(p, h)), k != null && g.push(Lo(p, k, m)))),
            S)
          )
            break;
          p = p.return;
        }
        0 < g.length &&
          ((c = new v(c, x, null, n, d)), f.push({ event: c, listeners: g }));
      }
    }
    if (!(t & 7)) {
      e: {
        if (
          ((c = e === "mouseover" || e === "pointerover"),
          (v = e === "mouseout" || e === "pointerout"),
          c &&
            n !== Jl &&
            (x = n.relatedTarget || n.fromElement) &&
            (Fn(x) || x[Wt]))
        )
          break e;
        if (
          (v || c) &&
          ((c =
            d.window === d
              ? d
              : (c = d.ownerDocument)
              ? c.defaultView || c.parentWindow
              : window),
          v
            ? ((x = n.relatedTarget || n.toElement),
              (v = u),
              (x = x ? Fn(x) : null),
              x !== null &&
                ((S = tr(x)), x !== S || (x.tag !== 5 && x.tag !== 6)) &&
                (x = null))
            : ((v = null), (x = u)),
          v !== x)
        ) {
          if (
            ((g = Ac),
            (k = "onMouseLeave"),
            (h = "onMouseEnter"),
            (p = "mouse"),
            (e === "pointerout" || e === "pointerover") &&
              ((g = _c),
              (k = "onPointerLeave"),
              (h = "onPointerEnter"),
              (p = "pointer")),
            (S = v == null ? c : hr(v)),
            (m = x == null ? c : hr(x)),
            (c = new g(k, p + "leave", v, n, d)),
            (c.target = S),
            (c.relatedTarget = m),
            (k = null),
            Fn(d) === u &&
              ((g = new g(h, p + "enter", x, n, d)),
              (g.target = m),
              (g.relatedTarget = S),
              (k = g)),
            (S = k),
            v && x)
          )
            t: {
              for (g = v, h = x, p = 0, m = g; m; m = ar(m)) p++;
              for (m = 0, k = h; k; k = ar(k)) m++;
              for (; 0 < p - m; ) (g = ar(g)), p--;
              for (; 0 < m - p; ) (h = ar(h)), m--;
              for (; p--; ) {
                if (g === h || (h !== null && g === h.alternate)) break t;
                (g = ar(g)), (h = ar(h));
              }
              g = null;
            }
          else g = null;
          v !== null && Wc(f, c, v, g, !1),
            x !== null && S !== null && Wc(f, S, x, g, !0);
        }
      }
      e: {
        if (
          ((c = u ? hr(u) : window),
          (v = c.nodeName && c.nodeName.toLowerCase()),
          v === "select" || (v === "input" && c.type === "file"))
        )
          var E = ov;
        else if (Lc(c))
          if (dp) E = av;
          else {
            E = sv;
            var b = iv;
          }
        else
          (v = c.nodeName) &&
            v.toLowerCase() === "input" &&
            (c.type === "checkbox" || c.type === "radio") &&
            (E = lv);
        if (E && (E = E(e, u))) {
          cp(f, E, n, d);
          break e;
        }
        b && b(e, c, u),
          e === "focusout" &&
            (b = c._wrapperState) &&
            b.controlled &&
            c.type === "number" &&
            Kl(c, "number", c.value);
      }
      switch (((b = u ? hr(u) : window), e)) {
        case "focusin":
          (Lc(b) || b.contentEditable === "true") &&
            ((fr = b), (ia = u), (wo = null));
          break;
        case "focusout":
          wo = ia = fr = null;
          break;
        case "mousedown":
          sa = !0;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          (sa = !1), $c(f, n, d);
          break;
        case "selectionchange":
          if (dv) break;
        case "keydown":
        case "keyup":
          $c(f, n, d);
      }
      var P;
      if (fu)
        e: {
          switch (e) {
            case "compositionstart":
              var T = "onCompositionStart";
              break e;
            case "compositionend":
              T = "onCompositionEnd";
              break e;
            case "compositionupdate":
              T = "onCompositionUpdate";
              break e;
          }
          T = void 0;
        }
      else
        dr
          ? ap(e, n) && (T = "onCompositionEnd")
          : e === "keydown" && n.keyCode === 229 && (T = "onCompositionStart");
      T &&
        (lp &&
          n.locale !== "ko" &&
          (dr || T !== "onCompositionStart"
            ? T === "onCompositionEnd" && dr && (P = sp())
            : ((mn = d),
              (uu = "value" in mn ? mn.value : mn.textContent),
              (dr = !0))),
        (b = ns(u, T)),
        0 < b.length &&
          ((T = new jc(T, e, null, n, d)),
          f.push({ event: T, listeners: b }),
          P ? (T.data = P) : ((P = up(n)), P !== null && (T.data = P)))),
        (P = Z0 ? ev(e, n) : tv(e, n)) &&
          ((u = ns(u, "onBeforeInput")),
          0 < u.length &&
            ((d = new jc("onBeforeInput", "beforeinput", null, n, d)),
            f.push({ event: d, listeners: u }),
            (d.data = P)));
    }
    Sp(f, t);
  });
}
function Lo(e, t, n) {
  return { instance: e, listener: t, currentTarget: n };
}
function ns(e, t) {
  for (var n = t + "Capture", r = []; e !== null; ) {
    var o = e,
      i = o.stateNode;
    o.tag === 5 &&
      i !== null &&
      ((o = i),
      (i = To(e, n)),
      i != null && r.unshift(Lo(e, i, o)),
      (i = To(e, t)),
      i != null && r.push(Lo(e, i, o))),
      (e = e.return);
  }
  return r;
}
function ar(e) {
  if (e === null) return null;
  do e = e.return;
  while (e && e.tag !== 5);
  return e || null;
}
function Wc(e, t, n, r, o) {
  for (var i = t._reactName, s = []; n !== null && n !== r; ) {
    var l = n,
      a = l.alternate,
      u = l.stateNode;
    if (a !== null && a === r) break;
    l.tag === 5 &&
      u !== null &&
      ((l = u),
      o
        ? ((a = To(n, i)), a != null && s.unshift(Lo(n, a, l)))
        : o || ((a = To(n, i)), a != null && s.push(Lo(n, a, l)))),
      (n = n.return);
  }
  s.length !== 0 && e.push({ event: t, listeners: s });
}
var mv = /\r\n?/g,
  gv = /\u0000|\uFFFD/g;
function Vc(e) {
  return (typeof e == "string" ? e : "" + e)
    .replace(
      mv,
      `
`
    )
    .replace(gv, "");
}
function Si(e, t, n) {
  if (((t = Vc(t)), Vc(e) !== t && n)) throw Error(R(425));
}
function rs() {}
var la = null,
  aa = null;
function ua(e, t) {
  return (
    e === "textarea" ||
    e === "noscript" ||
    typeof t.children == "string" ||
    typeof t.children == "number" ||
    (typeof t.dangerouslySetInnerHTML == "object" &&
      t.dangerouslySetInnerHTML !== null &&
      t.dangerouslySetInnerHTML.__html != null)
  );
}
var ca = typeof setTimeout == "function" ? setTimeout : void 0,
  vv = typeof clearTimeout == "function" ? clearTimeout : void 0,
  Hc = typeof Promise == "function" ? Promise : void 0,
  yv =
    typeof queueMicrotask == "function"
      ? queueMicrotask
      : typeof Hc < "u"
      ? function (e) {
          return Hc.resolve(null).then(e).catch(xv);
        }
      : ca;
function xv(e) {
  setTimeout(function () {
    throw e;
  });
}
function Sl(e, t) {
  var n = t,
    r = 0;
  do {
    var o = n.nextSibling;
    if ((e.removeChild(n), o && o.nodeType === 8))
      if (((n = o.data), n === "/$")) {
        if (r === 0) {
          e.removeChild(o), jo(t);
          return;
        }
        r--;
      } else (n !== "$" && n !== "$?" && n !== "$!") || r++;
    n = o;
  } while (n);
  jo(t);
}
function Sn(e) {
  for (; e != null; e = e.nextSibling) {
    var t = e.nodeType;
    if (t === 1 || t === 3) break;
    if (t === 8) {
      if (((t = e.data), t === "$" || t === "$!" || t === "$?")) break;
      if (t === "/$") return null;
    }
  }
  return e;
}
function Qc(e) {
  e = e.previousSibling;
  for (var t = 0; e; ) {
    if (e.nodeType === 8) {
      var n = e.data;
      if (n === "$" || n === "$!" || n === "$?") {
        if (t === 0) return e;
        t--;
      } else n === "/$" && t++;
    }
    e = e.previousSibling;
  }
  return null;
}
var Yr = Math.random().toString(36).slice(2),
  Rt = "__reactFiber$" + Yr,
  Io = "__reactProps$" + Yr,
  Wt = "__reactContainer$" + Yr,
  da = "__reactEvents$" + Yr,
  wv = "__reactListeners$" + Yr,
  Sv = "__reactHandles$" + Yr;
function Fn(e) {
  var t = e[Rt];
  if (t) return t;
  for (var n = e.parentNode; n; ) {
    if ((t = n[Wt] || n[Rt])) {
      if (
        ((n = t.alternate),
        t.child !== null || (n !== null && n.child !== null))
      )
        for (e = Qc(e); e !== null; ) {
          if ((n = e[Rt])) return n;
          e = Qc(e);
        }
      return t;
    }
    (e = n), (n = e.parentNode);
  }
  return null;
}
function ei(e) {
  return (
    (e = e[Rt] || e[Wt]),
    !e || (e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3) ? null : e
  );
}
function hr(e) {
  if (e.tag === 5 || e.tag === 6) return e.stateNode;
  throw Error(R(33));
}
function _s(e) {
  return e[Io] || null;
}
var fa = [],
  mr = -1;
function Mn(e) {
  return { current: e };
}
function ie(e) {
  0 > mr || ((e.current = fa[mr]), (fa[mr] = null), mr--);
}
function te(e, t) {
  mr++, (fa[mr] = e.current), (e.current = t);
}
var Tn = {},
  _e = Mn(Tn),
  Ue = Mn(!1),
  Gn = Tn;
function Fr(e, t) {
  var n = e.type.contextTypes;
  if (!n) return Tn;
  var r = e.stateNode;
  if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
    return r.__reactInternalMemoizedMaskedChildContext;
  var o = {},
    i;
  for (i in n) o[i] = t[i];
  return (
    r &&
      ((e = e.stateNode),
      (e.__reactInternalMemoizedUnmaskedChildContext = t),
      (e.__reactInternalMemoizedMaskedChildContext = o)),
    o
  );
}
function Be(e) {
  return (e = e.childContextTypes), e != null;
}
function os() {
  ie(Ue), ie(_e);
}
function Kc(e, t, n) {
  if (_e.current !== Tn) throw Error(R(168));
  te(_e, t), te(Ue, n);
}
function Ep(e, t, n) {
  var r = e.stateNode;
  if (((t = t.childContextTypes), typeof r.getChildContext != "function"))
    return n;
  r = r.getChildContext();
  for (var o in r) if (!(o in t)) throw Error(R(108, i0(e) || "Unknown", o));
  return ce({}, n, r);
}
function is(e) {
  return (
    (e =
      ((e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext) || Tn),
    (Gn = _e.current),
    te(_e, e),
    te(Ue, Ue.current),
    !0
  );
}
function Gc(e, t, n) {
  var r = e.stateNode;
  if (!r) throw Error(R(169));
  n
    ? ((e = Ep(e, t, Gn)),
      (r.__reactInternalMemoizedMergedChildContext = e),
      ie(Ue),
      ie(_e),
      te(_e, e))
    : ie(Ue),
    te(Ue, n);
}
var zt = null,
  Os = !1,
  kl = !1;
function Cp(e) {
  zt === null ? (zt = [e]) : zt.push(e);
}
function kv(e) {
  (Os = !0), Cp(e);
}
function Ln() {
  if (!kl && zt !== null) {
    kl = !0;
    var e = 0,
      t = Z;
    try {
      var n = zt;
      for (Z = 1; e < n.length; e++) {
        var r = n[e];
        do r = r(!0);
        while (r !== null);
      }
      (zt = null), (Os = !1);
    } catch (o) {
      throw (zt !== null && (zt = zt.slice(e + 1)), Yf(iu, Ln), o);
    } finally {
      (Z = t), (kl = !1);
    }
  }
  return null;
}
var gr = [],
  vr = 0,
  ss = null,
  ls = 0,
  nt = [],
  rt = 0,
  Yn = null,
  Ft = 1,
  $t = "";
function Dn(e, t) {
  (gr[vr++] = ls), (gr[vr++] = ss), (ss = e), (ls = t);
}
function bp(e, t, n) {
  (nt[rt++] = Ft), (nt[rt++] = $t), (nt[rt++] = Yn), (Yn = e);
  var r = Ft;
  e = $t;
  var o = 32 - mt(r) - 1;
  (r &= ~(1 << o)), (n += 1);
  var i = 32 - mt(t) + o;
  if (30 < i) {
    var s = o - (o % 5);
    (i = (r & ((1 << s) - 1)).toString(32)),
      (r >>= s),
      (o -= s),
      (Ft = (1 << (32 - mt(t) + o)) | (n << o) | r),
      ($t = i + e);
  } else (Ft = (1 << i) | (n << o) | r), ($t = e);
}
function hu(e) {
  e.return !== null && (Dn(e, 1), bp(e, 1, 0));
}
function mu(e) {
  for (; e === ss; )
    (ss = gr[--vr]), (gr[vr] = null), (ls = gr[--vr]), (gr[vr] = null);
  for (; e === Yn; )
    (Yn = nt[--rt]),
      (nt[rt] = null),
      ($t = nt[--rt]),
      (nt[rt] = null),
      (Ft = nt[--rt]),
      (nt[rt] = null);
}
var Xe = null,
  Ye = null,
  se = !1,
  ht = null;
function Pp(e, t) {
  var n = ot(5, null, null, 0);
  (n.elementType = "DELETED"),
    (n.stateNode = t),
    (n.return = e),
    (t = e.deletions),
    t === null ? ((e.deletions = [n]), (e.flags |= 16)) : t.push(n);
}
function Yc(e, t) {
  switch (e.tag) {
    case 5:
      var n = e.type;
      return (
        (t =
          t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase()
            ? null
            : t),
        t !== null
          ? ((e.stateNode = t), (Xe = e), (Ye = Sn(t.firstChild)), !0)
          : !1
      );
    case 6:
      return (
        (t = e.pendingProps === "" || t.nodeType !== 3 ? null : t),
        t !== null ? ((e.stateNode = t), (Xe = e), (Ye = null), !0) : !1
      );
    case 13:
      return (
        (t = t.nodeType !== 8 ? null : t),
        t !== null
          ? ((n = Yn !== null ? { id: Ft, overflow: $t } : null),
            (e.memoizedState = {
              dehydrated: t,
              treeContext: n,
              retryLane: 1073741824,
            }),
            (n = ot(18, null, null, 0)),
            (n.stateNode = t),
            (n.return = e),
            (e.child = n),
            (Xe = e),
            (Ye = null),
            !0)
          : !1
      );
    default:
      return !1;
  }
}
function pa(e) {
  return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
}
function ha(e) {
  if (se) {
    var t = Ye;
    if (t) {
      var n = t;
      if (!Yc(e, t)) {
        if (pa(e)) throw Error(R(418));
        t = Sn(n.nextSibling);
        var r = Xe;
        t && Yc(e, t)
          ? Pp(r, n)
          : ((e.flags = (e.flags & -4097) | 2), (se = !1), (Xe = e));
      }
    } else {
      if (pa(e)) throw Error(R(418));
      (e.flags = (e.flags & -4097) | 2), (se = !1), (Xe = e);
    }
  }
}
function Xc(e) {
  for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13; )
    e = e.return;
  Xe = e;
}
function ki(e) {
  if (e !== Xe) return !1;
  if (!se) return Xc(e), (se = !0), !1;
  var t;
  if (
    ((t = e.tag !== 3) &&
      !(t = e.tag !== 5) &&
      ((t = e.type),
      (t = t !== "head" && t !== "body" && !ua(e.type, e.memoizedProps))),
    t && (t = Ye))
  ) {
    if (pa(e)) throw (Np(), Error(R(418)));
    for (; t; ) Pp(e, t), (t = Sn(t.nextSibling));
  }
  if ((Xc(e), e.tag === 13)) {
    if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
      throw Error(R(317));
    e: {
      for (e = e.nextSibling, t = 0; e; ) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (n === "/$") {
            if (t === 0) {
              Ye = Sn(e.nextSibling);
              break e;
            }
            t--;
          } else (n !== "$" && n !== "$!" && n !== "$?") || t++;
        }
        e = e.nextSibling;
      }
      Ye = null;
    }
  } else Ye = Xe ? Sn(e.stateNode.nextSibling) : null;
  return !0;
}
function Np() {
  for (var e = Ye; e; ) e = Sn(e.nextSibling);
}
function $r() {
  (Ye = Xe = null), (se = !1);
}
function gu(e) {
  ht === null ? (ht = [e]) : ht.push(e);
}
var Ev = Yt.ReactCurrentBatchConfig;
function so(e, t, n) {
  if (
    ((e = n.ref), e !== null && typeof e != "function" && typeof e != "object")
  ) {
    if (n._owner) {
      if (((n = n._owner), n)) {
        if (n.tag !== 1) throw Error(R(309));
        var r = n.stateNode;
      }
      if (!r) throw Error(R(147, e));
      var o = r,
        i = "" + e;
      return t !== null &&
        t.ref !== null &&
        typeof t.ref == "function" &&
        t.ref._stringRef === i
        ? t.ref
        : ((t = function (s) {
            var l = o.refs;
            s === null ? delete l[i] : (l[i] = s);
          }),
          (t._stringRef = i),
          t);
    }
    if (typeof e != "string") throw Error(R(284));
    if (!n._owner) throw Error(R(290, e));
  }
  return e;
}
function Ei(e, t) {
  throw (
    ((e = Object.prototype.toString.call(t)),
    Error(
      R(
        31,
        e === "[object Object]"
          ? "object with keys {" + Object.keys(t).join(", ") + "}"
          : e
      )
    ))
  );
}
function qc(e) {
  var t = e._init;
  return t(e._payload);
}
function Tp(e) {
  function t(h, p) {
    if (e) {
      var m = h.deletions;
      m === null ? ((h.deletions = [p]), (h.flags |= 16)) : m.push(p);
    }
  }
  function n(h, p) {
    if (!e) return null;
    for (; p !== null; ) t(h, p), (p = p.sibling);
    return null;
  }
  function r(h, p) {
    for (h = new Map(); p !== null; )
      p.key !== null ? h.set(p.key, p) : h.set(p.index, p), (p = p.sibling);
    return h;
  }
  function o(h, p) {
    return (h = bn(h, p)), (h.index = 0), (h.sibling = null), h;
  }
  function i(h, p, m) {
    return (
      (h.index = m),
      e
        ? ((m = h.alternate),
          m !== null
            ? ((m = m.index), m < p ? ((h.flags |= 2), p) : m)
            : ((h.flags |= 2), p))
        : ((h.flags |= 1048576), p)
    );
  }
  function s(h) {
    return e && h.alternate === null && (h.flags |= 2), h;
  }
  function l(h, p, m, k) {
    return p === null || p.tag !== 6
      ? ((p = Rl(m, h.mode, k)), (p.return = h), p)
      : ((p = o(p, m)), (p.return = h), p);
  }
  function a(h, p, m, k) {
    var E = m.type;
    return E === cr
      ? d(h, p, m.props.children, k, m.key)
      : p !== null &&
        (p.elementType === E ||
          (typeof E == "object" &&
            E !== null &&
            E.$$typeof === sn &&
            qc(E) === p.type))
      ? ((k = o(p, m.props)), (k.ref = so(h, p, m)), (k.return = h), k)
      : ((k = Vi(m.type, m.key, m.props, null, h.mode, k)),
        (k.ref = so(h, p, m)),
        (k.return = h),
        k);
  }
  function u(h, p, m, k) {
    return p === null ||
      p.tag !== 4 ||
      p.stateNode.containerInfo !== m.containerInfo ||
      p.stateNode.implementation !== m.implementation
      ? ((p = Al(m, h.mode, k)), (p.return = h), p)
      : ((p = o(p, m.children || [])), (p.return = h), p);
  }
  function d(h, p, m, k, E) {
    return p === null || p.tag !== 7
      ? ((p = Kn(m, h.mode, k, E)), (p.return = h), p)
      : ((p = o(p, m)), (p.return = h), p);
  }
  function f(h, p, m) {
    if ((typeof p == "string" && p !== "") || typeof p == "number")
      return (p = Rl("" + p, h.mode, m)), (p.return = h), p;
    if (typeof p == "object" && p !== null) {
      switch (p.$$typeof) {
        case fi:
          return (
            (m = Vi(p.type, p.key, p.props, null, h.mode, m)),
            (m.ref = so(h, null, p)),
            (m.return = h),
            m
          );
        case ur:
          return (p = Al(p, h.mode, m)), (p.return = h), p;
        case sn:
          var k = p._init;
          return f(h, k(p._payload), m);
      }
      if (po(p) || to(p))
        return (p = Kn(p, h.mode, m, null)), (p.return = h), p;
      Ei(h, p);
    }
    return null;
  }
  function c(h, p, m, k) {
    var E = p !== null ? p.key : null;
    if ((typeof m == "string" && m !== "") || typeof m == "number")
      return E !== null ? null : l(h, p, "" + m, k);
    if (typeof m == "object" && m !== null) {
      switch (m.$$typeof) {
        case fi:
          return m.key === E ? a(h, p, m, k) : null;
        case ur:
          return m.key === E ? u(h, p, m, k) : null;
        case sn:
          return (E = m._init), c(h, p, E(m._payload), k);
      }
      if (po(m) || to(m)) return E !== null ? null : d(h, p, m, k, null);
      Ei(h, m);
    }
    return null;
  }
  function v(h, p, m, k, E) {
    if ((typeof k == "string" && k !== "") || typeof k == "number")
      return (h = h.get(m) || null), l(p, h, "" + k, E);
    if (typeof k == "object" && k !== null) {
      switch (k.$$typeof) {
        case fi:
          return (h = h.get(k.key === null ? m : k.key) || null), a(p, h, k, E);
        case ur:
          return (h = h.get(k.key === null ? m : k.key) || null), u(p, h, k, E);
        case sn:
          var b = k._init;
          return v(h, p, m, b(k._payload), E);
      }
      if (po(k) || to(k)) return (h = h.get(m) || null), d(p, h, k, E, null);
      Ei(p, k);
    }
    return null;
  }
  function x(h, p, m, k) {
    for (
      var E = null, b = null, P = p, T = (p = 0), I = null;
      P !== null && T < m.length;
      T++
    ) {
      P.index > T ? ((I = P), (P = null)) : (I = P.sibling);
      var _ = c(h, P, m[T], k);
      if (_ === null) {
        P === null && (P = I);
        break;
      }
      e && P && _.alternate === null && t(h, P),
        (p = i(_, p, T)),
        b === null ? (E = _) : (b.sibling = _),
        (b = _),
        (P = I);
    }
    if (T === m.length) return n(h, P), se && Dn(h, T), E;
    if (P === null) {
      for (; T < m.length; T++)
        (P = f(h, m[T], k)),
          P !== null &&
            ((p = i(P, p, T)), b === null ? (E = P) : (b.sibling = P), (b = P));
      return se && Dn(h, T), E;
    }
    for (P = r(h, P); T < m.length; T++)
      (I = v(P, h, T, m[T], k)),
        I !== null &&
          (e && I.alternate !== null && P.delete(I.key === null ? T : I.key),
          (p = i(I, p, T)),
          b === null ? (E = I) : (b.sibling = I),
          (b = I));
    return (
      e &&
        P.forEach(function ($) {
          return t(h, $);
        }),
      se && Dn(h, T),
      E
    );
  }
  function g(h, p, m, k) {
    var E = to(m);
    if (typeof E != "function") throw Error(R(150));
    if (((m = E.call(m)), m == null)) throw Error(R(151));
    for (
      var b = (E = null), P = p, T = (p = 0), I = null, _ = m.next();
      P !== null && !_.done;
      T++, _ = m.next()
    ) {
      P.index > T ? ((I = P), (P = null)) : (I = P.sibling);
      var $ = c(h, P, _.value, k);
      if ($ === null) {
        P === null && (P = I);
        break;
      }
      e && P && $.alternate === null && t(h, P),
        (p = i($, p, T)),
        b === null ? (E = $) : (b.sibling = $),
        (b = $),
        (P = I);
    }
    if (_.done) return n(h, P), se && Dn(h, T), E;
    if (P === null) {
      for (; !_.done; T++, _ = m.next())
        (_ = f(h, _.value, k)),
          _ !== null &&
            ((p = i(_, p, T)), b === null ? (E = _) : (b.sibling = _), (b = _));
      return se && Dn(h, T), E;
    }
    for (P = r(h, P); !_.done; T++, _ = m.next())
      (_ = v(P, h, T, _.value, k)),
        _ !== null &&
          (e && _.alternate !== null && P.delete(_.key === null ? T : _.key),
          (p = i(_, p, T)),
          b === null ? (E = _) : (b.sibling = _),
          (b = _));
    return (
      e &&
        P.forEach(function (D) {
          return t(h, D);
        }),
      se && Dn(h, T),
      E
    );
  }
  function S(h, p, m, k) {
    if (
      (typeof m == "object" &&
        m !== null &&
        m.type === cr &&
        m.key === null &&
        (m = m.props.children),
      typeof m == "object" && m !== null)
    ) {
      switch (m.$$typeof) {
        case fi:
          e: {
            for (var E = m.key, b = p; b !== null; ) {
              if (b.key === E) {
                if (((E = m.type), E === cr)) {
                  if (b.tag === 7) {
                    n(h, b.sibling),
                      (p = o(b, m.props.children)),
                      (p.return = h),
                      (h = p);
                    break e;
                  }
                } else if (
                  b.elementType === E ||
                  (typeof E == "object" &&
                    E !== null &&
                    E.$$typeof === sn &&
                    qc(E) === b.type)
                ) {
                  n(h, b.sibling),
                    (p = o(b, m.props)),
                    (p.ref = so(h, b, m)),
                    (p.return = h),
                    (h = p);
                  break e;
                }
                n(h, b);
                break;
              } else t(h, b);
              b = b.sibling;
            }
            m.type === cr
              ? ((p = Kn(m.props.children, h.mode, k, m.key)),
                (p.return = h),
                (h = p))
              : ((k = Vi(m.type, m.key, m.props, null, h.mode, k)),
                (k.ref = so(h, p, m)),
                (k.return = h),
                (h = k));
          }
          return s(h);
        case ur:
          e: {
            for (b = m.key; p !== null; ) {
              if (p.key === b)
                if (
                  p.tag === 4 &&
                  p.stateNode.containerInfo === m.containerInfo &&
                  p.stateNode.implementation === m.implementation
                ) {
                  n(h, p.sibling),
                    (p = o(p, m.children || [])),
                    (p.return = h),
                    (h = p);
                  break e;
                } else {
                  n(h, p);
                  break;
                }
              else t(h, p);
              p = p.sibling;
            }
            (p = Al(m, h.mode, k)), (p.return = h), (h = p);
          }
          return s(h);
        case sn:
          return (b = m._init), S(h, p, b(m._payload), k);
      }
      if (po(m)) return x(h, p, m, k);
      if (to(m)) return g(h, p, m, k);
      Ei(h, m);
    }
    return (typeof m == "string" && m !== "") || typeof m == "number"
      ? ((m = "" + m),
        p !== null && p.tag === 6
          ? (n(h, p.sibling), (p = o(p, m)), (p.return = h), (h = p))
          : (n(h, p), (p = Rl(m, h.mode, k)), (p.return = h), (h = p)),
        s(h))
      : n(h, p);
  }
  return S;
}
var Ur = Tp(!0),
  Rp = Tp(!1),
  as = Mn(null),
  us = null,
  yr = null,
  vu = null;
function yu() {
  vu = yr = us = null;
}
function xu(e) {
  var t = as.current;
  ie(as), (e._currentValue = t);
}
function ma(e, t, n) {
  for (; e !== null; ) {
    var r = e.alternate;
    if (
      ((e.childLanes & t) !== t
        ? ((e.childLanes |= t), r !== null && (r.childLanes |= t))
        : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
      e === n)
    )
      break;
    e = e.return;
  }
}
function br(e, t) {
  (us = e),
    (vu = yr = null),
    (e = e.dependencies),
    e !== null &&
      e.firstContext !== null &&
      (e.lanes & t && ($e = !0), (e.firstContext = null));
}
function st(e) {
  var t = e._currentValue;
  if (vu !== e)
    if (((e = { context: e, memoizedValue: t, next: null }), yr === null)) {
      if (us === null) throw Error(R(308));
      (yr = e), (us.dependencies = { lanes: 0, firstContext: e });
    } else yr = yr.next = e;
  return t;
}
var $n = null;
function wu(e) {
  $n === null ? ($n = [e]) : $n.push(e);
}
function Ap(e, t, n, r) {
  var o = t.interleaved;
  return (
    o === null ? ((n.next = n), wu(t)) : ((n.next = o.next), (o.next = n)),
    (t.interleaved = n),
    Vt(e, r)
  );
}
function Vt(e, t) {
  e.lanes |= t;
  var n = e.alternate;
  for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null; )
    (e.childLanes |= t),
      (n = e.alternate),
      n !== null && (n.childLanes |= t),
      (n = e),
      (e = e.return);
  return n.tag === 3 ? n.stateNode : null;
}
var ln = !1;
function Su(e) {
  e.updateQueue = {
    baseState: e.memoizedState,
    firstBaseUpdate: null,
    lastBaseUpdate: null,
    shared: { pending: null, interleaved: null, lanes: 0 },
    effects: null,
  };
}
function jp(e, t) {
  (e = e.updateQueue),
    t.updateQueue === e &&
      (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects,
      });
}
function Ut(e, t) {
  return {
    eventTime: e,
    lane: t,
    tag: 0,
    payload: null,
    callback: null,
    next: null,
  };
}
function kn(e, t, n) {
  var r = e.updateQueue;
  if (r === null) return null;
  if (((r = r.shared), X & 2)) {
    var o = r.pending;
    return (
      o === null ? (t.next = t) : ((t.next = o.next), (o.next = t)),
      (r.pending = t),
      Vt(e, n)
    );
  }
  return (
    (o = r.interleaved),
    o === null ? ((t.next = t), wu(r)) : ((t.next = o.next), (o.next = t)),
    (r.interleaved = t),
    Vt(e, n)
  );
}
function zi(e, t, n) {
  if (
    ((t = t.updateQueue), t !== null && ((t = t.shared), (n & 4194240) !== 0))
  ) {
    var r = t.lanes;
    (r &= e.pendingLanes), (n |= r), (t.lanes = n), su(e, n);
  }
}
function Jc(e, t) {
  var n = e.updateQueue,
    r = e.alternate;
  if (r !== null && ((r = r.updateQueue), n === r)) {
    var o = null,
      i = null;
    if (((n = n.firstBaseUpdate), n !== null)) {
      do {
        var s = {
          eventTime: n.eventTime,
          lane: n.lane,
          tag: n.tag,
          payload: n.payload,
          callback: n.callback,
          next: null,
        };
        i === null ? (o = i = s) : (i = i.next = s), (n = n.next);
      } while (n !== null);
      i === null ? (o = i = t) : (i = i.next = t);
    } else o = i = t;
    (n = {
      baseState: r.baseState,
      firstBaseUpdate: o,
      lastBaseUpdate: i,
      shared: r.shared,
      effects: r.effects,
    }),
      (e.updateQueue = n);
    return;
  }
  (e = n.lastBaseUpdate),
    e === null ? (n.firstBaseUpdate = t) : (e.next = t),
    (n.lastBaseUpdate = t);
}
function cs(e, t, n, r) {
  var o = e.updateQueue;
  ln = !1;
  var i = o.firstBaseUpdate,
    s = o.lastBaseUpdate,
    l = o.shared.pending;
  if (l !== null) {
    o.shared.pending = null;
    var a = l,
      u = a.next;
    (a.next = null), s === null ? (i = u) : (s.next = u), (s = a);
    var d = e.alternate;
    d !== null &&
      ((d = d.updateQueue),
      (l = d.lastBaseUpdate),
      l !== s &&
        (l === null ? (d.firstBaseUpdate = u) : (l.next = u),
        (d.lastBaseUpdate = a)));
  }
  if (i !== null) {
    var f = o.baseState;
    (s = 0), (d = u = a = null), (l = i);
    do {
      var c = l.lane,
        v = l.eventTime;
      if ((r & c) === c) {
        d !== null &&
          (d = d.next =
            {
              eventTime: v,
              lane: 0,
              tag: l.tag,
              payload: l.payload,
              callback: l.callback,
              next: null,
            });
        e: {
          var x = e,
            g = l;
          switch (((c = t), (v = n), g.tag)) {
            case 1:
              if (((x = g.payload), typeof x == "function")) {
                f = x.call(v, f, c);
                break e;
              }
              f = x;
              break e;
            case 3:
              x.flags = (x.flags & -65537) | 128;
            case 0:
              if (
                ((x = g.payload),
                (c = typeof x == "function" ? x.call(v, f, c) : x),
                c == null)
              )
                break e;
              f = ce({}, f, c);
              break e;
            case 2:
              ln = !0;
          }
        }
        l.callback !== null &&
          l.lane !== 0 &&
          ((e.flags |= 64),
          (c = o.effects),
          c === null ? (o.effects = [l]) : c.push(l));
      } else
        (v = {
          eventTime: v,
          lane: c,
          tag: l.tag,
          payload: l.payload,
          callback: l.callback,
          next: null,
        }),
          d === null ? ((u = d = v), (a = f)) : (d = d.next = v),
          (s |= c);
      if (((l = l.next), l === null)) {
        if (((l = o.shared.pending), l === null)) break;
        (c = l),
          (l = c.next),
          (c.next = null),
          (o.lastBaseUpdate = c),
          (o.shared.pending = null);
      }
    } while (!0);
    if (
      (d === null && (a = f),
      (o.baseState = a),
      (o.firstBaseUpdate = u),
      (o.lastBaseUpdate = d),
      (t = o.shared.interleaved),
      t !== null)
    ) {
      o = t;
      do (s |= o.lane), (o = o.next);
      while (o !== t);
    } else i === null && (o.shared.lanes = 0);
    (qn |= s), (e.lanes = s), (e.memoizedState = f);
  }
}
function Zc(e, t, n) {
  if (((e = t.effects), (t.effects = null), e !== null))
    for (t = 0; t < e.length; t++) {
      var r = e[t],
        o = r.callback;
      if (o !== null) {
        if (((r.callback = null), (r = n), typeof o != "function"))
          throw Error(R(191, o));
        o.call(r);
      }
    }
}
var ti = {},
  jt = Mn(ti),
  Do = Mn(ti),
  zo = Mn(ti);
function Un(e) {
  if (e === ti) throw Error(R(174));
  return e;
}
function ku(e, t) {
  switch ((te(zo, t), te(Do, e), te(jt, ti), (e = t.nodeType), e)) {
    case 9:
    case 11:
      t = (t = t.documentElement) ? t.namespaceURI : Yl(null, "");
      break;
    default:
      (e = e === 8 ? t.parentNode : t),
        (t = e.namespaceURI || null),
        (e = e.tagName),
        (t = Yl(t, e));
  }
  ie(jt), te(jt, t);
}
function Br() {
  ie(jt), ie(Do), ie(zo);
}
function _p(e) {
  Un(zo.current);
  var t = Un(jt.current),
    n = Yl(t, e.type);
  t !== n && (te(Do, e), te(jt, n));
}
function Eu(e) {
  Do.current === e && (ie(jt), ie(Do));
}
var ae = Mn(0);
function ds(e) {
  for (var t = e; t !== null; ) {
    if (t.tag === 13) {
      var n = t.memoizedState;
      if (
        n !== null &&
        ((n = n.dehydrated), n === null || n.data === "$?" || n.data === "$!")
      )
        return t;
    } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
      if (t.flags & 128) return t;
    } else if (t.child !== null) {
      (t.child.return = t), (t = t.child);
      continue;
    }
    if (t === e) break;
    for (; t.sibling === null; ) {
      if (t.return === null || t.return === e) return null;
      t = t.return;
    }
    (t.sibling.return = t.return), (t = t.sibling);
  }
  return null;
}
var El = [];
function Cu() {
  for (var e = 0; e < El.length; e++)
    El[e]._workInProgressVersionPrimary = null;
  El.length = 0;
}
var Fi = Yt.ReactCurrentDispatcher,
  Cl = Yt.ReactCurrentBatchConfig,
  Xn = 0,
  ue = null,
  ge = null,
  xe = null,
  fs = !1,
  So = !1,
  Fo = 0,
  Cv = 0;
function Te() {
  throw Error(R(321));
}
function bu(e, t) {
  if (t === null) return !1;
  for (var n = 0; n < t.length && n < e.length; n++)
    if (!vt(e[n], t[n])) return !1;
  return !0;
}
function Pu(e, t, n, r, o, i) {
  if (
    ((Xn = i),
    (ue = t),
    (t.memoizedState = null),
    (t.updateQueue = null),
    (t.lanes = 0),
    (Fi.current = e === null || e.memoizedState === null ? Tv : Rv),
    (e = n(r, o)),
    So)
  ) {
    i = 0;
    do {
      if (((So = !1), (Fo = 0), 25 <= i)) throw Error(R(301));
      (i += 1),
        (xe = ge = null),
        (t.updateQueue = null),
        (Fi.current = Av),
        (e = n(r, o));
    } while (So);
  }
  if (
    ((Fi.current = ps),
    (t = ge !== null && ge.next !== null),
    (Xn = 0),
    (xe = ge = ue = null),
    (fs = !1),
    t)
  )
    throw Error(R(300));
  return e;
}
function Nu() {
  var e = Fo !== 0;
  return (Fo = 0), e;
}
function bt() {
  var e = {
    memoizedState: null,
    baseState: null,
    baseQueue: null,
    queue: null,
    next: null,
  };
  return xe === null ? (ue.memoizedState = xe = e) : (xe = xe.next = e), xe;
}
function lt() {
  if (ge === null) {
    var e = ue.alternate;
    e = e !== null ? e.memoizedState : null;
  } else e = ge.next;
  var t = xe === null ? ue.memoizedState : xe.next;
  if (t !== null) (xe = t), (ge = e);
  else {
    if (e === null) throw Error(R(310));
    (ge = e),
      (e = {
        memoizedState: ge.memoizedState,
        baseState: ge.baseState,
        baseQueue: ge.baseQueue,
        queue: ge.queue,
        next: null,
      }),
      xe === null ? (ue.memoizedState = xe = e) : (xe = xe.next = e);
  }
  return xe;
}
function $o(e, t) {
  return typeof t == "function" ? t(e) : t;
}
function bl(e) {
  var t = lt(),
    n = t.queue;
  if (n === null) throw Error(R(311));
  n.lastRenderedReducer = e;
  var r = ge,
    o = r.baseQueue,
    i = n.pending;
  if (i !== null) {
    if (o !== null) {
      var s = o.next;
      (o.next = i.next), (i.next = s);
    }
    (r.baseQueue = o = i), (n.pending = null);
  }
  if (o !== null) {
    (i = o.next), (r = r.baseState);
    var l = (s = null),
      a = null,
      u = i;
    do {
      var d = u.lane;
      if ((Xn & d) === d)
        a !== null &&
          (a = a.next =
            {
              lane: 0,
              action: u.action,
              hasEagerState: u.hasEagerState,
              eagerState: u.eagerState,
              next: null,
            }),
          (r = u.hasEagerState ? u.eagerState : e(r, u.action));
      else {
        var f = {
          lane: d,
          action: u.action,
          hasEagerState: u.hasEagerState,
          eagerState: u.eagerState,
          next: null,
        };
        a === null ? ((l = a = f), (s = r)) : (a = a.next = f),
          (ue.lanes |= d),
          (qn |= d);
      }
      u = u.next;
    } while (u !== null && u !== i);
    a === null ? (s = r) : (a.next = l),
      vt(r, t.memoizedState) || ($e = !0),
      (t.memoizedState = r),
      (t.baseState = s),
      (t.baseQueue = a),
      (n.lastRenderedState = r);
  }
  if (((e = n.interleaved), e !== null)) {
    o = e;
    do (i = o.lane), (ue.lanes |= i), (qn |= i), (o = o.next);
    while (o !== e);
  } else o === null && (n.lanes = 0);
  return [t.memoizedState, n.dispatch];
}
function Pl(e) {
  var t = lt(),
    n = t.queue;
  if (n === null) throw Error(R(311));
  n.lastRenderedReducer = e;
  var r = n.dispatch,
    o = n.pending,
    i = t.memoizedState;
  if (o !== null) {
    n.pending = null;
    var s = (o = o.next);
    do (i = e(i, s.action)), (s = s.next);
    while (s !== o);
    vt(i, t.memoizedState) || ($e = !0),
      (t.memoizedState = i),
      t.baseQueue === null && (t.baseState = i),
      (n.lastRenderedState = i);
  }
  return [i, r];
}
function Op() {}
function Mp(e, t) {
  var n = ue,
    r = lt(),
    o = t(),
    i = !vt(r.memoizedState, o);
  if (
    (i && ((r.memoizedState = o), ($e = !0)),
    (r = r.queue),
    Tu(Dp.bind(null, n, r, e), [e]),
    r.getSnapshot !== t || i || (xe !== null && xe.memoizedState.tag & 1))
  ) {
    if (
      ((n.flags |= 2048),
      Uo(9, Ip.bind(null, n, r, o, t), void 0, null),
      we === null)
    )
      throw Error(R(349));
    Xn & 30 || Lp(n, t, o);
  }
  return o;
}
function Lp(e, t, n) {
  (e.flags |= 16384),
    (e = { getSnapshot: t, value: n }),
    (t = ue.updateQueue),
    t === null
      ? ((t = { lastEffect: null, stores: null }),
        (ue.updateQueue = t),
        (t.stores = [e]))
      : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e));
}
function Ip(e, t, n, r) {
  (t.value = n), (t.getSnapshot = r), zp(t) && Fp(e);
}
function Dp(e, t, n) {
  return n(function () {
    zp(t) && Fp(e);
  });
}
function zp(e) {
  var t = e.getSnapshot;
  e = e.value;
  try {
    var n = t();
    return !vt(e, n);
  } catch {
    return !0;
  }
}
function Fp(e) {
  var t = Vt(e, 1);
  t !== null && gt(t, e, 1, -1);
}
function ed(e) {
  var t = bt();
  return (
    typeof e == "function" && (e = e()),
    (t.memoizedState = t.baseState = e),
    (e = {
      pending: null,
      interleaved: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: $o,
      lastRenderedState: e,
    }),
    (t.queue = e),
    (e = e.dispatch = Nv.bind(null, ue, e)),
    [t.memoizedState, e]
  );
}
function Uo(e, t, n, r) {
  return (
    (e = { tag: e, create: t, destroy: n, deps: r, next: null }),
    (t = ue.updateQueue),
    t === null
      ? ((t = { lastEffect: null, stores: null }),
        (ue.updateQueue = t),
        (t.lastEffect = e.next = e))
      : ((n = t.lastEffect),
        n === null
          ? (t.lastEffect = e.next = e)
          : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e))),
    e
  );
}
function $p() {
  return lt().memoizedState;
}
function $i(e, t, n, r) {
  var o = bt();
  (ue.flags |= e),
    (o.memoizedState = Uo(1 | t, n, void 0, r === void 0 ? null : r));
}
function Ms(e, t, n, r) {
  var o = lt();
  r = r === void 0 ? null : r;
  var i = void 0;
  if (ge !== null) {
    var s = ge.memoizedState;
    if (((i = s.destroy), r !== null && bu(r, s.deps))) {
      o.memoizedState = Uo(t, n, i, r);
      return;
    }
  }
  (ue.flags |= e), (o.memoizedState = Uo(1 | t, n, i, r));
}
function td(e, t) {
  return $i(8390656, 8, e, t);
}
function Tu(e, t) {
  return Ms(2048, 8, e, t);
}
function Up(e, t) {
  return Ms(4, 2, e, t);
}
function Bp(e, t) {
  return Ms(4, 4, e, t);
}
function Wp(e, t) {
  if (typeof t == "function")
    return (
      (e = e()),
      t(e),
      function () {
        t(null);
      }
    );
  if (t != null)
    return (
      (e = e()),
      (t.current = e),
      function () {
        t.current = null;
      }
    );
}
function Vp(e, t, n) {
  return (
    (n = n != null ? n.concat([e]) : null), Ms(4, 4, Wp.bind(null, t, e), n)
  );
}
function Ru() {}
function Hp(e, t) {
  var n = lt();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && bu(t, r[1])
    ? r[0]
    : ((n.memoizedState = [e, t]), e);
}
function Qp(e, t) {
  var n = lt();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && bu(t, r[1])
    ? r[0]
    : ((e = e()), (n.memoizedState = [e, t]), e);
}
function Kp(e, t, n) {
  return Xn & 21
    ? (vt(n, t) || ((n = Jf()), (ue.lanes |= n), (qn |= n), (e.baseState = !0)),
      t)
    : (e.baseState && ((e.baseState = !1), ($e = !0)), (e.memoizedState = n));
}
function bv(e, t) {
  var n = Z;
  (Z = n !== 0 && 4 > n ? n : 4), e(!0);
  var r = Cl.transition;
  Cl.transition = {};
  try {
    e(!1), t();
  } finally {
    (Z = n), (Cl.transition = r);
  }
}
function Gp() {
  return lt().memoizedState;
}
function Pv(e, t, n) {
  var r = Cn(e);
  if (
    ((n = {
      lane: r,
      action: n,
      hasEagerState: !1,
      eagerState: null,
      next: null,
    }),
    Yp(e))
  )
    Xp(t, n);
  else if (((n = Ap(e, t, n, r)), n !== null)) {
    var o = Ie();
    gt(n, e, r, o), qp(n, t, r);
  }
}
function Nv(e, t, n) {
  var r = Cn(e),
    o = { lane: r, action: n, hasEagerState: !1, eagerState: null, next: null };
  if (Yp(e)) Xp(t, o);
  else {
    var i = e.alternate;
    if (
      e.lanes === 0 &&
      (i === null || i.lanes === 0) &&
      ((i = t.lastRenderedReducer), i !== null)
    )
      try {
        var s = t.lastRenderedState,
          l = i(s, n);
        if (((o.hasEagerState = !0), (o.eagerState = l), vt(l, s))) {
          var a = t.interleaved;
          a === null
            ? ((o.next = o), wu(t))
            : ((o.next = a.next), (a.next = o)),
            (t.interleaved = o);
          return;
        }
      } catch {
      } finally {
      }
    (n = Ap(e, t, o, r)),
      n !== null && ((o = Ie()), gt(n, e, r, o), qp(n, t, r));
  }
}
function Yp(e) {
  var t = e.alternate;
  return e === ue || (t !== null && t === ue);
}
function Xp(e, t) {
  So = fs = !0;
  var n = e.pending;
  n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
    (e.pending = t);
}
function qp(e, t, n) {
  if (n & 4194240) {
    var r = t.lanes;
    (r &= e.pendingLanes), (n |= r), (t.lanes = n), su(e, n);
  }
}
var ps = {
    readContext: st,
    useCallback: Te,
    useContext: Te,
    useEffect: Te,
    useImperativeHandle: Te,
    useInsertionEffect: Te,
    useLayoutEffect: Te,
    useMemo: Te,
    useReducer: Te,
    useRef: Te,
    useState: Te,
    useDebugValue: Te,
    useDeferredValue: Te,
    useTransition: Te,
    useMutableSource: Te,
    useSyncExternalStore: Te,
    useId: Te,
    unstable_isNewReconciler: !1,
  },
  Tv = {
    readContext: st,
    useCallback: function (e, t) {
      return (bt().memoizedState = [e, t === void 0 ? null : t]), e;
    },
    useContext: st,
    useEffect: td,
    useImperativeHandle: function (e, t, n) {
      return (
        (n = n != null ? n.concat([e]) : null),
        $i(4194308, 4, Wp.bind(null, t, e), n)
      );
    },
    useLayoutEffect: function (e, t) {
      return $i(4194308, 4, e, t);
    },
    useInsertionEffect: function (e, t) {
      return $i(4, 2, e, t);
    },
    useMemo: function (e, t) {
      var n = bt();
      return (
        (t = t === void 0 ? null : t), (e = e()), (n.memoizedState = [e, t]), e
      );
    },
    useReducer: function (e, t, n) {
      var r = bt();
      return (
        (t = n !== void 0 ? n(t) : t),
        (r.memoizedState = r.baseState = t),
        (e = {
          pending: null,
          interleaved: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: e,
          lastRenderedState: t,
        }),
        (r.queue = e),
        (e = e.dispatch = Pv.bind(null, ue, e)),
        [r.memoizedState, e]
      );
    },
    useRef: function (e) {
      var t = bt();
      return (e = { current: e }), (t.memoizedState = e);
    },
    useState: ed,
    useDebugValue: Ru,
    useDeferredValue: function (e) {
      return (bt().memoizedState = e);
    },
    useTransition: function () {
      var e = ed(!1),
        t = e[0];
      return (e = bv.bind(null, e[1])), (bt().memoizedState = e), [t, e];
    },
    useMutableSource: function () {},
    useSyncExternalStore: function (e, t, n) {
      var r = ue,
        o = bt();
      if (se) {
        if (n === void 0) throw Error(R(407));
        n = n();
      } else {
        if (((n = t()), we === null)) throw Error(R(349));
        Xn & 30 || Lp(r, t, n);
      }
      o.memoizedState = n;
      var i = { value: n, getSnapshot: t };
      return (
        (o.queue = i),
        td(Dp.bind(null, r, i, e), [e]),
        (r.flags |= 2048),
        Uo(9, Ip.bind(null, r, i, n, t), void 0, null),
        n
      );
    },
    useId: function () {
      var e = bt(),
        t = we.identifierPrefix;
      if (se) {
        var n = $t,
          r = Ft;
        (n = (r & ~(1 << (32 - mt(r) - 1))).toString(32) + n),
          (t = ":" + t + "R" + n),
          (n = Fo++),
          0 < n && (t += "H" + n.toString(32)),
          (t += ":");
      } else (n = Cv++), (t = ":" + t + "r" + n.toString(32) + ":");
      return (e.memoizedState = t);
    },
    unstable_isNewReconciler: !1,
  },
  Rv = {
    readContext: st,
    useCallback: Hp,
    useContext: st,
    useEffect: Tu,
    useImperativeHandle: Vp,
    useInsertionEffect: Up,
    useLayoutEffect: Bp,
    useMemo: Qp,
    useReducer: bl,
    useRef: $p,
    useState: function () {
      return bl($o);
    },
    useDebugValue: Ru,
    useDeferredValue: function (e) {
      var t = lt();
      return Kp(t, ge.memoizedState, e);
    },
    useTransition: function () {
      var e = bl($o)[0],
        t = lt().memoizedState;
      return [e, t];
    },
    useMutableSource: Op,
    useSyncExternalStore: Mp,
    useId: Gp,
    unstable_isNewReconciler: !1,
  },
  Av = {
    readContext: st,
    useCallback: Hp,
    useContext: st,
    useEffect: Tu,
    useImperativeHandle: Vp,
    useInsertionEffect: Up,
    useLayoutEffect: Bp,
    useMemo: Qp,
    useReducer: Pl,
    useRef: $p,
    useState: function () {
      return Pl($o);
    },
    useDebugValue: Ru,
    useDeferredValue: function (e) {
      var t = lt();
      return ge === null ? (t.memoizedState = e) : Kp(t, ge.memoizedState, e);
    },
    useTransition: function () {
      var e = Pl($o)[0],
        t = lt().memoizedState;
      return [e, t];
    },
    useMutableSource: Op,
    useSyncExternalStore: Mp,
    useId: Gp,
    unstable_isNewReconciler: !1,
  };
function ct(e, t) {
  if (e && e.defaultProps) {
    (t = ce({}, t)), (e = e.defaultProps);
    for (var n in e) t[n] === void 0 && (t[n] = e[n]);
    return t;
  }
  return t;
}
function ga(e, t, n, r) {
  (t = e.memoizedState),
    (n = n(r, t)),
    (n = n == null ? t : ce({}, t, n)),
    (e.memoizedState = n),
    e.lanes === 0 && (e.updateQueue.baseState = n);
}
var Ls = {
  isMounted: function (e) {
    return (e = e._reactInternals) ? tr(e) === e : !1;
  },
  enqueueSetState: function (e, t, n) {
    e = e._reactInternals;
    var r = Ie(),
      o = Cn(e),
      i = Ut(r, o);
    (i.payload = t),
      n != null && (i.callback = n),
      (t = kn(e, i, o)),
      t !== null && (gt(t, e, o, r), zi(t, e, o));
  },
  enqueueReplaceState: function (e, t, n) {
    e = e._reactInternals;
    var r = Ie(),
      o = Cn(e),
      i = Ut(r, o);
    (i.tag = 1),
      (i.payload = t),
      n != null && (i.callback = n),
      (t = kn(e, i, o)),
      t !== null && (gt(t, e, o, r), zi(t, e, o));
  },
  enqueueForceUpdate: function (e, t) {
    e = e._reactInternals;
    var n = Ie(),
      r = Cn(e),
      o = Ut(n, r);
    (o.tag = 2),
      t != null && (o.callback = t),
      (t = kn(e, o, r)),
      t !== null && (gt(t, e, r, n), zi(t, e, r));
  },
};
function nd(e, t, n, r, o, i, s) {
  return (
    (e = e.stateNode),
    typeof e.shouldComponentUpdate == "function"
      ? e.shouldComponentUpdate(r, i, s)
      : t.prototype && t.prototype.isPureReactComponent
      ? !Oo(n, r) || !Oo(o, i)
      : !0
  );
}
function Jp(e, t, n) {
  var r = !1,
    o = Tn,
    i = t.contextType;
  return (
    typeof i == "object" && i !== null
      ? (i = st(i))
      : ((o = Be(t) ? Gn : _e.current),
        (r = t.contextTypes),
        (i = (r = r != null) ? Fr(e, o) : Tn)),
    (t = new t(n, i)),
    (e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null),
    (t.updater = Ls),
    (e.stateNode = t),
    (t._reactInternals = e),
    r &&
      ((e = e.stateNode),
      (e.__reactInternalMemoizedUnmaskedChildContext = o),
      (e.__reactInternalMemoizedMaskedChildContext = i)),
    t
  );
}
function rd(e, t, n, r) {
  (e = t.state),
    typeof t.componentWillReceiveProps == "function" &&
      t.componentWillReceiveProps(n, r),
    typeof t.UNSAFE_componentWillReceiveProps == "function" &&
      t.UNSAFE_componentWillReceiveProps(n, r),
    t.state !== e && Ls.enqueueReplaceState(t, t.state, null);
}
function va(e, t, n, r) {
  var o = e.stateNode;
  (o.props = n), (o.state = e.memoizedState), (o.refs = {}), Su(e);
  var i = t.contextType;
  typeof i == "object" && i !== null
    ? (o.context = st(i))
    : ((i = Be(t) ? Gn : _e.current), (o.context = Fr(e, i))),
    (o.state = e.memoizedState),
    (i = t.getDerivedStateFromProps),
    typeof i == "function" && (ga(e, t, i, n), (o.state = e.memoizedState)),
    typeof t.getDerivedStateFromProps == "function" ||
      typeof o.getSnapshotBeforeUpdate == "function" ||
      (typeof o.UNSAFE_componentWillMount != "function" &&
        typeof o.componentWillMount != "function") ||
      ((t = o.state),
      typeof o.componentWillMount == "function" && o.componentWillMount(),
      typeof o.UNSAFE_componentWillMount == "function" &&
        o.UNSAFE_componentWillMount(),
      t !== o.state && Ls.enqueueReplaceState(o, o.state, null),
      cs(e, n, o, r),
      (o.state = e.memoizedState)),
    typeof o.componentDidMount == "function" && (e.flags |= 4194308);
}
function Wr(e, t) {
  try {
    var n = "",
      r = t;
    do (n += o0(r)), (r = r.return);
    while (r);
    var o = n;
  } catch (i) {
    o =
      `
Error generating stack: ` +
      i.message +
      `
` +
      i.stack;
  }
  return { value: e, source: t, stack: o, digest: null };
}
function Nl(e, t, n) {
  return { value: e, source: null, stack: n ?? null, digest: t ?? null };
}
function ya(e, t) {
  try {
    console.error(t.value);
  } catch (n) {
    setTimeout(function () {
      throw n;
    });
  }
}
var jv = typeof WeakMap == "function" ? WeakMap : Map;
function Zp(e, t, n) {
  (n = Ut(-1, n)), (n.tag = 3), (n.payload = { element: null });
  var r = t.value;
  return (
    (n.callback = function () {
      ms || ((ms = !0), (Ta = r)), ya(e, t);
    }),
    n
  );
}
function eh(e, t, n) {
  (n = Ut(-1, n)), (n.tag = 3);
  var r = e.type.getDerivedStateFromError;
  if (typeof r == "function") {
    var o = t.value;
    (n.payload = function () {
      return r(o);
    }),
      (n.callback = function () {
        ya(e, t);
      });
  }
  var i = e.stateNode;
  return (
    i !== null &&
      typeof i.componentDidCatch == "function" &&
      (n.callback = function () {
        ya(e, t),
          typeof r != "function" &&
            (En === null ? (En = new Set([this])) : En.add(this));
        var s = t.stack;
        this.componentDidCatch(t.value, {
          componentStack: s !== null ? s : "",
        });
      }),
    n
  );
}
function od(e, t, n) {
  var r = e.pingCache;
  if (r === null) {
    r = e.pingCache = new jv();
    var o = new Set();
    r.set(t, o);
  } else (o = r.get(t)), o === void 0 && ((o = new Set()), r.set(t, o));
  o.has(n) || (o.add(n), (e = Hv.bind(null, e, t, n)), t.then(e, e));
}
function id(e) {
  do {
    var t;
    if (
      ((t = e.tag === 13) &&
        ((t = e.memoizedState), (t = t !== null ? t.dehydrated !== null : !0)),
      t)
    )
      return e;
    e = e.return;
  } while (e !== null);
  return null;
}
function sd(e, t, n, r, o) {
  return e.mode & 1
    ? ((e.flags |= 65536), (e.lanes = o), e)
    : (e === t
        ? (e.flags |= 65536)
        : ((e.flags |= 128),
          (n.flags |= 131072),
          (n.flags &= -52805),
          n.tag === 1 &&
            (n.alternate === null
              ? (n.tag = 17)
              : ((t = Ut(-1, 1)), (t.tag = 2), kn(n, t, 1))),
          (n.lanes |= 1)),
      e);
}
var _v = Yt.ReactCurrentOwner,
  $e = !1;
function Me(e, t, n, r) {
  t.child = e === null ? Rp(t, null, n, r) : Ur(t, e.child, n, r);
}
function ld(e, t, n, r, o) {
  n = n.render;
  var i = t.ref;
  return (
    br(t, o),
    (r = Pu(e, t, n, r, i, o)),
    (n = Nu()),
    e !== null && !$e
      ? ((t.updateQueue = e.updateQueue),
        (t.flags &= -2053),
        (e.lanes &= ~o),
        Ht(e, t, o))
      : (se && n && hu(t), (t.flags |= 1), Me(e, t, r, o), t.child)
  );
}
function ad(e, t, n, r, o) {
  if (e === null) {
    var i = n.type;
    return typeof i == "function" &&
      !Du(i) &&
      i.defaultProps === void 0 &&
      n.compare === null &&
      n.defaultProps === void 0
      ? ((t.tag = 15), (t.type = i), th(e, t, i, r, o))
      : ((e = Vi(n.type, null, r, t, t.mode, o)),
        (e.ref = t.ref),
        (e.return = t),
        (t.child = e));
  }
  if (((i = e.child), !(e.lanes & o))) {
    var s = i.memoizedProps;
    if (
      ((n = n.compare), (n = n !== null ? n : Oo), n(s, r) && e.ref === t.ref)
    )
      return Ht(e, t, o);
  }
  return (
    (t.flags |= 1),
    (e = bn(i, r)),
    (e.ref = t.ref),
    (e.return = t),
    (t.child = e)
  );
}
function th(e, t, n, r, o) {
  if (e !== null) {
    var i = e.memoizedProps;
    if (Oo(i, r) && e.ref === t.ref)
      if ((($e = !1), (t.pendingProps = r = i), (e.lanes & o) !== 0))
        e.flags & 131072 && ($e = !0);
      else return (t.lanes = e.lanes), Ht(e, t, o);
  }
  return xa(e, t, n, r, o);
}
function nh(e, t, n) {
  var r = t.pendingProps,
    o = r.children,
    i = e !== null ? e.memoizedState : null;
  if (r.mode === "hidden")
    if (!(t.mode & 1))
      (t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }),
        te(wr, Ke),
        (Ke |= n);
    else {
      if (!(n & 1073741824))
        return (
          (e = i !== null ? i.baseLanes | n : n),
          (t.lanes = t.childLanes = 1073741824),
          (t.memoizedState = {
            baseLanes: e,
            cachePool: null,
            transitions: null,
          }),
          (t.updateQueue = null),
          te(wr, Ke),
          (Ke |= e),
          null
        );
      (t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }),
        (r = i !== null ? i.baseLanes : n),
        te(wr, Ke),
        (Ke |= r);
    }
  else
    i !== null ? ((r = i.baseLanes | n), (t.memoizedState = null)) : (r = n),
      te(wr, Ke),
      (Ke |= r);
  return Me(e, t, o, n), t.child;
}
function rh(e, t) {
  var n = t.ref;
  ((e === null && n !== null) || (e !== null && e.ref !== n)) &&
    ((t.flags |= 512), (t.flags |= 2097152));
}
function xa(e, t, n, r, o) {
  var i = Be(n) ? Gn : _e.current;
  return (
    (i = Fr(t, i)),
    br(t, o),
    (n = Pu(e, t, n, r, i, o)),
    (r = Nu()),
    e !== null && !$e
      ? ((t.updateQueue = e.updateQueue),
        (t.flags &= -2053),
        (e.lanes &= ~o),
        Ht(e, t, o))
      : (se && r && hu(t), (t.flags |= 1), Me(e, t, n, o), t.child)
  );
}
function ud(e, t, n, r, o) {
  if (Be(n)) {
    var i = !0;
    is(t);
  } else i = !1;
  if ((br(t, o), t.stateNode === null))
    Ui(e, t), Jp(t, n, r), va(t, n, r, o), (r = !0);
  else if (e === null) {
    var s = t.stateNode,
      l = t.memoizedProps;
    s.props = l;
    var a = s.context,
      u = n.contextType;
    typeof u == "object" && u !== null
      ? (u = st(u))
      : ((u = Be(n) ? Gn : _e.current), (u = Fr(t, u)));
    var d = n.getDerivedStateFromProps,
      f =
        typeof d == "function" ||
        typeof s.getSnapshotBeforeUpdate == "function";
    f ||
      (typeof s.UNSAFE_componentWillReceiveProps != "function" &&
        typeof s.componentWillReceiveProps != "function") ||
      ((l !== r || a !== u) && rd(t, s, r, u)),
      (ln = !1);
    var c = t.memoizedState;
    (s.state = c),
      cs(t, r, s, o),
      (a = t.memoizedState),
      l !== r || c !== a || Ue.current || ln
        ? (typeof d == "function" && (ga(t, n, d, r), (a = t.memoizedState)),
          (l = ln || nd(t, n, l, r, c, a, u))
            ? (f ||
                (typeof s.UNSAFE_componentWillMount != "function" &&
                  typeof s.componentWillMount != "function") ||
                (typeof s.componentWillMount == "function" &&
                  s.componentWillMount(),
                typeof s.UNSAFE_componentWillMount == "function" &&
                  s.UNSAFE_componentWillMount()),
              typeof s.componentDidMount == "function" && (t.flags |= 4194308))
            : (typeof s.componentDidMount == "function" && (t.flags |= 4194308),
              (t.memoizedProps = r),
              (t.memoizedState = a)),
          (s.props = r),
          (s.state = a),
          (s.context = u),
          (r = l))
        : (typeof s.componentDidMount == "function" && (t.flags |= 4194308),
          (r = !1));
  } else {
    (s = t.stateNode),
      jp(e, t),
      (l = t.memoizedProps),
      (u = t.type === t.elementType ? l : ct(t.type, l)),
      (s.props = u),
      (f = t.pendingProps),
      (c = s.context),
      (a = n.contextType),
      typeof a == "object" && a !== null
        ? (a = st(a))
        : ((a = Be(n) ? Gn : _e.current), (a = Fr(t, a)));
    var v = n.getDerivedStateFromProps;
    (d =
      typeof v == "function" ||
      typeof s.getSnapshotBeforeUpdate == "function") ||
      (typeof s.UNSAFE_componentWillReceiveProps != "function" &&
        typeof s.componentWillReceiveProps != "function") ||
      ((l !== f || c !== a) && rd(t, s, r, a)),
      (ln = !1),
      (c = t.memoizedState),
      (s.state = c),
      cs(t, r, s, o);
    var x = t.memoizedState;
    l !== f || c !== x || Ue.current || ln
      ? (typeof v == "function" && (ga(t, n, v, r), (x = t.memoizedState)),
        (u = ln || nd(t, n, u, r, c, x, a) || !1)
          ? (d ||
              (typeof s.UNSAFE_componentWillUpdate != "function" &&
                typeof s.componentWillUpdate != "function") ||
              (typeof s.componentWillUpdate == "function" &&
                s.componentWillUpdate(r, x, a),
              typeof s.UNSAFE_componentWillUpdate == "function" &&
                s.UNSAFE_componentWillUpdate(r, x, a)),
            typeof s.componentDidUpdate == "function" && (t.flags |= 4),
            typeof s.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024))
          : (typeof s.componentDidUpdate != "function" ||
              (l === e.memoizedProps && c === e.memoizedState) ||
              (t.flags |= 4),
            typeof s.getSnapshotBeforeUpdate != "function" ||
              (l === e.memoizedProps && c === e.memoizedState) ||
              (t.flags |= 1024),
            (t.memoizedProps = r),
            (t.memoizedState = x)),
        (s.props = r),
        (s.state = x),
        (s.context = a),
        (r = u))
      : (typeof s.componentDidUpdate != "function" ||
          (l === e.memoizedProps && c === e.memoizedState) ||
          (t.flags |= 4),
        typeof s.getSnapshotBeforeUpdate != "function" ||
          (l === e.memoizedProps && c === e.memoizedState) ||
          (t.flags |= 1024),
        (r = !1));
  }
  return wa(e, t, n, r, i, o);
}
function wa(e, t, n, r, o, i) {
  rh(e, t);
  var s = (t.flags & 128) !== 0;
  if (!r && !s) return o && Gc(t, n, !1), Ht(e, t, i);
  (r = t.stateNode), (_v.current = t);
  var l =
    s && typeof n.getDerivedStateFromError != "function" ? null : r.render();
  return (
    (t.flags |= 1),
    e !== null && s
      ? ((t.child = Ur(t, e.child, null, i)), (t.child = Ur(t, null, l, i)))
      : Me(e, t, l, i),
    (t.memoizedState = r.state),
    o && Gc(t, n, !0),
    t.child
  );
}
function oh(e) {
  var t = e.stateNode;
  t.pendingContext
    ? Kc(e, t.pendingContext, t.pendingContext !== t.context)
    : t.context && Kc(e, t.context, !1),
    ku(e, t.containerInfo);
}
function cd(e, t, n, r, o) {
  return $r(), gu(o), (t.flags |= 256), Me(e, t, n, r), t.child;
}
var Sa = { dehydrated: null, treeContext: null, retryLane: 0 };
function ka(e) {
  return { baseLanes: e, cachePool: null, transitions: null };
}
function ih(e, t, n) {
  var r = t.pendingProps,
    o = ae.current,
    i = !1,
    s = (t.flags & 128) !== 0,
    l;
  if (
    ((l = s) ||
      (l = e !== null && e.memoizedState === null ? !1 : (o & 2) !== 0),
    l
      ? ((i = !0), (t.flags &= -129))
      : (e === null || e.memoizedState !== null) && (o |= 1),
    te(ae, o & 1),
    e === null)
  )
    return (
      ha(t),
      (e = t.memoizedState),
      e !== null && ((e = e.dehydrated), e !== null)
        ? (t.mode & 1
            ? e.data === "$!"
              ? (t.lanes = 8)
              : (t.lanes = 1073741824)
            : (t.lanes = 1),
          null)
        : ((s = r.children),
          (e = r.fallback),
          i
            ? ((r = t.mode),
              (i = t.child),
              (s = { mode: "hidden", children: s }),
              !(r & 1) && i !== null
                ? ((i.childLanes = 0), (i.pendingProps = s))
                : (i = zs(s, r, 0, null)),
              (e = Kn(e, r, n, null)),
              (i.return = t),
              (e.return = t),
              (i.sibling = e),
              (t.child = i),
              (t.child.memoizedState = ka(n)),
              (t.memoizedState = Sa),
              e)
            : Au(t, s))
    );
  if (((o = e.memoizedState), o !== null && ((l = o.dehydrated), l !== null)))
    return Ov(e, t, s, r, l, o, n);
  if (i) {
    (i = r.fallback), (s = t.mode), (o = e.child), (l = o.sibling);
    var a = { mode: "hidden", children: r.children };
    return (
      !(s & 1) && t.child !== o
        ? ((r = t.child),
          (r.childLanes = 0),
          (r.pendingProps = a),
          (t.deletions = null))
        : ((r = bn(o, a)), (r.subtreeFlags = o.subtreeFlags & 14680064)),
      l !== null ? (i = bn(l, i)) : ((i = Kn(i, s, n, null)), (i.flags |= 2)),
      (i.return = t),
      (r.return = t),
      (r.sibling = i),
      (t.child = r),
      (r = i),
      (i = t.child),
      (s = e.child.memoizedState),
      (s =
        s === null
          ? ka(n)
          : {
              baseLanes: s.baseLanes | n,
              cachePool: null,
              transitions: s.transitions,
            }),
      (i.memoizedState = s),
      (i.childLanes = e.childLanes & ~n),
      (t.memoizedState = Sa),
      r
    );
  }
  return (
    (i = e.child),
    (e = i.sibling),
    (r = bn(i, { mode: "visible", children: r.children })),
    !(t.mode & 1) && (r.lanes = n),
    (r.return = t),
    (r.sibling = null),
    e !== null &&
      ((n = t.deletions),
      n === null ? ((t.deletions = [e]), (t.flags |= 16)) : n.push(e)),
    (t.child = r),
    (t.memoizedState = null),
    r
  );
}
function Au(e, t) {
  return (
    (t = zs({ mode: "visible", children: t }, e.mode, 0, null)),
    (t.return = e),
    (e.child = t)
  );
}
function Ci(e, t, n, r) {
  return (
    r !== null && gu(r),
    Ur(t, e.child, null, n),
    (e = Au(t, t.pendingProps.children)),
    (e.flags |= 2),
    (t.memoizedState = null),
    e
  );
}
function Ov(e, t, n, r, o, i, s) {
  if (n)
    return t.flags & 256
      ? ((t.flags &= -257), (r = Nl(Error(R(422)))), Ci(e, t, s, r))
      : t.memoizedState !== null
      ? ((t.child = e.child), (t.flags |= 128), null)
      : ((i = r.fallback),
        (o = t.mode),
        (r = zs({ mode: "visible", children: r.children }, o, 0, null)),
        (i = Kn(i, o, s, null)),
        (i.flags |= 2),
        (r.return = t),
        (i.return = t),
        (r.sibling = i),
        (t.child = r),
        t.mode & 1 && Ur(t, e.child, null, s),
        (t.child.memoizedState = ka(s)),
        (t.memoizedState = Sa),
        i);
  if (!(t.mode & 1)) return Ci(e, t, s, null);
  if (o.data === "$!") {
    if (((r = o.nextSibling && o.nextSibling.dataset), r)) var l = r.dgst;
    return (r = l), (i = Error(R(419))), (r = Nl(i, r, void 0)), Ci(e, t, s, r);
  }
  if (((l = (s & e.childLanes) !== 0), $e || l)) {
    if (((r = we), r !== null)) {
      switch (s & -s) {
        case 4:
          o = 2;
          break;
        case 16:
          o = 8;
          break;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          o = 32;
          break;
        case 536870912:
          o = 268435456;
          break;
        default:
          o = 0;
      }
      (o = o & (r.suspendedLanes | s) ? 0 : o),
        o !== 0 &&
          o !== i.retryLane &&
          ((i.retryLane = o), Vt(e, o), gt(r, e, o, -1));
    }
    return Iu(), (r = Nl(Error(R(421)))), Ci(e, t, s, r);
  }
  return o.data === "$?"
    ? ((t.flags |= 128),
      (t.child = e.child),
      (t = Qv.bind(null, e)),
      (o._reactRetry = t),
      null)
    : ((e = i.treeContext),
      (Ye = Sn(o.nextSibling)),
      (Xe = t),
      (se = !0),
      (ht = null),
      e !== null &&
        ((nt[rt++] = Ft),
        (nt[rt++] = $t),
        (nt[rt++] = Yn),
        (Ft = e.id),
        ($t = e.overflow),
        (Yn = t)),
      (t = Au(t, r.children)),
      (t.flags |= 4096),
      t);
}
function dd(e, t, n) {
  e.lanes |= t;
  var r = e.alternate;
  r !== null && (r.lanes |= t), ma(e.return, t, n);
}
function Tl(e, t, n, r, o) {
  var i = e.memoizedState;
  i === null
    ? (e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: o,
      })
    : ((i.isBackwards = t),
      (i.rendering = null),
      (i.renderingStartTime = 0),
      (i.last = r),
      (i.tail = n),
      (i.tailMode = o));
}
function sh(e, t, n) {
  var r = t.pendingProps,
    o = r.revealOrder,
    i = r.tail;
  if ((Me(e, t, r.children, n), (r = ae.current), r & 2))
    (r = (r & 1) | 2), (t.flags |= 128);
  else {
    if (e !== null && e.flags & 128)
      e: for (e = t.child; e !== null; ) {
        if (e.tag === 13) e.memoizedState !== null && dd(e, n, t);
        else if (e.tag === 19) dd(e, n, t);
        else if (e.child !== null) {
          (e.child.return = e), (e = e.child);
          continue;
        }
        if (e === t) break e;
        for (; e.sibling === null; ) {
          if (e.return === null || e.return === t) break e;
          e = e.return;
        }
        (e.sibling.return = e.return), (e = e.sibling);
      }
    r &= 1;
  }
  if ((te(ae, r), !(t.mode & 1))) t.memoizedState = null;
  else
    switch (o) {
      case "forwards":
        for (n = t.child, o = null; n !== null; )
          (e = n.alternate),
            e !== null && ds(e) === null && (o = n),
            (n = n.sibling);
        (n = o),
          n === null
            ? ((o = t.child), (t.child = null))
            : ((o = n.sibling), (n.sibling = null)),
          Tl(t, !1, o, n, i);
        break;
      case "backwards":
        for (n = null, o = t.child, t.child = null; o !== null; ) {
          if (((e = o.alternate), e !== null && ds(e) === null)) {
            t.child = o;
            break;
          }
          (e = o.sibling), (o.sibling = n), (n = o), (o = e);
        }
        Tl(t, !0, n, null, i);
        break;
      case "together":
        Tl(t, !1, null, null, void 0);
        break;
      default:
        t.memoizedState = null;
    }
  return t.child;
}
function Ui(e, t) {
  !(t.mode & 1) &&
    e !== null &&
    ((e.alternate = null), (t.alternate = null), (t.flags |= 2));
}
function Ht(e, t, n) {
  if (
    (e !== null && (t.dependencies = e.dependencies),
    (qn |= t.lanes),
    !(n & t.childLanes))
  )
    return null;
  if (e !== null && t.child !== e.child) throw Error(R(153));
  if (t.child !== null) {
    for (
      e = t.child, n = bn(e, e.pendingProps), t.child = n, n.return = t;
      e.sibling !== null;

    )
      (e = e.sibling), (n = n.sibling = bn(e, e.pendingProps)), (n.return = t);
    n.sibling = null;
  }
  return t.child;
}
function Mv(e, t, n) {
  switch (t.tag) {
    case 3:
      oh(t), $r();
      break;
    case 5:
      _p(t);
      break;
    case 1:
      Be(t.type) && is(t);
      break;
    case 4:
      ku(t, t.stateNode.containerInfo);
      break;
    case 10:
      var r = t.type._context,
        o = t.memoizedProps.value;
      te(as, r._currentValue), (r._currentValue = o);
      break;
    case 13:
      if (((r = t.memoizedState), r !== null))
        return r.dehydrated !== null
          ? (te(ae, ae.current & 1), (t.flags |= 128), null)
          : n & t.child.childLanes
          ? ih(e, t, n)
          : (te(ae, ae.current & 1),
            (e = Ht(e, t, n)),
            e !== null ? e.sibling : null);
      te(ae, ae.current & 1);
      break;
    case 19:
      if (((r = (n & t.childLanes) !== 0), e.flags & 128)) {
        if (r) return sh(e, t, n);
        t.flags |= 128;
      }
      if (
        ((o = t.memoizedState),
        o !== null &&
          ((o.rendering = null), (o.tail = null), (o.lastEffect = null)),
        te(ae, ae.current),
        r)
      )
        break;
      return null;
    case 22:
    case 23:
      return (t.lanes = 0), nh(e, t, n);
  }
  return Ht(e, t, n);
}
var lh, Ea, ah, uh;
lh = function (e, t) {
  for (var n = t.child; n !== null; ) {
    if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
    else if (n.tag !== 4 && n.child !== null) {
      (n.child.return = n), (n = n.child);
      continue;
    }
    if (n === t) break;
    for (; n.sibling === null; ) {
      if (n.return === null || n.return === t) return;
      n = n.return;
    }
    (n.sibling.return = n.return), (n = n.sibling);
  }
};
Ea = function () {};
ah = function (e, t, n, r) {
  var o = e.memoizedProps;
  if (o !== r) {
    (e = t.stateNode), Un(jt.current);
    var i = null;
    switch (n) {
      case "input":
        (o = Hl(e, o)), (r = Hl(e, r)), (i = []);
        break;
      case "select":
        (o = ce({}, o, { value: void 0 })),
          (r = ce({}, r, { value: void 0 })),
          (i = []);
        break;
      case "textarea":
        (o = Gl(e, o)), (r = Gl(e, r)), (i = []);
        break;
      default:
        typeof o.onClick != "function" &&
          typeof r.onClick == "function" &&
          (e.onclick = rs);
    }
    Xl(n, r);
    var s;
    n = null;
    for (u in o)
      if (!r.hasOwnProperty(u) && o.hasOwnProperty(u) && o[u] != null)
        if (u === "style") {
          var l = o[u];
          for (s in l) l.hasOwnProperty(s) && (n || (n = {}), (n[s] = ""));
        } else
          u !== "dangerouslySetInnerHTML" &&
            u !== "children" &&
            u !== "suppressContentEditableWarning" &&
            u !== "suppressHydrationWarning" &&
            u !== "autoFocus" &&
            (Po.hasOwnProperty(u)
              ? i || (i = [])
              : (i = i || []).push(u, null));
    for (u in r) {
      var a = r[u];
      if (
        ((l = o != null ? o[u] : void 0),
        r.hasOwnProperty(u) && a !== l && (a != null || l != null))
      )
        if (u === "style")
          if (l) {
            for (s in l)
              !l.hasOwnProperty(s) ||
                (a && a.hasOwnProperty(s)) ||
                (n || (n = {}), (n[s] = ""));
            for (s in a)
              a.hasOwnProperty(s) &&
                l[s] !== a[s] &&
                (n || (n = {}), (n[s] = a[s]));
          } else n || (i || (i = []), i.push(u, n)), (n = a);
        else
          u === "dangerouslySetInnerHTML"
            ? ((a = a ? a.__html : void 0),
              (l = l ? l.__html : void 0),
              a != null && l !== a && (i = i || []).push(u, a))
            : u === "children"
            ? (typeof a != "string" && typeof a != "number") ||
              (i = i || []).push(u, "" + a)
            : u !== "suppressContentEditableWarning" &&
              u !== "suppressHydrationWarning" &&
              (Po.hasOwnProperty(u)
                ? (a != null && u === "onScroll" && oe("scroll", e),
                  i || l === a || (i = []))
                : (i = i || []).push(u, a));
    }
    n && (i = i || []).push("style", n);
    var u = i;
    (t.updateQueue = u) && (t.flags |= 4);
  }
};
uh = function (e, t, n, r) {
  n !== r && (t.flags |= 4);
};
function lo(e, t) {
  if (!se)
    switch (e.tailMode) {
      case "hidden":
        t = e.tail;
        for (var n = null; t !== null; )
          t.alternate !== null && (n = t), (t = t.sibling);
        n === null ? (e.tail = null) : (n.sibling = null);
        break;
      case "collapsed":
        n = e.tail;
        for (var r = null; n !== null; )
          n.alternate !== null && (r = n), (n = n.sibling);
        r === null
          ? t || e.tail === null
            ? (e.tail = null)
            : (e.tail.sibling = null)
          : (r.sibling = null);
    }
}
function Re(e) {
  var t = e.alternate !== null && e.alternate.child === e.child,
    n = 0,
    r = 0;
  if (t)
    for (var o = e.child; o !== null; )
      (n |= o.lanes | o.childLanes),
        (r |= o.subtreeFlags & 14680064),
        (r |= o.flags & 14680064),
        (o.return = e),
        (o = o.sibling);
  else
    for (o = e.child; o !== null; )
      (n |= o.lanes | o.childLanes),
        (r |= o.subtreeFlags),
        (r |= o.flags),
        (o.return = e),
        (o = o.sibling);
  return (e.subtreeFlags |= r), (e.childLanes = n), t;
}
function Lv(e, t, n) {
  var r = t.pendingProps;
  switch ((mu(t), t.tag)) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return Re(t), null;
    case 1:
      return Be(t.type) && os(), Re(t), null;
    case 3:
      return (
        (r = t.stateNode),
        Br(),
        ie(Ue),
        ie(_e),
        Cu(),
        r.pendingContext &&
          ((r.context = r.pendingContext), (r.pendingContext = null)),
        (e === null || e.child === null) &&
          (ki(t)
            ? (t.flags |= 4)
            : e === null ||
              (e.memoizedState.isDehydrated && !(t.flags & 256)) ||
              ((t.flags |= 1024), ht !== null && (ja(ht), (ht = null)))),
        Ea(e, t),
        Re(t),
        null
      );
    case 5:
      Eu(t);
      var o = Un(zo.current);
      if (((n = t.type), e !== null && t.stateNode != null))
        ah(e, t, n, r, o),
          e.ref !== t.ref && ((t.flags |= 512), (t.flags |= 2097152));
      else {
        if (!r) {
          if (t.stateNode === null) throw Error(R(166));
          return Re(t), null;
        }
        if (((e = Un(jt.current)), ki(t))) {
          (r = t.stateNode), (n = t.type);
          var i = t.memoizedProps;
          switch (((r[Rt] = t), (r[Io] = i), (e = (t.mode & 1) !== 0), n)) {
            case "dialog":
              oe("cancel", r), oe("close", r);
              break;
            case "iframe":
            case "object":
            case "embed":
              oe("load", r);
              break;
            case "video":
            case "audio":
              for (o = 0; o < mo.length; o++) oe(mo[o], r);
              break;
            case "source":
              oe("error", r);
              break;
            case "img":
            case "image":
            case "link":
              oe("error", r), oe("load", r);
              break;
            case "details":
              oe("toggle", r);
              break;
            case "input":
              wc(r, i), oe("invalid", r);
              break;
            case "select":
              (r._wrapperState = { wasMultiple: !!i.multiple }),
                oe("invalid", r);
              break;
            case "textarea":
              kc(r, i), oe("invalid", r);
          }
          Xl(n, i), (o = null);
          for (var s in i)
            if (i.hasOwnProperty(s)) {
              var l = i[s];
              s === "children"
                ? typeof l == "string"
                  ? r.textContent !== l &&
                    (i.suppressHydrationWarning !== !0 &&
                      Si(r.textContent, l, e),
                    (o = ["children", l]))
                  : typeof l == "number" &&
                    r.textContent !== "" + l &&
                    (i.suppressHydrationWarning !== !0 &&
                      Si(r.textContent, l, e),
                    (o = ["children", "" + l]))
                : Po.hasOwnProperty(s) &&
                  l != null &&
                  s === "onScroll" &&
                  oe("scroll", r);
            }
          switch (n) {
            case "input":
              pi(r), Sc(r, i, !0);
              break;
            case "textarea":
              pi(r), Ec(r);
              break;
            case "select":
            case "option":
              break;
            default:
              typeof i.onClick == "function" && (r.onclick = rs);
          }
          (r = o), (t.updateQueue = r), r !== null && (t.flags |= 4);
        } else {
          (s = o.nodeType === 9 ? o : o.ownerDocument),
            e === "http://www.w3.org/1999/xhtml" && (e = Df(n)),
            e === "http://www.w3.org/1999/xhtml"
              ? n === "script"
                ? ((e = s.createElement("div")),
                  (e.innerHTML = "<script></script>"),
                  (e = e.removeChild(e.firstChild)))
                : typeof r.is == "string"
                ? (e = s.createElement(n, { is: r.is }))
                : ((e = s.createElement(n)),
                  n === "select" &&
                    ((s = e),
                    r.multiple
                      ? (s.multiple = !0)
                      : r.size && (s.size = r.size)))
              : (e = s.createElementNS(e, n)),
            (e[Rt] = t),
            (e[Io] = r),
            lh(e, t, !1, !1),
            (t.stateNode = e);
          e: {
            switch (((s = ql(n, r)), n)) {
              case "dialog":
                oe("cancel", e), oe("close", e), (o = r);
                break;
              case "iframe":
              case "object":
              case "embed":
                oe("load", e), (o = r);
                break;
              case "video":
              case "audio":
                for (o = 0; o < mo.length; o++) oe(mo[o], e);
                o = r;
                break;
              case "source":
                oe("error", e), (o = r);
                break;
              case "img":
              case "image":
              case "link":
                oe("error", e), oe("load", e), (o = r);
                break;
              case "details":
                oe("toggle", e), (o = r);
                break;
              case "input":
                wc(e, r), (o = Hl(e, r)), oe("invalid", e);
                break;
              case "option":
                o = r;
                break;
              case "select":
                (e._wrapperState = { wasMultiple: !!r.multiple }),
                  (o = ce({}, r, { value: void 0 })),
                  oe("invalid", e);
                break;
              case "textarea":
                kc(e, r), (o = Gl(e, r)), oe("invalid", e);
                break;
              default:
                o = r;
            }
            Xl(n, o), (l = o);
            for (i in l)
              if (l.hasOwnProperty(i)) {
                var a = l[i];
                i === "style"
                  ? $f(e, a)
                  : i === "dangerouslySetInnerHTML"
                  ? ((a = a ? a.__html : void 0), a != null && zf(e, a))
                  : i === "children"
                  ? typeof a == "string"
                    ? (n !== "textarea" || a !== "") && No(e, a)
                    : typeof a == "number" && No(e, "" + a)
                  : i !== "suppressContentEditableWarning" &&
                    i !== "suppressHydrationWarning" &&
                    i !== "autoFocus" &&
                    (Po.hasOwnProperty(i)
                      ? a != null && i === "onScroll" && oe("scroll", e)
                      : a != null && eu(e, i, a, s));
              }
            switch (n) {
              case "input":
                pi(e), Sc(e, r, !1);
                break;
              case "textarea":
                pi(e), Ec(e);
                break;
              case "option":
                r.value != null && e.setAttribute("value", "" + Nn(r.value));
                break;
              case "select":
                (e.multiple = !!r.multiple),
                  (i = r.value),
                  i != null
                    ? Sr(e, !!r.multiple, i, !1)
                    : r.defaultValue != null &&
                      Sr(e, !!r.multiple, r.defaultValue, !0);
                break;
              default:
                typeof o.onClick == "function" && (e.onclick = rs);
            }
            switch (n) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                r = !!r.autoFocus;
                break e;
              case "img":
                r = !0;
                break e;
              default:
                r = !1;
            }
          }
          r && (t.flags |= 4);
        }
        t.ref !== null && ((t.flags |= 512), (t.flags |= 2097152));
      }
      return Re(t), null;
    case 6:
      if (e && t.stateNode != null) uh(e, t, e.memoizedProps, r);
      else {
        if (typeof r != "string" && t.stateNode === null) throw Error(R(166));
        if (((n = Un(zo.current)), Un(jt.current), ki(t))) {
          if (
            ((r = t.stateNode),
            (n = t.memoizedProps),
            (r[Rt] = t),
            (i = r.nodeValue !== n) && ((e = Xe), e !== null))
          )
            switch (e.tag) {
              case 3:
                Si(r.nodeValue, n, (e.mode & 1) !== 0);
                break;
              case 5:
                e.memoizedProps.suppressHydrationWarning !== !0 &&
                  Si(r.nodeValue, n, (e.mode & 1) !== 0);
            }
          i && (t.flags |= 4);
        } else
          (r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r)),
            (r[Rt] = t),
            (t.stateNode = r);
      }
      return Re(t), null;
    case 13:
      if (
        (ie(ae),
        (r = t.memoizedState),
        e === null ||
          (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
      ) {
        if (se && Ye !== null && t.mode & 1 && !(t.flags & 128))
          Np(), $r(), (t.flags |= 98560), (i = !1);
        else if (((i = ki(t)), r !== null && r.dehydrated !== null)) {
          if (e === null) {
            if (!i) throw Error(R(318));
            if (
              ((i = t.memoizedState),
              (i = i !== null ? i.dehydrated : null),
              !i)
            )
              throw Error(R(317));
            i[Rt] = t;
          } else
            $r(), !(t.flags & 128) && (t.memoizedState = null), (t.flags |= 4);
          Re(t), (i = !1);
        } else ht !== null && (ja(ht), (ht = null)), (i = !0);
        if (!i) return t.flags & 65536 ? t : null;
      }
      return t.flags & 128
        ? ((t.lanes = n), t)
        : ((r = r !== null),
          r !== (e !== null && e.memoizedState !== null) &&
            r &&
            ((t.child.flags |= 8192),
            t.mode & 1 &&
              (e === null || ae.current & 1 ? ye === 0 && (ye = 3) : Iu())),
          t.updateQueue !== null && (t.flags |= 4),
          Re(t),
          null);
    case 4:
      return (
        Br(), Ea(e, t), e === null && Mo(t.stateNode.containerInfo), Re(t), null
      );
    case 10:
      return xu(t.type._context), Re(t), null;
    case 17:
      return Be(t.type) && os(), Re(t), null;
    case 19:
      if ((ie(ae), (i = t.memoizedState), i === null)) return Re(t), null;
      if (((r = (t.flags & 128) !== 0), (s = i.rendering), s === null))
        if (r) lo(i, !1);
        else {
          if (ye !== 0 || (e !== null && e.flags & 128))
            for (e = t.child; e !== null; ) {
              if (((s = ds(e)), s !== null)) {
                for (
                  t.flags |= 128,
                    lo(i, !1),
                    r = s.updateQueue,
                    r !== null && ((t.updateQueue = r), (t.flags |= 4)),
                    t.subtreeFlags = 0,
                    r = n,
                    n = t.child;
                  n !== null;

                )
                  (i = n),
                    (e = r),
                    (i.flags &= 14680066),
                    (s = i.alternate),
                    s === null
                      ? ((i.childLanes = 0),
                        (i.lanes = e),
                        (i.child = null),
                        (i.subtreeFlags = 0),
                        (i.memoizedProps = null),
                        (i.memoizedState = null),
                        (i.updateQueue = null),
                        (i.dependencies = null),
                        (i.stateNode = null))
                      : ((i.childLanes = s.childLanes),
                        (i.lanes = s.lanes),
                        (i.child = s.child),
                        (i.subtreeFlags = 0),
                        (i.deletions = null),
                        (i.memoizedProps = s.memoizedProps),
                        (i.memoizedState = s.memoizedState),
                        (i.updateQueue = s.updateQueue),
                        (i.type = s.type),
                        (e = s.dependencies),
                        (i.dependencies =
                          e === null
                            ? null
                            : {
                                lanes: e.lanes,
                                firstContext: e.firstContext,
                              })),
                    (n = n.sibling);
                return te(ae, (ae.current & 1) | 2), t.child;
              }
              e = e.sibling;
            }
          i.tail !== null &&
            pe() > Vr &&
            ((t.flags |= 128), (r = !0), lo(i, !1), (t.lanes = 4194304));
        }
      else {
        if (!r)
          if (((e = ds(s)), e !== null)) {
            if (
              ((t.flags |= 128),
              (r = !0),
              (n = e.updateQueue),
              n !== null && ((t.updateQueue = n), (t.flags |= 4)),
              lo(i, !0),
              i.tail === null && i.tailMode === "hidden" && !s.alternate && !se)
            )
              return Re(t), null;
          } else
            2 * pe() - i.renderingStartTime > Vr &&
              n !== 1073741824 &&
              ((t.flags |= 128), (r = !0), lo(i, !1), (t.lanes = 4194304));
        i.isBackwards
          ? ((s.sibling = t.child), (t.child = s))
          : ((n = i.last),
            n !== null ? (n.sibling = s) : (t.child = s),
            (i.last = s));
      }
      return i.tail !== null
        ? ((t = i.tail),
          (i.rendering = t),
          (i.tail = t.sibling),
          (i.renderingStartTime = pe()),
          (t.sibling = null),
          (n = ae.current),
          te(ae, r ? (n & 1) | 2 : n & 1),
          t)
        : (Re(t), null);
    case 22:
    case 23:
      return (
        Lu(),
        (r = t.memoizedState !== null),
        e !== null && (e.memoizedState !== null) !== r && (t.flags |= 8192),
        r && t.mode & 1
          ? Ke & 1073741824 && (Re(t), t.subtreeFlags & 6 && (t.flags |= 8192))
          : Re(t),
        null
      );
    case 24:
      return null;
    case 25:
      return null;
  }
  throw Error(R(156, t.tag));
}
function Iv(e, t) {
  switch ((mu(t), t.tag)) {
    case 1:
      return (
        Be(t.type) && os(),
        (e = t.flags),
        e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
      );
    case 3:
      return (
        Br(),
        ie(Ue),
        ie(_e),
        Cu(),
        (e = t.flags),
        e & 65536 && !(e & 128) ? ((t.flags = (e & -65537) | 128), t) : null
      );
    case 5:
      return Eu(t), null;
    case 13:
      if (
        (ie(ae), (e = t.memoizedState), e !== null && e.dehydrated !== null)
      ) {
        if (t.alternate === null) throw Error(R(340));
        $r();
      }
      return (
        (e = t.flags), e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
      );
    case 19:
      return ie(ae), null;
    case 4:
      return Br(), null;
    case 10:
      return xu(t.type._context), null;
    case 22:
    case 23:
      return Lu(), null;
    case 24:
      return null;
    default:
      return null;
  }
}
var bi = !1,
  je = !1,
  Dv = typeof WeakSet == "function" ? WeakSet : Set,
  M = null;
function xr(e, t) {
  var n = e.ref;
  if (n !== null)
    if (typeof n == "function")
      try {
        n(null);
      } catch (r) {
        fe(e, t, r);
      }
    else n.current = null;
}
function Ca(e, t, n) {
  try {
    n();
  } catch (r) {
    fe(e, t, r);
  }
}
var fd = !1;
function zv(e, t) {
  if (((la = es), (e = hp()), pu(e))) {
    if ("selectionStart" in e)
      var n = { start: e.selectionStart, end: e.selectionEnd };
    else
      e: {
        n = ((n = e.ownerDocument) && n.defaultView) || window;
        var r = n.getSelection && n.getSelection();
        if (r && r.rangeCount !== 0) {
          n = r.anchorNode;
          var o = r.anchorOffset,
            i = r.focusNode;
          r = r.focusOffset;
          try {
            n.nodeType, i.nodeType;
          } catch {
            n = null;
            break e;
          }
          var s = 0,
            l = -1,
            a = -1,
            u = 0,
            d = 0,
            f = e,
            c = null;
          t: for (;;) {
            for (
              var v;
              f !== n || (o !== 0 && f.nodeType !== 3) || (l = s + o),
                f !== i || (r !== 0 && f.nodeType !== 3) || (a = s + r),
                f.nodeType === 3 && (s += f.nodeValue.length),
                (v = f.firstChild) !== null;

            )
              (c = f), (f = v);
            for (;;) {
              if (f === e) break t;
              if (
                (c === n && ++u === o && (l = s),
                c === i && ++d === r && (a = s),
                (v = f.nextSibling) !== null)
              )
                break;
              (f = c), (c = f.parentNode);
            }
            f = v;
          }
          n = l === -1 || a === -1 ? null : { start: l, end: a };
        } else n = null;
      }
    n = n || { start: 0, end: 0 };
  } else n = null;
  for (aa = { focusedElem: e, selectionRange: n }, es = !1, M = t; M !== null; )
    if (((t = M), (e = t.child), (t.subtreeFlags & 1028) !== 0 && e !== null))
      (e.return = t), (M = e);
    else
      for (; M !== null; ) {
        t = M;
        try {
          var x = t.alternate;
          if (t.flags & 1024)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                break;
              case 1:
                if (x !== null) {
                  var g = x.memoizedProps,
                    S = x.memoizedState,
                    h = t.stateNode,
                    p = h.getSnapshotBeforeUpdate(
                      t.elementType === t.type ? g : ct(t.type, g),
                      S
                    );
                  h.__reactInternalSnapshotBeforeUpdate = p;
                }
                break;
              case 3:
                var m = t.stateNode.containerInfo;
                m.nodeType === 1
                  ? (m.textContent = "")
                  : m.nodeType === 9 &&
                    m.documentElement &&
                    m.removeChild(m.documentElement);
                break;
              case 5:
              case 6:
              case 4:
              case 17:
                break;
              default:
                throw Error(R(163));
            }
        } catch (k) {
          fe(t, t.return, k);
        }
        if (((e = t.sibling), e !== null)) {
          (e.return = t.return), (M = e);
          break;
        }
        M = t.return;
      }
  return (x = fd), (fd = !1), x;
}
function ko(e, t, n) {
  var r = t.updateQueue;
  if (((r = r !== null ? r.lastEffect : null), r !== null)) {
    var o = (r = r.next);
    do {
      if ((o.tag & e) === e) {
        var i = o.destroy;
        (o.destroy = void 0), i !== void 0 && Ca(t, n, i);
      }
      o = o.next;
    } while (o !== r);
  }
}
function Is(e, t) {
  if (
    ((t = t.updateQueue), (t = t !== null ? t.lastEffect : null), t !== null)
  ) {
    var n = (t = t.next);
    do {
      if ((n.tag & e) === e) {
        var r = n.create;
        n.destroy = r();
      }
      n = n.next;
    } while (n !== t);
  }
}
function ba(e) {
  var t = e.ref;
  if (t !== null) {
    var n = e.stateNode;
    switch (e.tag) {
      case 5:
        e = n;
        break;
      default:
        e = n;
    }
    typeof t == "function" ? t(e) : (t.current = e);
  }
}
function ch(e) {
  var t = e.alternate;
  t !== null && ((e.alternate = null), ch(t)),
    (e.child = null),
    (e.deletions = null),
    (e.sibling = null),
    e.tag === 5 &&
      ((t = e.stateNode),
      t !== null &&
        (delete t[Rt], delete t[Io], delete t[da], delete t[wv], delete t[Sv])),
    (e.stateNode = null),
    (e.return = null),
    (e.dependencies = null),
    (e.memoizedProps = null),
    (e.memoizedState = null),
    (e.pendingProps = null),
    (e.stateNode = null),
    (e.updateQueue = null);
}
function dh(e) {
  return e.tag === 5 || e.tag === 3 || e.tag === 4;
}
function pd(e) {
  e: for (;;) {
    for (; e.sibling === null; ) {
      if (e.return === null || dh(e.return)) return null;
      e = e.return;
    }
    for (
      e.sibling.return = e.return, e = e.sibling;
      e.tag !== 5 && e.tag !== 6 && e.tag !== 18;

    ) {
      if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
      (e.child.return = e), (e = e.child);
    }
    if (!(e.flags & 2)) return e.stateNode;
  }
}
function Pa(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6)
    (e = e.stateNode),
      t
        ? n.nodeType === 8
          ? n.parentNode.insertBefore(e, t)
          : n.insertBefore(e, t)
        : (n.nodeType === 8
            ? ((t = n.parentNode), t.insertBefore(e, n))
            : ((t = n), t.appendChild(e)),
          (n = n._reactRootContainer),
          n != null || t.onclick !== null || (t.onclick = rs));
  else if (r !== 4 && ((e = e.child), e !== null))
    for (Pa(e, t, n), e = e.sibling; e !== null; ) Pa(e, t, n), (e = e.sibling);
}
function Na(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6)
    (e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e);
  else if (r !== 4 && ((e = e.child), e !== null))
    for (Na(e, t, n), e = e.sibling; e !== null; ) Na(e, t, n), (e = e.sibling);
}
var ke = null,
  pt = !1;
function tn(e, t, n) {
  for (n = n.child; n !== null; ) fh(e, t, n), (n = n.sibling);
}
function fh(e, t, n) {
  if (At && typeof At.onCommitFiberUnmount == "function")
    try {
      At.onCommitFiberUnmount(Ts, n);
    } catch {}
  switch (n.tag) {
    case 5:
      je || xr(n, t);
    case 6:
      var r = ke,
        o = pt;
      (ke = null),
        tn(e, t, n),
        (ke = r),
        (pt = o),
        ke !== null &&
          (pt
            ? ((e = ke),
              (n = n.stateNode),
              e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n))
            : ke.removeChild(n.stateNode));
      break;
    case 18:
      ke !== null &&
        (pt
          ? ((e = ke),
            (n = n.stateNode),
            e.nodeType === 8
              ? Sl(e.parentNode, n)
              : e.nodeType === 1 && Sl(e, n),
            jo(e))
          : Sl(ke, n.stateNode));
      break;
    case 4:
      (r = ke),
        (o = pt),
        (ke = n.stateNode.containerInfo),
        (pt = !0),
        tn(e, t, n),
        (ke = r),
        (pt = o);
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (
        !je &&
        ((r = n.updateQueue), r !== null && ((r = r.lastEffect), r !== null))
      ) {
        o = r = r.next;
        do {
          var i = o,
            s = i.destroy;
          (i = i.tag),
            s !== void 0 && (i & 2 || i & 4) && Ca(n, t, s),
            (o = o.next);
        } while (o !== r);
      }
      tn(e, t, n);
      break;
    case 1:
      if (
        !je &&
        (xr(n, t),
        (r = n.stateNode),
        typeof r.componentWillUnmount == "function")
      )
        try {
          (r.props = n.memoizedProps),
            (r.state = n.memoizedState),
            r.componentWillUnmount();
        } catch (l) {
          fe(n, t, l);
        }
      tn(e, t, n);
      break;
    case 21:
      tn(e, t, n);
      break;
    case 22:
      n.mode & 1
        ? ((je = (r = je) || n.memoizedState !== null), tn(e, t, n), (je = r))
        : tn(e, t, n);
      break;
    default:
      tn(e, t, n);
  }
}
function hd(e) {
  var t = e.updateQueue;
  if (t !== null) {
    e.updateQueue = null;
    var n = e.stateNode;
    n === null && (n = e.stateNode = new Dv()),
      t.forEach(function (r) {
        var o = Kv.bind(null, e, r);
        n.has(r) || (n.add(r), r.then(o, o));
      });
  }
}
function ut(e, t) {
  var n = t.deletions;
  if (n !== null)
    for (var r = 0; r < n.length; r++) {
      var o = n[r];
      try {
        var i = e,
          s = t,
          l = s;
        e: for (; l !== null; ) {
          switch (l.tag) {
            case 5:
              (ke = l.stateNode), (pt = !1);
              break e;
            case 3:
              (ke = l.stateNode.containerInfo), (pt = !0);
              break e;
            case 4:
              (ke = l.stateNode.containerInfo), (pt = !0);
              break e;
          }
          l = l.return;
        }
        if (ke === null) throw Error(R(160));
        fh(i, s, o), (ke = null), (pt = !1);
        var a = o.alternate;
        a !== null && (a.return = null), (o.return = null);
      } catch (u) {
        fe(o, t, u);
      }
    }
  if (t.subtreeFlags & 12854)
    for (t = t.child; t !== null; ) ph(t, e), (t = t.sibling);
}
function ph(e, t) {
  var n = e.alternate,
    r = e.flags;
  switch (e.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      if ((ut(t, e), Ct(e), r & 4)) {
        try {
          ko(3, e, e.return), Is(3, e);
        } catch (g) {
          fe(e, e.return, g);
        }
        try {
          ko(5, e, e.return);
        } catch (g) {
          fe(e, e.return, g);
        }
      }
      break;
    case 1:
      ut(t, e), Ct(e), r & 512 && n !== null && xr(n, n.return);
      break;
    case 5:
      if (
        (ut(t, e),
        Ct(e),
        r & 512 && n !== null && xr(n, n.return),
        e.flags & 32)
      ) {
        var o = e.stateNode;
        try {
          No(o, "");
        } catch (g) {
          fe(e, e.return, g);
        }
      }
      if (r & 4 && ((o = e.stateNode), o != null)) {
        var i = e.memoizedProps,
          s = n !== null ? n.memoizedProps : i,
          l = e.type,
          a = e.updateQueue;
        if (((e.updateQueue = null), a !== null))
          try {
            l === "input" && i.type === "radio" && i.name != null && Lf(o, i),
              ql(l, s);
            var u = ql(l, i);
            for (s = 0; s < a.length; s += 2) {
              var d = a[s],
                f = a[s + 1];
              d === "style"
                ? $f(o, f)
                : d === "dangerouslySetInnerHTML"
                ? zf(o, f)
                : d === "children"
                ? No(o, f)
                : eu(o, d, f, u);
            }
            switch (l) {
              case "input":
                Ql(o, i);
                break;
              case "textarea":
                If(o, i);
                break;
              case "select":
                var c = o._wrapperState.wasMultiple;
                o._wrapperState.wasMultiple = !!i.multiple;
                var v = i.value;
                v != null
                  ? Sr(o, !!i.multiple, v, !1)
                  : c !== !!i.multiple &&
                    (i.defaultValue != null
                      ? Sr(o, !!i.multiple, i.defaultValue, !0)
                      : Sr(o, !!i.multiple, i.multiple ? [] : "", !1));
            }
            o[Io] = i;
          } catch (g) {
            fe(e, e.return, g);
          }
      }
      break;
    case 6:
      if ((ut(t, e), Ct(e), r & 4)) {
        if (e.stateNode === null) throw Error(R(162));
        (o = e.stateNode), (i = e.memoizedProps);
        try {
          o.nodeValue = i;
        } catch (g) {
          fe(e, e.return, g);
        }
      }
      break;
    case 3:
      if (
        (ut(t, e), Ct(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
      )
        try {
          jo(t.containerInfo);
        } catch (g) {
          fe(e, e.return, g);
        }
      break;
    case 4:
      ut(t, e), Ct(e);
      break;
    case 13:
      ut(t, e),
        Ct(e),
        (o = e.child),
        o.flags & 8192 &&
          ((i = o.memoizedState !== null),
          (o.stateNode.isHidden = i),
          !i ||
            (o.alternate !== null && o.alternate.memoizedState !== null) ||
            (Ou = pe())),
        r & 4 && hd(e);
      break;
    case 22:
      if (
        ((d = n !== null && n.memoizedState !== null),
        e.mode & 1 ? ((je = (u = je) || d), ut(t, e), (je = u)) : ut(t, e),
        Ct(e),
        r & 8192)
      ) {
        if (
          ((u = e.memoizedState !== null),
          (e.stateNode.isHidden = u) && !d && e.mode & 1)
        )
          for (M = e, d = e.child; d !== null; ) {
            for (f = M = d; M !== null; ) {
              switch (((c = M), (v = c.child), c.tag)) {
                case 0:
                case 11:
                case 14:
                case 15:
                  ko(4, c, c.return);
                  break;
                case 1:
                  xr(c, c.return);
                  var x = c.stateNode;
                  if (typeof x.componentWillUnmount == "function") {
                    (r = c), (n = c.return);
                    try {
                      (t = r),
                        (x.props = t.memoizedProps),
                        (x.state = t.memoizedState),
                        x.componentWillUnmount();
                    } catch (g) {
                      fe(r, n, g);
                    }
                  }
                  break;
                case 5:
                  xr(c, c.return);
                  break;
                case 22:
                  if (c.memoizedState !== null) {
                    gd(f);
                    continue;
                  }
              }
              v !== null ? ((v.return = c), (M = v)) : gd(f);
            }
            d = d.sibling;
          }
        e: for (d = null, f = e; ; ) {
          if (f.tag === 5) {
            if (d === null) {
              d = f;
              try {
                (o = f.stateNode),
                  u
                    ? ((i = o.style),
                      typeof i.setProperty == "function"
                        ? i.setProperty("display", "none", "important")
                        : (i.display = "none"))
                    : ((l = f.stateNode),
                      (a = f.memoizedProps.style),
                      (s =
                        a != null && a.hasOwnProperty("display")
                          ? a.display
                          : null),
                      (l.style.display = Ff("display", s)));
              } catch (g) {
                fe(e, e.return, g);
              }
            }
          } else if (f.tag === 6) {
            if (d === null)
              try {
                f.stateNode.nodeValue = u ? "" : f.memoizedProps;
              } catch (g) {
                fe(e, e.return, g);
              }
          } else if (
            ((f.tag !== 22 && f.tag !== 23) ||
              f.memoizedState === null ||
              f === e) &&
            f.child !== null
          ) {
            (f.child.return = f), (f = f.child);
            continue;
          }
          if (f === e) break e;
          for (; f.sibling === null; ) {
            if (f.return === null || f.return === e) break e;
            d === f && (d = null), (f = f.return);
          }
          d === f && (d = null), (f.sibling.return = f.return), (f = f.sibling);
        }
      }
      break;
    case 19:
      ut(t, e), Ct(e), r & 4 && hd(e);
      break;
    case 21:
      break;
    default:
      ut(t, e), Ct(e);
  }
}
function Ct(e) {
  var t = e.flags;
  if (t & 2) {
    try {
      e: {
        for (var n = e.return; n !== null; ) {
          if (dh(n)) {
            var r = n;
            break e;
          }
          n = n.return;
        }
        throw Error(R(160));
      }
      switch (r.tag) {
        case 5:
          var o = r.stateNode;
          r.flags & 32 && (No(o, ""), (r.flags &= -33));
          var i = pd(e);
          Na(e, i, o);
          break;
        case 3:
        case 4:
          var s = r.stateNode.containerInfo,
            l = pd(e);
          Pa(e, l, s);
          break;
        default:
          throw Error(R(161));
      }
    } catch (a) {
      fe(e, e.return, a);
    }
    e.flags &= -3;
  }
  t & 4096 && (e.flags &= -4097);
}
function Fv(e, t, n) {
  (M = e), hh(e);
}
function hh(e, t, n) {
  for (var r = (e.mode & 1) !== 0; M !== null; ) {
    var o = M,
      i = o.child;
    if (o.tag === 22 && r) {
      var s = o.memoizedState !== null || bi;
      if (!s) {
        var l = o.alternate,
          a = (l !== null && l.memoizedState !== null) || je;
        l = bi;
        var u = je;
        if (((bi = s), (je = a) && !u))
          for (M = o; M !== null; )
            (s = M),
              (a = s.child),
              s.tag === 22 && s.memoizedState !== null
                ? vd(o)
                : a !== null
                ? ((a.return = s), (M = a))
                : vd(o);
        for (; i !== null; ) (M = i), hh(i), (i = i.sibling);
        (M = o), (bi = l), (je = u);
      }
      md(e);
    } else
      o.subtreeFlags & 8772 && i !== null ? ((i.return = o), (M = i)) : md(e);
  }
}
function md(e) {
  for (; M !== null; ) {
    var t = M;
    if (t.flags & 8772) {
      var n = t.alternate;
      try {
        if (t.flags & 8772)
          switch (t.tag) {
            case 0:
            case 11:
            case 15:
              je || Is(5, t);
              break;
            case 1:
              var r = t.stateNode;
              if (t.flags & 4 && !je)
                if (n === null) r.componentDidMount();
                else {
                  var o =
                    t.elementType === t.type
                      ? n.memoizedProps
                      : ct(t.type, n.memoizedProps);
                  r.componentDidUpdate(
                    o,
                    n.memoizedState,
                    r.__reactInternalSnapshotBeforeUpdate
                  );
                }
              var i = t.updateQueue;
              i !== null && Zc(t, i, r);
              break;
            case 3:
              var s = t.updateQueue;
              if (s !== null) {
                if (((n = null), t.child !== null))
                  switch (t.child.tag) {
                    case 5:
                      n = t.child.stateNode;
                      break;
                    case 1:
                      n = t.child.stateNode;
                  }
                Zc(t, s, n);
              }
              break;
            case 5:
              var l = t.stateNode;
              if (n === null && t.flags & 4) {
                n = l;
                var a = t.memoizedProps;
                switch (t.type) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    a.autoFocus && n.focus();
                    break;
                  case "img":
                    a.src && (n.src = a.src);
                }
              }
              break;
            case 6:
              break;
            case 4:
              break;
            case 12:
              break;
            case 13:
              if (t.memoizedState === null) {
                var u = t.alternate;
                if (u !== null) {
                  var d = u.memoizedState;
                  if (d !== null) {
                    var f = d.dehydrated;
                    f !== null && jo(f);
                  }
                }
              }
              break;
            case 19:
            case 17:
            case 21:
            case 22:
            case 23:
            case 25:
              break;
            default:
              throw Error(R(163));
          }
        je || (t.flags & 512 && ba(t));
      } catch (c) {
        fe(t, t.return, c);
      }
    }
    if (t === e) {
      M = null;
      break;
    }
    if (((n = t.sibling), n !== null)) {
      (n.return = t.return), (M = n);
      break;
    }
    M = t.return;
  }
}
function gd(e) {
  for (; M !== null; ) {
    var t = M;
    if (t === e) {
      M = null;
      break;
    }
    var n = t.sibling;
    if (n !== null) {
      (n.return = t.return), (M = n);
      break;
    }
    M = t.return;
  }
}
function vd(e) {
  for (; M !== null; ) {
    var t = M;
    try {
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          var n = t.return;
          try {
            Is(4, t);
          } catch (a) {
            fe(t, n, a);
          }
          break;
        case 1:
          var r = t.stateNode;
          if (typeof r.componentDidMount == "function") {
            var o = t.return;
            try {
              r.componentDidMount();
            } catch (a) {
              fe(t, o, a);
            }
          }
          var i = t.return;
          try {
            ba(t);
          } catch (a) {
            fe(t, i, a);
          }
          break;
        case 5:
          var s = t.return;
          try {
            ba(t);
          } catch (a) {
            fe(t, s, a);
          }
      }
    } catch (a) {
      fe(t, t.return, a);
    }
    if (t === e) {
      M = null;
      break;
    }
    var l = t.sibling;
    if (l !== null) {
      (l.return = t.return), (M = l);
      break;
    }
    M = t.return;
  }
}
var $v = Math.ceil,
  hs = Yt.ReactCurrentDispatcher,
  ju = Yt.ReactCurrentOwner,
  it = Yt.ReactCurrentBatchConfig,
  X = 0,
  we = null,
  he = null,
  Ee = 0,
  Ke = 0,
  wr = Mn(0),
  ye = 0,
  Bo = null,
  qn = 0,
  Ds = 0,
  _u = 0,
  Eo = null,
  Fe = null,
  Ou = 0,
  Vr = 1 / 0,
  Dt = null,
  ms = !1,
  Ta = null,
  En = null,
  Pi = !1,
  gn = null,
  gs = 0,
  Co = 0,
  Ra = null,
  Bi = -1,
  Wi = 0;
function Ie() {
  return X & 6 ? pe() : Bi !== -1 ? Bi : (Bi = pe());
}
function Cn(e) {
  return e.mode & 1
    ? X & 2 && Ee !== 0
      ? Ee & -Ee
      : Ev.transition !== null
      ? (Wi === 0 && (Wi = Jf()), Wi)
      : ((e = Z),
        e !== 0 || ((e = window.event), (e = e === void 0 ? 16 : ip(e.type))),
        e)
    : 1;
}
function gt(e, t, n, r) {
  if (50 < Co) throw ((Co = 0), (Ra = null), Error(R(185)));
  Jo(e, n, r),
    (!(X & 2) || e !== we) &&
      (e === we && (!(X & 2) && (Ds |= n), ye === 4 && un(e, Ee)),
      We(e, r),
      n === 1 && X === 0 && !(t.mode & 1) && ((Vr = pe() + 500), Os && Ln()));
}
function We(e, t) {
  var n = e.callbackNode;
  E0(e, t);
  var r = Zi(e, e === we ? Ee : 0);
  if (r === 0)
    n !== null && Pc(n), (e.callbackNode = null), (e.callbackPriority = 0);
  else if (((t = r & -r), e.callbackPriority !== t)) {
    if ((n != null && Pc(n), t === 1))
      e.tag === 0 ? kv(yd.bind(null, e)) : Cp(yd.bind(null, e)),
        yv(function () {
          !(X & 6) && Ln();
        }),
        (n = null);
    else {
      switch (Zf(r)) {
        case 1:
          n = iu;
          break;
        case 4:
          n = Xf;
          break;
        case 16:
          n = Ji;
          break;
        case 536870912:
          n = qf;
          break;
        default:
          n = Ji;
      }
      n = kh(n, mh.bind(null, e));
    }
    (e.callbackPriority = t), (e.callbackNode = n);
  }
}
function mh(e, t) {
  if (((Bi = -1), (Wi = 0), X & 6)) throw Error(R(327));
  var n = e.callbackNode;
  if (Pr() && e.callbackNode !== n) return null;
  var r = Zi(e, e === we ? Ee : 0);
  if (r === 0) return null;
  if (r & 30 || r & e.expiredLanes || t) t = vs(e, r);
  else {
    t = r;
    var o = X;
    X |= 2;
    var i = vh();
    (we !== e || Ee !== t) && ((Dt = null), (Vr = pe() + 500), Qn(e, t));
    do
      try {
        Wv();
        break;
      } catch (l) {
        gh(e, l);
      }
    while (!0);
    yu(),
      (hs.current = i),
      (X = o),
      he !== null ? (t = 0) : ((we = null), (Ee = 0), (t = ye));
  }
  if (t !== 0) {
    if (
      (t === 2 && ((o = na(e)), o !== 0 && ((r = o), (t = Aa(e, o)))), t === 1)
    )
      throw ((n = Bo), Qn(e, 0), un(e, r), We(e, pe()), n);
    if (t === 6) un(e, r);
    else {
      if (
        ((o = e.current.alternate),
        !(r & 30) &&
          !Uv(o) &&
          ((t = vs(e, r)),
          t === 2 && ((i = na(e)), i !== 0 && ((r = i), (t = Aa(e, i)))),
          t === 1))
      )
        throw ((n = Bo), Qn(e, 0), un(e, r), We(e, pe()), n);
      switch (((e.finishedWork = o), (e.finishedLanes = r), t)) {
        case 0:
        case 1:
          throw Error(R(345));
        case 2:
          zn(e, Fe, Dt);
          break;
        case 3:
          if (
            (un(e, r), (r & 130023424) === r && ((t = Ou + 500 - pe()), 10 < t))
          ) {
            if (Zi(e, 0) !== 0) break;
            if (((o = e.suspendedLanes), (o & r) !== r)) {
              Ie(), (e.pingedLanes |= e.suspendedLanes & o);
              break;
            }
            e.timeoutHandle = ca(zn.bind(null, e, Fe, Dt), t);
            break;
          }
          zn(e, Fe, Dt);
          break;
        case 4:
          if ((un(e, r), (r & 4194240) === r)) break;
          for (t = e.eventTimes, o = -1; 0 < r; ) {
            var s = 31 - mt(r);
            (i = 1 << s), (s = t[s]), s > o && (o = s), (r &= ~i);
          }
          if (
            ((r = o),
            (r = pe() - r),
            (r =
              (120 > r
                ? 120
                : 480 > r
                ? 480
                : 1080 > r
                ? 1080
                : 1920 > r
                ? 1920
                : 3e3 > r
                ? 3e3
                : 4320 > r
                ? 4320
                : 1960 * $v(r / 1960)) - r),
            10 < r)
          ) {
            e.timeoutHandle = ca(zn.bind(null, e, Fe, Dt), r);
            break;
          }
          zn(e, Fe, Dt);
          break;
        case 5:
          zn(e, Fe, Dt);
          break;
        default:
          throw Error(R(329));
      }
    }
  }
  return We(e, pe()), e.callbackNode === n ? mh.bind(null, e) : null;
}
function Aa(e, t) {
  var n = Eo;
  return (
    e.current.memoizedState.isDehydrated && (Qn(e, t).flags |= 256),
    (e = vs(e, t)),
    e !== 2 && ((t = Fe), (Fe = n), t !== null && ja(t)),
    e
  );
}
function ja(e) {
  Fe === null ? (Fe = e) : Fe.push.apply(Fe, e);
}
function Uv(e) {
  for (var t = e; ; ) {
    if (t.flags & 16384) {
      var n = t.updateQueue;
      if (n !== null && ((n = n.stores), n !== null))
        for (var r = 0; r < n.length; r++) {
          var o = n[r],
            i = o.getSnapshot;
          o = o.value;
          try {
            if (!vt(i(), o)) return !1;
          } catch {
            return !1;
          }
        }
    }
    if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
      (n.return = t), (t = n);
    else {
      if (t === e) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e) return !0;
        t = t.return;
      }
      (t.sibling.return = t.return), (t = t.sibling);
    }
  }
  return !0;
}
function un(e, t) {
  for (
    t &= ~_u,
      t &= ~Ds,
      e.suspendedLanes |= t,
      e.pingedLanes &= ~t,
      e = e.expirationTimes;
    0 < t;

  ) {
    var n = 31 - mt(t),
      r = 1 << n;
    (e[n] = -1), (t &= ~r);
  }
}
function yd(e) {
  if (X & 6) throw Error(R(327));
  Pr();
  var t = Zi(e, 0);
  if (!(t & 1)) return We(e, pe()), null;
  var n = vs(e, t);
  if (e.tag !== 0 && n === 2) {
    var r = na(e);
    r !== 0 && ((t = r), (n = Aa(e, r)));
  }
  if (n === 1) throw ((n = Bo), Qn(e, 0), un(e, t), We(e, pe()), n);
  if (n === 6) throw Error(R(345));
  return (
    (e.finishedWork = e.current.alternate),
    (e.finishedLanes = t),
    zn(e, Fe, Dt),
    We(e, pe()),
    null
  );
}
function Mu(e, t) {
  var n = X;
  X |= 1;
  try {
    return e(t);
  } finally {
    (X = n), X === 0 && ((Vr = pe() + 500), Os && Ln());
  }
}
function Jn(e) {
  gn !== null && gn.tag === 0 && !(X & 6) && Pr();
  var t = X;
  X |= 1;
  var n = it.transition,
    r = Z;
  try {
    if (((it.transition = null), (Z = 1), e)) return e();
  } finally {
    (Z = r), (it.transition = n), (X = t), !(X & 6) && Ln();
  }
}
function Lu() {
  (Ke = wr.current), ie(wr);
}
function Qn(e, t) {
  (e.finishedWork = null), (e.finishedLanes = 0);
  var n = e.timeoutHandle;
  if ((n !== -1 && ((e.timeoutHandle = -1), vv(n)), he !== null))
    for (n = he.return; n !== null; ) {
      var r = n;
      switch ((mu(r), r.tag)) {
        case 1:
          (r = r.type.childContextTypes), r != null && os();
          break;
        case 3:
          Br(), ie(Ue), ie(_e), Cu();
          break;
        case 5:
          Eu(r);
          break;
        case 4:
          Br();
          break;
        case 13:
          ie(ae);
          break;
        case 19:
          ie(ae);
          break;
        case 10:
          xu(r.type._context);
          break;
        case 22:
        case 23:
          Lu();
      }
      n = n.return;
    }
  if (
    ((we = e),
    (he = e = bn(e.current, null)),
    (Ee = Ke = t),
    (ye = 0),
    (Bo = null),
    (_u = Ds = qn = 0),
    (Fe = Eo = null),
    $n !== null)
  ) {
    for (t = 0; t < $n.length; t++)
      if (((n = $n[t]), (r = n.interleaved), r !== null)) {
        n.interleaved = null;
        var o = r.next,
          i = n.pending;
        if (i !== null) {
          var s = i.next;
          (i.next = o), (r.next = s);
        }
        n.pending = r;
      }
    $n = null;
  }
  return e;
}
function gh(e, t) {
  do {
    var n = he;
    try {
      if ((yu(), (Fi.current = ps), fs)) {
        for (var r = ue.memoizedState; r !== null; ) {
          var o = r.queue;
          o !== null && (o.pending = null), (r = r.next);
        }
        fs = !1;
      }
      if (
        ((Xn = 0),
        (xe = ge = ue = null),
        (So = !1),
        (Fo = 0),
        (ju.current = null),
        n === null || n.return === null)
      ) {
        (ye = 1), (Bo = t), (he = null);
        break;
      }
      e: {
        var i = e,
          s = n.return,
          l = n,
          a = t;
        if (
          ((t = Ee),
          (l.flags |= 32768),
          a !== null && typeof a == "object" && typeof a.then == "function")
        ) {
          var u = a,
            d = l,
            f = d.tag;
          if (!(d.mode & 1) && (f === 0 || f === 11 || f === 15)) {
            var c = d.alternate;
            c
              ? ((d.updateQueue = c.updateQueue),
                (d.memoizedState = c.memoizedState),
                (d.lanes = c.lanes))
              : ((d.updateQueue = null), (d.memoizedState = null));
          }
          var v = id(s);
          if (v !== null) {
            (v.flags &= -257),
              sd(v, s, l, i, t),
              v.mode & 1 && od(i, u, t),
              (t = v),
              (a = u);
            var x = t.updateQueue;
            if (x === null) {
              var g = new Set();
              g.add(a), (t.updateQueue = g);
            } else x.add(a);
            break e;
          } else {
            if (!(t & 1)) {
              od(i, u, t), Iu();
              break e;
            }
            a = Error(R(426));
          }
        } else if (se && l.mode & 1) {
          var S = id(s);
          if (S !== null) {
            !(S.flags & 65536) && (S.flags |= 256),
              sd(S, s, l, i, t),
              gu(Wr(a, l));
            break e;
          }
        }
        (i = a = Wr(a, l)),
          ye !== 4 && (ye = 2),
          Eo === null ? (Eo = [i]) : Eo.push(i),
          (i = s);
        do {
          switch (i.tag) {
            case 3:
              (i.flags |= 65536), (t &= -t), (i.lanes |= t);
              var h = Zp(i, a, t);
              Jc(i, h);
              break e;
            case 1:
              l = a;
              var p = i.type,
                m = i.stateNode;
              if (
                !(i.flags & 128) &&
                (typeof p.getDerivedStateFromError == "function" ||
                  (m !== null &&
                    typeof m.componentDidCatch == "function" &&
                    (En === null || !En.has(m))))
              ) {
                (i.flags |= 65536), (t &= -t), (i.lanes |= t);
                var k = eh(i, l, t);
                Jc(i, k);
                break e;
              }
          }
          i = i.return;
        } while (i !== null);
      }
      xh(n);
    } catch (E) {
      (t = E), he === n && n !== null && (he = n = n.return);
      continue;
    }
    break;
  } while (!0);
}
function vh() {
  var e = hs.current;
  return (hs.current = ps), e === null ? ps : e;
}
function Iu() {
  (ye === 0 || ye === 3 || ye === 2) && (ye = 4),
    we === null || (!(qn & 268435455) && !(Ds & 268435455)) || un(we, Ee);
}
function vs(e, t) {
  var n = X;
  X |= 2;
  var r = vh();
  (we !== e || Ee !== t) && ((Dt = null), Qn(e, t));
  do
    try {
      Bv();
      break;
    } catch (o) {
      gh(e, o);
    }
  while (!0);
  if ((yu(), (X = n), (hs.current = r), he !== null)) throw Error(R(261));
  return (we = null), (Ee = 0), ye;
}
function Bv() {
  for (; he !== null; ) yh(he);
}
function Wv() {
  for (; he !== null && !h0(); ) yh(he);
}
function yh(e) {
  var t = Sh(e.alternate, e, Ke);
  (e.memoizedProps = e.pendingProps),
    t === null ? xh(e) : (he = t),
    (ju.current = null);
}
function xh(e) {
  var t = e;
  do {
    var n = t.alternate;
    if (((e = t.return), t.flags & 32768)) {
      if (((n = Iv(n, t)), n !== null)) {
        (n.flags &= 32767), (he = n);
        return;
      }
      if (e !== null)
        (e.flags |= 32768), (e.subtreeFlags = 0), (e.deletions = null);
      else {
        (ye = 6), (he = null);
        return;
      }
    } else if (((n = Lv(n, t, Ke)), n !== null)) {
      he = n;
      return;
    }
    if (((t = t.sibling), t !== null)) {
      he = t;
      return;
    }
    he = t = e;
  } while (t !== null);
  ye === 0 && (ye = 5);
}
function zn(e, t, n) {
  var r = Z,
    o = it.transition;
  try {
    (it.transition = null), (Z = 1), Vv(e, t, n, r);
  } finally {
    (it.transition = o), (Z = r);
  }
  return null;
}
function Vv(e, t, n, r) {
  do Pr();
  while (gn !== null);
  if (X & 6) throw Error(R(327));
  n = e.finishedWork;
  var o = e.finishedLanes;
  if (n === null) return null;
  if (((e.finishedWork = null), (e.finishedLanes = 0), n === e.current))
    throw Error(R(177));
  (e.callbackNode = null), (e.callbackPriority = 0);
  var i = n.lanes | n.childLanes;
  if (
    (C0(e, i),
    e === we && ((he = we = null), (Ee = 0)),
    (!(n.subtreeFlags & 2064) && !(n.flags & 2064)) ||
      Pi ||
      ((Pi = !0),
      kh(Ji, function () {
        return Pr(), null;
      })),
    (i = (n.flags & 15990) !== 0),
    n.subtreeFlags & 15990 || i)
  ) {
    (i = it.transition), (it.transition = null);
    var s = Z;
    Z = 1;
    var l = X;
    (X |= 4),
      (ju.current = null),
      zv(e, n),
      ph(n, e),
      cv(aa),
      (es = !!la),
      (aa = la = null),
      (e.current = n),
      Fv(n),
      m0(),
      (X = l),
      (Z = s),
      (it.transition = i);
  } else e.current = n;
  if (
    (Pi && ((Pi = !1), (gn = e), (gs = o)),
    (i = e.pendingLanes),
    i === 0 && (En = null),
    y0(n.stateNode),
    We(e, pe()),
    t !== null)
  )
    for (r = e.onRecoverableError, n = 0; n < t.length; n++)
      (o = t[n]), r(o.value, { componentStack: o.stack, digest: o.digest });
  if (ms) throw ((ms = !1), (e = Ta), (Ta = null), e);
  return (
    gs & 1 && e.tag !== 0 && Pr(),
    (i = e.pendingLanes),
    i & 1 ? (e === Ra ? Co++ : ((Co = 0), (Ra = e))) : (Co = 0),
    Ln(),
    null
  );
}
function Pr() {
  if (gn !== null) {
    var e = Zf(gs),
      t = it.transition,
      n = Z;
    try {
      if (((it.transition = null), (Z = 16 > e ? 16 : e), gn === null))
        var r = !1;
      else {
        if (((e = gn), (gn = null), (gs = 0), X & 6)) throw Error(R(331));
        var o = X;
        for (X |= 4, M = e.current; M !== null; ) {
          var i = M,
            s = i.child;
          if (M.flags & 16) {
            var l = i.deletions;
            if (l !== null) {
              for (var a = 0; a < l.length; a++) {
                var u = l[a];
                for (M = u; M !== null; ) {
                  var d = M;
                  switch (d.tag) {
                    case 0:
                    case 11:
                    case 15:
                      ko(8, d, i);
                  }
                  var f = d.child;
                  if (f !== null) (f.return = d), (M = f);
                  else
                    for (; M !== null; ) {
                      d = M;
                      var c = d.sibling,
                        v = d.return;
                      if ((ch(d), d === u)) {
                        M = null;
                        break;
                      }
                      if (c !== null) {
                        (c.return = v), (M = c);
                        break;
                      }
                      M = v;
                    }
                }
              }
              var x = i.alternate;
              if (x !== null) {
                var g = x.child;
                if (g !== null) {
                  x.child = null;
                  do {
                    var S = g.sibling;
                    (g.sibling = null), (g = S);
                  } while (g !== null);
                }
              }
              M = i;
            }
          }
          if (i.subtreeFlags & 2064 && s !== null) (s.return = i), (M = s);
          else
            e: for (; M !== null; ) {
              if (((i = M), i.flags & 2048))
                switch (i.tag) {
                  case 0:
                  case 11:
                  case 15:
                    ko(9, i, i.return);
                }
              var h = i.sibling;
              if (h !== null) {
                (h.return = i.return), (M = h);
                break e;
              }
              M = i.return;
            }
        }
        var p = e.current;
        for (M = p; M !== null; ) {
          s = M;
          var m = s.child;
          if (s.subtreeFlags & 2064 && m !== null) (m.return = s), (M = m);
          else
            e: for (s = p; M !== null; ) {
              if (((l = M), l.flags & 2048))
                try {
                  switch (l.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Is(9, l);
                  }
                } catch (E) {
                  fe(l, l.return, E);
                }
              if (l === s) {
                M = null;
                break e;
              }
              var k = l.sibling;
              if (k !== null) {
                (k.return = l.return), (M = k);
                break e;
              }
              M = l.return;
            }
        }
        if (
          ((X = o), Ln(), At && typeof At.onPostCommitFiberRoot == "function")
        )
          try {
            At.onPostCommitFiberRoot(Ts, e);
          } catch {}
        r = !0;
      }
      return r;
    } finally {
      (Z = n), (it.transition = t);
    }
  }
  return !1;
}
function xd(e, t, n) {
  (t = Wr(n, t)),
    (t = Zp(e, t, 1)),
    (e = kn(e, t, 1)),
    (t = Ie()),
    e !== null && (Jo(e, 1, t), We(e, t));
}
function fe(e, t, n) {
  if (e.tag === 3) xd(e, e, n);
  else
    for (; t !== null; ) {
      if (t.tag === 3) {
        xd(t, e, n);
        break;
      } else if (t.tag === 1) {
        var r = t.stateNode;
        if (
          typeof t.type.getDerivedStateFromError == "function" ||
          (typeof r.componentDidCatch == "function" &&
            (En === null || !En.has(r)))
        ) {
          (e = Wr(n, e)),
            (e = eh(t, e, 1)),
            (t = kn(t, e, 1)),
            (e = Ie()),
            t !== null && (Jo(t, 1, e), We(t, e));
          break;
        }
      }
      t = t.return;
    }
}
function Hv(e, t, n) {
  var r = e.pingCache;
  r !== null && r.delete(t),
    (t = Ie()),
    (e.pingedLanes |= e.suspendedLanes & n),
    we === e &&
      (Ee & n) === n &&
      (ye === 4 || (ye === 3 && (Ee & 130023424) === Ee && 500 > pe() - Ou)
        ? Qn(e, 0)
        : (_u |= n)),
    We(e, t);
}
function wh(e, t) {
  t === 0 &&
    (e.mode & 1
      ? ((t = gi), (gi <<= 1), !(gi & 130023424) && (gi = 4194304))
      : (t = 1));
  var n = Ie();
  (e = Vt(e, t)), e !== null && (Jo(e, t, n), We(e, n));
}
function Qv(e) {
  var t = e.memoizedState,
    n = 0;
  t !== null && (n = t.retryLane), wh(e, n);
}
function Kv(e, t) {
  var n = 0;
  switch (e.tag) {
    case 13:
      var r = e.stateNode,
        o = e.memoizedState;
      o !== null && (n = o.retryLane);
      break;
    case 19:
      r = e.stateNode;
      break;
    default:
      throw Error(R(314));
  }
  r !== null && r.delete(t), wh(e, n);
}
var Sh;
Sh = function (e, t, n) {
  if (e !== null)
    if (e.memoizedProps !== t.pendingProps || Ue.current) $e = !0;
    else {
      if (!(e.lanes & n) && !(t.flags & 128)) return ($e = !1), Mv(e, t, n);
      $e = !!(e.flags & 131072);
    }
  else ($e = !1), se && t.flags & 1048576 && bp(t, ls, t.index);
  switch (((t.lanes = 0), t.tag)) {
    case 2:
      var r = t.type;
      Ui(e, t), (e = t.pendingProps);
      var o = Fr(t, _e.current);
      br(t, n), (o = Pu(null, t, r, e, o, n));
      var i = Nu();
      return (
        (t.flags |= 1),
        typeof o == "object" &&
        o !== null &&
        typeof o.render == "function" &&
        o.$$typeof === void 0
          ? ((t.tag = 1),
            (t.memoizedState = null),
            (t.updateQueue = null),
            Be(r) ? ((i = !0), is(t)) : (i = !1),
            (t.memoizedState =
              o.state !== null && o.state !== void 0 ? o.state : null),
            Su(t),
            (o.updater = Ls),
            (t.stateNode = o),
            (o._reactInternals = t),
            va(t, r, e, n),
            (t = wa(null, t, r, !0, i, n)))
          : ((t.tag = 0), se && i && hu(t), Me(null, t, o, n), (t = t.child)),
        t
      );
    case 16:
      r = t.elementType;
      e: {
        switch (
          (Ui(e, t),
          (e = t.pendingProps),
          (o = r._init),
          (r = o(r._payload)),
          (t.type = r),
          (o = t.tag = Yv(r)),
          (e = ct(r, e)),
          o)
        ) {
          case 0:
            t = xa(null, t, r, e, n);
            break e;
          case 1:
            t = ud(null, t, r, e, n);
            break e;
          case 11:
            t = ld(null, t, r, e, n);
            break e;
          case 14:
            t = ad(null, t, r, ct(r.type, e), n);
            break e;
        }
        throw Error(R(306, r, ""));
      }
      return t;
    case 0:
      return (
        (r = t.type),
        (o = t.pendingProps),
        (o = t.elementType === r ? o : ct(r, o)),
        xa(e, t, r, o, n)
      );
    case 1:
      return (
        (r = t.type),
        (o = t.pendingProps),
        (o = t.elementType === r ? o : ct(r, o)),
        ud(e, t, r, o, n)
      );
    case 3:
      e: {
        if ((oh(t), e === null)) throw Error(R(387));
        (r = t.pendingProps),
          (i = t.memoizedState),
          (o = i.element),
          jp(e, t),
          cs(t, r, null, n);
        var s = t.memoizedState;
        if (((r = s.element), i.isDehydrated))
          if (
            ((i = {
              element: r,
              isDehydrated: !1,
              cache: s.cache,
              pendingSuspenseBoundaries: s.pendingSuspenseBoundaries,
              transitions: s.transitions,
            }),
            (t.updateQueue.baseState = i),
            (t.memoizedState = i),
            t.flags & 256)
          ) {
            (o = Wr(Error(R(423)), t)), (t = cd(e, t, r, n, o));
            break e;
          } else if (r !== o) {
            (o = Wr(Error(R(424)), t)), (t = cd(e, t, r, n, o));
            break e;
          } else
            for (
              Ye = Sn(t.stateNode.containerInfo.firstChild),
                Xe = t,
                se = !0,
                ht = null,
                n = Rp(t, null, r, n),
                t.child = n;
              n;

            )
              (n.flags = (n.flags & -3) | 4096), (n = n.sibling);
        else {
          if (($r(), r === o)) {
            t = Ht(e, t, n);
            break e;
          }
          Me(e, t, r, n);
        }
        t = t.child;
      }
      return t;
    case 5:
      return (
        _p(t),
        e === null && ha(t),
        (r = t.type),
        (o = t.pendingProps),
        (i = e !== null ? e.memoizedProps : null),
        (s = o.children),
        ua(r, o) ? (s = null) : i !== null && ua(r, i) && (t.flags |= 32),
        rh(e, t),
        Me(e, t, s, n),
        t.child
      );
    case 6:
      return e === null && ha(t), null;
    case 13:
      return ih(e, t, n);
    case 4:
      return (
        ku(t, t.stateNode.containerInfo),
        (r = t.pendingProps),
        e === null ? (t.child = Ur(t, null, r, n)) : Me(e, t, r, n),
        t.child
      );
    case 11:
      return (
        (r = t.type),
        (o = t.pendingProps),
        (o = t.elementType === r ? o : ct(r, o)),
        ld(e, t, r, o, n)
      );
    case 7:
      return Me(e, t, t.pendingProps, n), t.child;
    case 8:
      return Me(e, t, t.pendingProps.children, n), t.child;
    case 12:
      return Me(e, t, t.pendingProps.children, n), t.child;
    case 10:
      e: {
        if (
          ((r = t.type._context),
          (o = t.pendingProps),
          (i = t.memoizedProps),
          (s = o.value),
          te(as, r._currentValue),
          (r._currentValue = s),
          i !== null)
        )
          if (vt(i.value, s)) {
            if (i.children === o.children && !Ue.current) {
              t = Ht(e, t, n);
              break e;
            }
          } else
            for (i = t.child, i !== null && (i.return = t); i !== null; ) {
              var l = i.dependencies;
              if (l !== null) {
                s = i.child;
                for (var a = l.firstContext; a !== null; ) {
                  if (a.context === r) {
                    if (i.tag === 1) {
                      (a = Ut(-1, n & -n)), (a.tag = 2);
                      var u = i.updateQueue;
                      if (u !== null) {
                        u = u.shared;
                        var d = u.pending;
                        d === null
                          ? (a.next = a)
                          : ((a.next = d.next), (d.next = a)),
                          (u.pending = a);
                      }
                    }
                    (i.lanes |= n),
                      (a = i.alternate),
                      a !== null && (a.lanes |= n),
                      ma(i.return, n, t),
                      (l.lanes |= n);
                    break;
                  }
                  a = a.next;
                }
              } else if (i.tag === 10) s = i.type === t.type ? null : i.child;
              else if (i.tag === 18) {
                if (((s = i.return), s === null)) throw Error(R(341));
                (s.lanes |= n),
                  (l = s.alternate),
                  l !== null && (l.lanes |= n),
                  ma(s, n, t),
                  (s = i.sibling);
              } else s = i.child;
              if (s !== null) s.return = i;
              else
                for (s = i; s !== null; ) {
                  if (s === t) {
                    s = null;
                    break;
                  }
                  if (((i = s.sibling), i !== null)) {
                    (i.return = s.return), (s = i);
                    break;
                  }
                  s = s.return;
                }
              i = s;
            }
        Me(e, t, o.children, n), (t = t.child);
      }
      return t;
    case 9:
      return (
        (o = t.type),
        (r = t.pendingProps.children),
        br(t, n),
        (o = st(o)),
        (r = r(o)),
        (t.flags |= 1),
        Me(e, t, r, n),
        t.child
      );
    case 14:
      return (
        (r = t.type),
        (o = ct(r, t.pendingProps)),
        (o = ct(r.type, o)),
        ad(e, t, r, o, n)
      );
    case 15:
      return th(e, t, t.type, t.pendingProps, n);
    case 17:
      return (
        (r = t.type),
        (o = t.pendingProps),
        (o = t.elementType === r ? o : ct(r, o)),
        Ui(e, t),
        (t.tag = 1),
        Be(r) ? ((e = !0), is(t)) : (e = !1),
        br(t, n),
        Jp(t, r, o),
        va(t, r, o, n),
        wa(null, t, r, !0, e, n)
      );
    case 19:
      return sh(e, t, n);
    case 22:
      return nh(e, t, n);
  }
  throw Error(R(156, t.tag));
};
function kh(e, t) {
  return Yf(e, t);
}
function Gv(e, t, n, r) {
  (this.tag = e),
    (this.key = n),
    (this.sibling =
      this.child =
      this.return =
      this.stateNode =
      this.type =
      this.elementType =
        null),
    (this.index = 0),
    (this.ref = null),
    (this.pendingProps = t),
    (this.dependencies =
      this.memoizedState =
      this.updateQueue =
      this.memoizedProps =
        null),
    (this.mode = r),
    (this.subtreeFlags = this.flags = 0),
    (this.deletions = null),
    (this.childLanes = this.lanes = 0),
    (this.alternate = null);
}
function ot(e, t, n, r) {
  return new Gv(e, t, n, r);
}
function Du(e) {
  return (e = e.prototype), !(!e || !e.isReactComponent);
}
function Yv(e) {
  if (typeof e == "function") return Du(e) ? 1 : 0;
  if (e != null) {
    if (((e = e.$$typeof), e === nu)) return 11;
    if (e === ru) return 14;
  }
  return 2;
}
function bn(e, t) {
  var n = e.alternate;
  return (
    n === null
      ? ((n = ot(e.tag, t, e.key, e.mode)),
        (n.elementType = e.elementType),
        (n.type = e.type),
        (n.stateNode = e.stateNode),
        (n.alternate = e),
        (e.alternate = n))
      : ((n.pendingProps = t),
        (n.type = e.type),
        (n.flags = 0),
        (n.subtreeFlags = 0),
        (n.deletions = null)),
    (n.flags = e.flags & 14680064),
    (n.childLanes = e.childLanes),
    (n.lanes = e.lanes),
    (n.child = e.child),
    (n.memoizedProps = e.memoizedProps),
    (n.memoizedState = e.memoizedState),
    (n.updateQueue = e.updateQueue),
    (t = e.dependencies),
    (n.dependencies =
      t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
    (n.sibling = e.sibling),
    (n.index = e.index),
    (n.ref = e.ref),
    n
  );
}
function Vi(e, t, n, r, o, i) {
  var s = 2;
  if (((r = e), typeof e == "function")) Du(e) && (s = 1);
  else if (typeof e == "string") s = 5;
  else
    e: switch (e) {
      case cr:
        return Kn(n.children, o, i, t);
      case tu:
        (s = 8), (o |= 8);
        break;
      case Ul:
        return (
          (e = ot(12, n, t, o | 2)), (e.elementType = Ul), (e.lanes = i), e
        );
      case Bl:
        return (e = ot(13, n, t, o)), (e.elementType = Bl), (e.lanes = i), e;
      case Wl:
        return (e = ot(19, n, t, o)), (e.elementType = Wl), (e.lanes = i), e;
      case _f:
        return zs(n, o, i, t);
      default:
        if (typeof e == "object" && e !== null)
          switch (e.$$typeof) {
            case Af:
              s = 10;
              break e;
            case jf:
              s = 9;
              break e;
            case nu:
              s = 11;
              break e;
            case ru:
              s = 14;
              break e;
            case sn:
              (s = 16), (r = null);
              break e;
          }
        throw Error(R(130, e == null ? e : typeof e, ""));
    }
  return (
    (t = ot(s, n, t, o)), (t.elementType = e), (t.type = r), (t.lanes = i), t
  );
}
function Kn(e, t, n, r) {
  return (e = ot(7, e, r, t)), (e.lanes = n), e;
}
function zs(e, t, n, r) {
  return (
    (e = ot(22, e, r, t)),
    (e.elementType = _f),
    (e.lanes = n),
    (e.stateNode = { isHidden: !1 }),
    e
  );
}
function Rl(e, t, n) {
  return (e = ot(6, e, null, t)), (e.lanes = n), e;
}
function Al(e, t, n) {
  return (
    (t = ot(4, e.children !== null ? e.children : [], e.key, t)),
    (t.lanes = n),
    (t.stateNode = {
      containerInfo: e.containerInfo,
      pendingChildren: null,
      implementation: e.implementation,
    }),
    t
  );
}
function Xv(e, t, n, r, o) {
  (this.tag = t),
    (this.containerInfo = e),
    (this.finishedWork =
      this.pingCache =
      this.current =
      this.pendingChildren =
        null),
    (this.timeoutHandle = -1),
    (this.callbackNode = this.pendingContext = this.context = null),
    (this.callbackPriority = 0),
    (this.eventTimes = cl(0)),
    (this.expirationTimes = cl(-1)),
    (this.entangledLanes =
      this.finishedLanes =
      this.mutableReadLanes =
      this.expiredLanes =
      this.pingedLanes =
      this.suspendedLanes =
      this.pendingLanes =
        0),
    (this.entanglements = cl(0)),
    (this.identifierPrefix = r),
    (this.onRecoverableError = o),
    (this.mutableSourceEagerHydrationData = null);
}
function zu(e, t, n, r, o, i, s, l, a) {
  return (
    (e = new Xv(e, t, n, l, a)),
    t === 1 ? ((t = 1), i === !0 && (t |= 8)) : (t = 0),
    (i = ot(3, null, null, t)),
    (e.current = i),
    (i.stateNode = e),
    (i.memoizedState = {
      element: r,
      isDehydrated: n,
      cache: null,
      transitions: null,
      pendingSuspenseBoundaries: null,
    }),
    Su(i),
    e
  );
}
function qv(e, t, n) {
  var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
  return {
    $$typeof: ur,
    key: r == null ? null : "" + r,
    children: e,
    containerInfo: t,
    implementation: n,
  };
}
function Eh(e) {
  if (!e) return Tn;
  e = e._reactInternals;
  e: {
    if (tr(e) !== e || e.tag !== 1) throw Error(R(170));
    var t = e;
    do {
      switch (t.tag) {
        case 3:
          t = t.stateNode.context;
          break e;
        case 1:
          if (Be(t.type)) {
            t = t.stateNode.__reactInternalMemoizedMergedChildContext;
            break e;
          }
      }
      t = t.return;
    } while (t !== null);
    throw Error(R(171));
  }
  if (e.tag === 1) {
    var n = e.type;
    if (Be(n)) return Ep(e, n, t);
  }
  return t;
}
function Ch(e, t, n, r, o, i, s, l, a) {
  return (
    (e = zu(n, r, !0, e, o, i, s, l, a)),
    (e.context = Eh(null)),
    (n = e.current),
    (r = Ie()),
    (o = Cn(n)),
    (i = Ut(r, o)),
    (i.callback = t ?? null),
    kn(n, i, o),
    (e.current.lanes = o),
    Jo(e, o, r),
    We(e, r),
    e
  );
}
function Fs(e, t, n, r) {
  var o = t.current,
    i = Ie(),
    s = Cn(o);
  return (
    (n = Eh(n)),
    t.context === null ? (t.context = n) : (t.pendingContext = n),
    (t = Ut(i, s)),
    (t.payload = { element: e }),
    (r = r === void 0 ? null : r),
    r !== null && (t.callback = r),
    (e = kn(o, t, s)),
    e !== null && (gt(e, o, s, i), zi(e, o, s)),
    s
  );
}
function ys(e) {
  if (((e = e.current), !e.child)) return null;
  switch (e.child.tag) {
    case 5:
      return e.child.stateNode;
    default:
      return e.child.stateNode;
  }
}
function wd(e, t) {
  if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
    var n = e.retryLane;
    e.retryLane = n !== 0 && n < t ? n : t;
  }
}
function Fu(e, t) {
  wd(e, t), (e = e.alternate) && wd(e, t);
}
function Jv() {
  return null;
}
var bh =
  typeof reportError == "function"
    ? reportError
    : function (e) {
        console.error(e);
      };
function $u(e) {
  this._internalRoot = e;
}
$s.prototype.render = $u.prototype.render = function (e) {
  var t = this._internalRoot;
  if (t === null) throw Error(R(409));
  Fs(e, t, null, null);
};
$s.prototype.unmount = $u.prototype.unmount = function () {
  var e = this._internalRoot;
  if (e !== null) {
    this._internalRoot = null;
    var t = e.containerInfo;
    Jn(function () {
      Fs(null, e, null, null);
    }),
      (t[Wt] = null);
  }
};
function $s(e) {
  this._internalRoot = e;
}
$s.prototype.unstable_scheduleHydration = function (e) {
  if (e) {
    var t = np();
    e = { blockedOn: null, target: e, priority: t };
    for (var n = 0; n < an.length && t !== 0 && t < an[n].priority; n++);
    an.splice(n, 0, e), n === 0 && op(e);
  }
};
function Uu(e) {
  return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
}
function Us(e) {
  return !(
    !e ||
    (e.nodeType !== 1 &&
      e.nodeType !== 9 &&
      e.nodeType !== 11 &&
      (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
  );
}
function Sd() {}
function Zv(e, t, n, r, o) {
  if (o) {
    if (typeof r == "function") {
      var i = r;
      r = function () {
        var u = ys(s);
        i.call(u);
      };
    }
    var s = Ch(t, r, e, 0, null, !1, !1, "", Sd);
    return (
      (e._reactRootContainer = s),
      (e[Wt] = s.current),
      Mo(e.nodeType === 8 ? e.parentNode : e),
      Jn(),
      s
    );
  }
  for (; (o = e.lastChild); ) e.removeChild(o);
  if (typeof r == "function") {
    var l = r;
    r = function () {
      var u = ys(a);
      l.call(u);
    };
  }
  var a = zu(e, 0, !1, null, null, !1, !1, "", Sd);
  return (
    (e._reactRootContainer = a),
    (e[Wt] = a.current),
    Mo(e.nodeType === 8 ? e.parentNode : e),
    Jn(function () {
      Fs(t, a, n, r);
    }),
    a
  );
}
function Bs(e, t, n, r, o) {
  var i = n._reactRootContainer;
  if (i) {
    var s = i;
    if (typeof o == "function") {
      var l = o;
      o = function () {
        var a = ys(s);
        l.call(a);
      };
    }
    Fs(t, s, e, o);
  } else s = Zv(n, t, e, o, r);
  return ys(s);
}
ep = function (e) {
  switch (e.tag) {
    case 3:
      var t = e.stateNode;
      if (t.current.memoizedState.isDehydrated) {
        var n = ho(t.pendingLanes);
        n !== 0 &&
          (su(t, n | 1), We(t, pe()), !(X & 6) && ((Vr = pe() + 500), Ln()));
      }
      break;
    case 13:
      Jn(function () {
        var r = Vt(e, 1);
        if (r !== null) {
          var o = Ie();
          gt(r, e, 1, o);
        }
      }),
        Fu(e, 1);
  }
};
lu = function (e) {
  if (e.tag === 13) {
    var t = Vt(e, 134217728);
    if (t !== null) {
      var n = Ie();
      gt(t, e, 134217728, n);
    }
    Fu(e, 134217728);
  }
};
tp = function (e) {
  if (e.tag === 13) {
    var t = Cn(e),
      n = Vt(e, t);
    if (n !== null) {
      var r = Ie();
      gt(n, e, t, r);
    }
    Fu(e, t);
  }
};
np = function () {
  return Z;
};
rp = function (e, t) {
  var n = Z;
  try {
    return (Z = e), t();
  } finally {
    Z = n;
  }
};
Zl = function (e, t, n) {
  switch (t) {
    case "input":
      if ((Ql(e, n), (t = n.name), n.type === "radio" && t != null)) {
        for (n = e; n.parentNode; ) n = n.parentNode;
        for (
          n = n.querySelectorAll(
            "input[name=" + JSON.stringify("" + t) + '][type="radio"]'
          ),
            t = 0;
          t < n.length;
          t++
        ) {
          var r = n[t];
          if (r !== e && r.form === e.form) {
            var o = _s(r);
            if (!o) throw Error(R(90));
            Mf(r), Ql(r, o);
          }
        }
      }
      break;
    case "textarea":
      If(e, n);
      break;
    case "select":
      (t = n.value), t != null && Sr(e, !!n.multiple, t, !1);
  }
};
Wf = Mu;
Vf = Jn;
var ey = { usingClientEntryPoint: !1, Events: [ei, hr, _s, Uf, Bf, Mu] },
  ao = {
    findFiberByHostInstance: Fn,
    bundleType: 0,
    version: "18.3.1",
    rendererPackageName: "react-dom",
  },
  ty = {
    bundleType: ao.bundleType,
    version: ao.version,
    rendererPackageName: ao.rendererPackageName,
    rendererConfig: ao.rendererConfig,
    overrideHookState: null,
    overrideHookStateDeletePath: null,
    overrideHookStateRenamePath: null,
    overrideProps: null,
    overridePropsDeletePath: null,
    overridePropsRenamePath: null,
    setErrorHandler: null,
    setSuspenseHandler: null,
    scheduleUpdate: null,
    currentDispatcherRef: Yt.ReactCurrentDispatcher,
    findHostInstanceByFiber: function (e) {
      return (e = Kf(e)), e === null ? null : e.stateNode;
    },
    findFiberByHostInstance: ao.findFiberByHostInstance || Jv,
    findHostInstancesForRefresh: null,
    scheduleRefresh: null,
    scheduleRoot: null,
    setRefreshHandler: null,
    getCurrentFiber: null,
    reconcilerVersion: "18.3.1-next-f1338f8080-20240426",
  };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
  var Ni = __REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (!Ni.isDisabled && Ni.supportsFiber)
    try {
      (Ts = Ni.inject(ty)), (At = Ni);
    } catch {}
}
Ze.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ey;
Ze.createPortal = function (e, t) {
  var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
  if (!Uu(t)) throw Error(R(200));
  return qv(e, t, null, n);
};
Ze.createRoot = function (e, t) {
  if (!Uu(e)) throw Error(R(299));
  var n = !1,
    r = "",
    o = bh;
  return (
    t != null &&
      (t.unstable_strictMode === !0 && (n = !0),
      t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
      t.onRecoverableError !== void 0 && (o = t.onRecoverableError)),
    (t = zu(e, 1, !1, null, null, n, !1, r, o)),
    (e[Wt] = t.current),
    Mo(e.nodeType === 8 ? e.parentNode : e),
    new $u(t)
  );
};
Ze.findDOMNode = function (e) {
  if (e == null) return null;
  if (e.nodeType === 1) return e;
  var t = e._reactInternals;
  if (t === void 0)
    throw typeof e.render == "function"
      ? Error(R(188))
      : ((e = Object.keys(e).join(",")), Error(R(268, e)));
  return (e = Kf(t)), (e = e === null ? null : e.stateNode), e;
};
Ze.flushSync = function (e) {
  return Jn(e);
};
Ze.hydrate = function (e, t, n) {
  if (!Us(t)) throw Error(R(200));
  return Bs(null, e, t, !0, n);
};
Ze.hydrateRoot = function (e, t, n) {
  if (!Uu(e)) throw Error(R(405));
  var r = (n != null && n.hydratedSources) || null,
    o = !1,
    i = "",
    s = bh;
  if (
    (n != null &&
      (n.unstable_strictMode === !0 && (o = !0),
      n.identifierPrefix !== void 0 && (i = n.identifierPrefix),
      n.onRecoverableError !== void 0 && (s = n.onRecoverableError)),
    (t = Ch(t, null, e, 1, n ?? null, o, !1, i, s)),
    (e[Wt] = t.current),
    Mo(e),
    r)
  )
    for (e = 0; e < r.length; e++)
      (n = r[e]),
        (o = n._getVersion),
        (o = o(n._source)),
        t.mutableSourceEagerHydrationData == null
          ? (t.mutableSourceEagerHydrationData = [n, o])
          : t.mutableSourceEagerHydrationData.push(n, o);
  return new $s(t);
};
Ze.render = function (e, t, n) {
  if (!Us(t)) throw Error(R(200));
  return Bs(null, e, t, !1, n);
};
Ze.unmountComponentAtNode = function (e) {
  if (!Us(e)) throw Error(R(40));
  return e._reactRootContainer
    ? (Jn(function () {
        Bs(null, null, e, !1, function () {
          (e._reactRootContainer = null), (e[Wt] = null);
        });
      }),
      !0)
    : !1;
};
Ze.unstable_batchedUpdates = Mu;
Ze.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
  if (!Us(n)) throw Error(R(200));
  if (e == null || e._reactInternals === void 0) throw Error(R(38));
  return Bs(e, t, n, !1, r);
};
Ze.version = "18.3.1-next-f1338f8080-20240426";
function Ph() {
  if (
    !(
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
    )
  )
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Ph);
    } catch (e) {
      console.error(e);
    }
}
Ph(), (Pf.exports = Ze);
var ni = Pf.exports;
const Nh = hf(ni);
var Th,
  kd = ni;
(Th = kd.createRoot), kd.hydrateRoot;
const ny = 1,
  ry = 1e6;
let jl = 0;
function oy() {
  return (jl = (jl + 1) % Number.MAX_SAFE_INTEGER), jl.toString();
}
const _l = new Map(),
  Ed = (e) => {
    if (_l.has(e)) return;
    const t = setTimeout(() => {
      _l.delete(e), bo({ type: "REMOVE_TOAST", toastId: e });
    }, ry);
    _l.set(e, t);
  },
  iy = (e, t) => {
    switch (t.type) {
      case "ADD_TOAST":
        return { ...e, toasts: [t.toast, ...e.toasts].slice(0, ny) };
      case "UPDATE_TOAST":
        return {
          ...e,
          toasts: e.toasts.map((n) =>
            n.id === t.toast.id ? { ...n, ...t.toast } : n
          ),
        };
      case "DISMISS_TOAST": {
        const { toastId: n } = t;
        return (
          n
            ? Ed(n)
            : e.toasts.forEach((r) => {
                Ed(r.id);
              }),
          {
            ...e,
            toasts: e.toasts.map((r) =>
              r.id === n || n === void 0 ? { ...r, open: !1 } : r
            ),
          }
        );
      }
      case "REMOVE_TOAST":
        return t.toastId === void 0
          ? { ...e, toasts: [] }
          : { ...e, toasts: e.toasts.filter((n) => n.id !== t.toastId) };
    }
  },
  Hi = [];
let Qi = { toasts: [] };
function bo(e) {
  (Qi = iy(Qi, e)),
    Hi.forEach((t) => {
      t(Qi);
    });
}
function sy({ ...e }) {
  const t = oy(),
    n = (o) => bo({ type: "UPDATE_TOAST", toast: { ...o, id: t } }),
    r = () => bo({ type: "DISMISS_TOAST", toastId: t });
  return (
    bo({
      type: "ADD_TOAST",
      toast: {
        ...e,
        id: t,
        open: !0,
        onOpenChange: (o) => {
          o || r();
        },
      },
    }),
    { id: t, dismiss: r, update: n }
  );
}
function ly() {
  const [e, t] = y.useState(Qi);
  return (
    y.useEffect(
      () => (
        Hi.push(t),
        () => {
          const n = Hi.indexOf(t);
          n > -1 && Hi.splice(n, 1);
        }
      ),
      [e]
    ),
    {
      ...e,
      toast: sy,
      dismiss: (n) => bo({ type: "DISMISS_TOAST", toastId: n }),
    }
  );
}
function ve(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
  return function (o) {
    if ((e == null || e(o), n === !1 || !o.defaultPrevented))
      return t == null ? void 0 : t(o);
  };
}
function ay(e, t) {
  typeof e == "function" ? e(t) : e != null && (e.current = t);
}
function Rh(...e) {
  return (t) => e.forEach((n) => ay(n, t));
}
function yt(...e) {
  return y.useCallback(Rh(...e), e);
}
function uy(e, t = []) {
  let n = [];
  function r(i, s) {
    const l = y.createContext(s),
      a = n.length;
    n = [...n, s];
    function u(f) {
      const { scope: c, children: v, ...x } = f,
        g = (c == null ? void 0 : c[e][a]) || l,
        S = y.useMemo(() => x, Object.values(x));
      return w.jsx(g.Provider, { value: S, children: v });
    }
    function d(f, c) {
      const v = (c == null ? void 0 : c[e][a]) || l,
        x = y.useContext(v);
      if (x) return x;
      if (s !== void 0) return s;
      throw new Error(`\`${f}\` must be used within \`${i}\``);
    }
    return (u.displayName = i + "Provider"), [u, d];
  }
  const o = () => {
    const i = n.map((s) => y.createContext(s));
    return function (l) {
      const a = (l == null ? void 0 : l[e]) || i;
      return y.useMemo(() => ({ [`__scope${e}`]: { ...l, [e]: a } }), [l, a]);
    };
  };
  return (o.scopeName = e), [r, cy(o, ...t)];
}
function cy(...e) {
  const t = e[0];
  if (e.length === 1) return t;
  const n = () => {
    const r = e.map((o) => ({ useScope: o(), scopeName: o.scopeName }));
    return function (i) {
      const s = r.reduce((l, { useScope: a, scopeName: u }) => {
        const f = a(i)[`__scope${u}`];
        return { ...l, ...f };
      }, {});
      return y.useMemo(() => ({ [`__scope${t.scopeName}`]: s }), [s]);
    };
  };
  return (n.scopeName = t.scopeName), n;
}
var xs = y.forwardRef((e, t) => {
  const { children: n, ...r } = e,
    o = y.Children.toArray(n),
    i = o.find(dy);
  if (i) {
    const s = i.props.children,
      l = o.map((a) =>
        a === i
          ? y.Children.count(s) > 1
            ? y.Children.only(null)
            : y.isValidElement(s)
            ? s.props.children
            : null
          : a
      );
    return w.jsx(_a, {
      ...r,
      ref: t,
      children: y.isValidElement(s) ? y.cloneElement(s, void 0, l) : null,
    });
  }
  return w.jsx(_a, { ...r, ref: t, children: n });
});
xs.displayName = "Slot";
var _a = y.forwardRef((e, t) => {
  const { children: n, ...r } = e;
  if (y.isValidElement(n)) {
    const o = py(n);
    return y.cloneElement(n, { ...fy(r, n.props), ref: t ? Rh(t, o) : o });
  }
  return y.Children.count(n) > 1 ? y.Children.only(null) : null;
});
_a.displayName = "SlotClone";
var Ah = ({ children: e }) => w.jsx(w.Fragment, { children: e });
function dy(e) {
  return y.isValidElement(e) && e.type === Ah;
}
function fy(e, t) {
  const n = { ...t };
  for (const r in t) {
    const o = e[r],
      i = t[r];
    /^on[A-Z]/.test(r)
      ? o && i
        ? (n[r] = (...l) => {
            i(...l), o(...l);
          })
        : o && (n[r] = o)
      : r === "style"
      ? (n[r] = { ...o, ...i })
      : r === "className" && (n[r] = [o, i].filter(Boolean).join(" "));
  }
  return { ...e, ...n };
}
function py(e) {
  var r, o;
  let t =
      (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null
        ? void 0
        : r.get,
    n = t && "isReactWarning" in t && t.isReactWarning;
  return n
    ? e.ref
    : ((t =
        (o = Object.getOwnPropertyDescriptor(e, "ref")) == null
          ? void 0
          : o.get),
      (n = t && "isReactWarning" in t && t.isReactWarning),
      n ? e.props.ref : e.props.ref || e.ref);
}
function hy(e) {
  const t = e + "CollectionProvider",
    [n, r] = uy(t),
    [o, i] = n(t, { collectionRef: { current: null }, itemMap: new Map() }),
    s = (v) => {
      const { scope: x, children: g } = v,
        S = j.useRef(null),
        h = j.useRef(new Map()).current;
      return w.jsx(o, { scope: x, itemMap: h, collectionRef: S, children: g });
    };
  s.displayName = t;
  const l = e + "CollectionSlot",
    a = j.forwardRef((v, x) => {
      const { scope: g, children: S } = v,
        h = i(l, g),
        p = yt(x, h.collectionRef);
      return w.jsx(xs, { ref: p, children: S });
    });
  a.displayName = l;
  const u = e + "CollectionItemSlot",
    d = "data-radix-collection-item",
    f = j.forwardRef((v, x) => {
      const { scope: g, children: S, ...h } = v,
        p = j.useRef(null),
        m = yt(x, p),
        k = i(u, g);
      return (
        j.useEffect(
          () => (
            k.itemMap.set(p, { ref: p, ...h }), () => void k.itemMap.delete(p)
          )
        ),
        w.jsx(xs, { [d]: "", ref: m, children: S })
      );
    });
  f.displayName = u;
  function c(v) {
    const x = i(e + "CollectionConsumer", v);
    return j.useCallback(() => {
      const S = x.collectionRef.current;
      if (!S) return [];
      const h = Array.from(S.querySelectorAll(`[${d}]`));
      return Array.from(x.itemMap.values()).sort(
        (k, E) => h.indexOf(k.ref.current) - h.indexOf(E.ref.current)
      );
    }, [x.collectionRef, x.itemMap]);
  }
  return [{ Provider: s, Slot: a, ItemSlot: f }, c, r];
}
function Bu(e, t = []) {
  let n = [];
  function r(i, s) {
    const l = y.createContext(s),
      a = n.length;
    n = [...n, s];
    const u = (f) => {
      var h;
      const { scope: c, children: v, ...x } = f,
        g = ((h = c == null ? void 0 : c[e]) == null ? void 0 : h[a]) || l,
        S = y.useMemo(() => x, Object.values(x));
      return w.jsx(g.Provider, { value: S, children: v });
    };
    u.displayName = i + "Provider";
    function d(f, c) {
      var g;
      const v = ((g = c == null ? void 0 : c[e]) == null ? void 0 : g[a]) || l,
        x = y.useContext(v);
      if (x) return x;
      if (s !== void 0) return s;
      throw new Error(`\`${f}\` must be used within \`${i}\``);
    }
    return [u, d];
  }
  const o = () => {
    const i = n.map((s) => y.createContext(s));
    return function (l) {
      const a = (l == null ? void 0 : l[e]) || i;
      return y.useMemo(() => ({ [`__scope${e}`]: { ...l, [e]: a } }), [l, a]);
    };
  };
  return (o.scopeName = e), [r, my(o, ...t)];
}
function my(...e) {
  const t = e[0];
  if (e.length === 1) return t;
  const n = () => {
    const r = e.map((o) => ({ useScope: o(), scopeName: o.scopeName }));
    return function (i) {
      const s = r.reduce((l, { useScope: a, scopeName: u }) => {
        const f = a(i)[`__scope${u}`];
        return { ...l, ...f };
      }, {});
      return y.useMemo(() => ({ [`__scope${t.scopeName}`]: s }), [s]);
    };
  };
  return (n.scopeName = t.scopeName), n;
}
var gy = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "span",
    "svg",
    "ul",
  ],
  be = gy.reduce((e, t) => {
    const n = y.forwardRef((r, o) => {
      const { asChild: i, ...s } = r,
        l = i ? xs : t;
      return (
        typeof window < "u" && (window[Symbol.for("radix-ui")] = !0),
        w.jsx(l, { ...s, ref: o })
      );
    });
    return (n.displayName = `Primitive.${t}`), { ...e, [t]: n };
  }, {});
function jh(e, t) {
  e && ni.flushSync(() => e.dispatchEvent(t));
}
function xt(e) {
  const t = y.useRef(e);
  return (
    y.useEffect(() => {
      t.current = e;
    }),
    y.useMemo(
      () =>
        (...n) => {
          var r;
          return (r = t.current) == null ? void 0 : r.call(t, ...n);
        },
      []
    )
  );
}
function vy(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = xt(e);
  y.useEffect(() => {
    const r = (o) => {
      o.key === "Escape" && n(o);
    };
    return (
      t.addEventListener("keydown", r, { capture: !0 }),
      () => t.removeEventListener("keydown", r, { capture: !0 })
    );
  }, [n, t]);
}
var yy = "DismissableLayer",
  Oa = "dismissableLayer.update",
  xy = "dismissableLayer.pointerDownOutside",
  wy = "dismissableLayer.focusOutside",
  Cd,
  _h = y.createContext({
    layers: new Set(),
    layersWithOutsidePointerEventsDisabled: new Set(),
    branches: new Set(),
  }),
  Wu = y.forwardRef((e, t) => {
    const {
        disableOutsidePointerEvents: n = !1,
        onEscapeKeyDown: r,
        onPointerDownOutside: o,
        onFocusOutside: i,
        onInteractOutside: s,
        onDismiss: l,
        ...a
      } = e,
      u = y.useContext(_h),
      [d, f] = y.useState(null),
      c =
        (d == null ? void 0 : d.ownerDocument) ??
        (globalThis == null ? void 0 : globalThis.document),
      [, v] = y.useState({}),
      x = yt(t, (P) => f(P)),
      g = Array.from(u.layers),
      [S] = [...u.layersWithOutsidePointerEventsDisabled].slice(-1),
      h = g.indexOf(S),
      p = d ? g.indexOf(d) : -1,
      m = u.layersWithOutsidePointerEventsDisabled.size > 0,
      k = p >= h,
      E = ky((P) => {
        const T = P.target,
          I = [...u.branches].some((_) => _.contains(T));
        !k ||
          I ||
          (o == null || o(P),
          s == null || s(P),
          P.defaultPrevented || l == null || l());
      }, c),
      b = Ey((P) => {
        const T = P.target;
        [...u.branches].some((_) => _.contains(T)) ||
          (i == null || i(P),
          s == null || s(P),
          P.defaultPrevented || l == null || l());
      }, c);
    return (
      vy((P) => {
        p === u.layers.size - 1 &&
          (r == null || r(P),
          !P.defaultPrevented && l && (P.preventDefault(), l()));
      }, c),
      y.useEffect(() => {
        if (d)
          return (
            n &&
              (u.layersWithOutsidePointerEventsDisabled.size === 0 &&
                ((Cd = c.body.style.pointerEvents),
                (c.body.style.pointerEvents = "none")),
              u.layersWithOutsidePointerEventsDisabled.add(d)),
            u.layers.add(d),
            bd(),
            () => {
              n &&
                u.layersWithOutsidePointerEventsDisabled.size === 1 &&
                (c.body.style.pointerEvents = Cd);
            }
          );
      }, [d, c, n, u]),
      y.useEffect(
        () => () => {
          d &&
            (u.layers.delete(d),
            u.layersWithOutsidePointerEventsDisabled.delete(d),
            bd());
        },
        [d, u]
      ),
      y.useEffect(() => {
        const P = () => v({});
        return (
          document.addEventListener(Oa, P),
          () => document.removeEventListener(Oa, P)
        );
      }, []),
      w.jsx(be.div, {
        ...a,
        ref: x,
        style: {
          pointerEvents: m ? (k ? "auto" : "none") : void 0,
          ...e.style,
        },
        onFocusCapture: ve(e.onFocusCapture, b.onFocusCapture),
        onBlurCapture: ve(e.onBlurCapture, b.onBlurCapture),
        onPointerDownCapture: ve(
          e.onPointerDownCapture,
          E.onPointerDownCapture
        ),
      })
    );
  });
Wu.displayName = yy;
var Sy = "DismissableLayerBranch",
  Oh = y.forwardRef((e, t) => {
    const n = y.useContext(_h),
      r = y.useRef(null),
      o = yt(t, r);
    return (
      y.useEffect(() => {
        const i = r.current;
        if (i)
          return (
            n.branches.add(i),
            () => {
              n.branches.delete(i);
            }
          );
      }, [n.branches]),
      w.jsx(be.div, { ...e, ref: o })
    );
  });
Oh.displayName = Sy;
function ky(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = xt(e),
    r = y.useRef(!1),
    o = y.useRef(() => {});
  return (
    y.useEffect(() => {
      const i = (l) => {
          if (l.target && !r.current) {
            let a = function () {
              Mh(xy, n, u, { discrete: !0 });
            };
            const u = { originalEvent: l };
            l.pointerType === "touch"
              ? (t.removeEventListener("click", o.current),
                (o.current = a),
                t.addEventListener("click", o.current, { once: !0 }))
              : a();
          } else t.removeEventListener("click", o.current);
          r.current = !1;
        },
        s = window.setTimeout(() => {
          t.addEventListener("pointerdown", i);
        }, 0);
      return () => {
        window.clearTimeout(s),
          t.removeEventListener("pointerdown", i),
          t.removeEventListener("click", o.current);
      };
    }, [t, n]),
    { onPointerDownCapture: () => (r.current = !0) }
  );
}
function Ey(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = xt(e),
    r = y.useRef(!1);
  return (
    y.useEffect(() => {
      const o = (i) => {
        i.target &&
          !r.current &&
          Mh(wy, n, { originalEvent: i }, { discrete: !1 });
      };
      return (
        t.addEventListener("focusin", o),
        () => t.removeEventListener("focusin", o)
      );
    }, [t, n]),
    {
      onFocusCapture: () => (r.current = !0),
      onBlurCapture: () => (r.current = !1),
    }
  );
}
function bd() {
  const e = new CustomEvent(Oa);
  document.dispatchEvent(e);
}
function Mh(e, t, n, { discrete: r }) {
  const o = n.originalEvent.target,
    i = new CustomEvent(e, { bubbles: !1, cancelable: !0, detail: n });
  t && o.addEventListener(e, t, { once: !0 }),
    r ? jh(o, i) : o.dispatchEvent(i);
}
var Cy = Wu,
  by = Oh,
  Qt = globalThis != null && globalThis.document ? y.useLayoutEffect : () => {},
  Py = "Portal",
  Lh = y.forwardRef((e, t) => {
    var l;
    const { container: n, ...r } = e,
      [o, i] = y.useState(!1);
    Qt(() => i(!0), []);
    const s =
      n ||
      (o &&
        ((l = globalThis == null ? void 0 : globalThis.document) == null
          ? void 0
          : l.body));
    return s ? Nh.createPortal(w.jsx(be.div, { ...r, ref: t }), s) : null;
  });
Lh.displayName = Py;
function Ny(e, t) {
  return y.useReducer((n, r) => t[n][r] ?? n, e);
}
var Vu = (e) => {
  const { present: t, children: n } = e,
    r = Ty(t),
    o =
      typeof n == "function" ? n({ present: r.isPresent }) : y.Children.only(n),
    i = yt(r.ref, Ry(o));
  return typeof n == "function" || r.isPresent
    ? y.cloneElement(o, { ref: i })
    : null;
};
Vu.displayName = "Presence";
function Ty(e) {
  const [t, n] = y.useState(),
    r = y.useRef({}),
    o = y.useRef(e),
    i = y.useRef("none"),
    s = e ? "mounted" : "unmounted",
    [l, a] = Ny(s, {
      mounted: { UNMOUNT: "unmounted", ANIMATION_OUT: "unmountSuspended" },
      unmountSuspended: { MOUNT: "mounted", ANIMATION_END: "unmounted" },
      unmounted: { MOUNT: "mounted" },
    });
  return (
    y.useEffect(() => {
      const u = Ti(r.current);
      i.current = l === "mounted" ? u : "none";
    }, [l]),
    Qt(() => {
      const u = r.current,
        d = o.current;
      if (d !== e) {
        const c = i.current,
          v = Ti(u);
        e
          ? a("MOUNT")
          : v === "none" || (u == null ? void 0 : u.display) === "none"
          ? a("UNMOUNT")
          : a(d && c !== v ? "ANIMATION_OUT" : "UNMOUNT"),
          (o.current = e);
      }
    }, [e, a]),
    Qt(() => {
      if (t) {
        let u;
        const d = t.ownerDocument.defaultView ?? window,
          f = (v) => {
            const g = Ti(r.current).includes(v.animationName);
            if (v.target === t && g && (a("ANIMATION_END"), !o.current)) {
              const S = t.style.animationFillMode;
              (t.style.animationFillMode = "forwards"),
                (u = d.setTimeout(() => {
                  t.style.animationFillMode === "forwards" &&
                    (t.style.animationFillMode = S);
                }));
            }
          },
          c = (v) => {
            v.target === t && (i.current = Ti(r.current));
          };
        return (
          t.addEventListener("animationstart", c),
          t.addEventListener("animationcancel", f),
          t.addEventListener("animationend", f),
          () => {
            d.clearTimeout(u),
              t.removeEventListener("animationstart", c),
              t.removeEventListener("animationcancel", f),
              t.removeEventListener("animationend", f);
          }
        );
      } else a("ANIMATION_END");
    }, [t, a]),
    {
      isPresent: ["mounted", "unmountSuspended"].includes(l),
      ref: y.useCallback((u) => {
        u && (r.current = getComputedStyle(u)), n(u);
      }, []),
    }
  );
}
function Ti(e) {
  return (e == null ? void 0 : e.animationName) || "none";
}
function Ry(e) {
  var r, o;
  let t =
      (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null
        ? void 0
        : r.get,
    n = t && "isReactWarning" in t && t.isReactWarning;
  return n
    ? e.ref
    : ((t =
        (o = Object.getOwnPropertyDescriptor(e, "ref")) == null
          ? void 0
          : o.get),
      (n = t && "isReactWarning" in t && t.isReactWarning),
      n ? e.props.ref : e.props.ref || e.ref);
}
function Ay({ prop: e, defaultProp: t, onChange: n = () => {} }) {
  const [r, o] = jy({ defaultProp: t, onChange: n }),
    i = e !== void 0,
    s = i ? e : r,
    l = xt(n),
    a = y.useCallback(
      (u) => {
        if (i) {
          const f = typeof u == "function" ? u(e) : u;
          f !== e && l(f);
        } else o(u);
      },
      [i, e, o, l]
    );
  return [s, a];
}
function jy({ defaultProp: e, onChange: t }) {
  const n = y.useState(e),
    [r] = n,
    o = y.useRef(r),
    i = xt(t);
  return (
    y.useEffect(() => {
      o.current !== r && (i(r), (o.current = r));
    }, [r, o, i]),
    n
  );
}
var _y = "VisuallyHidden",
  Ws = y.forwardRef((e, t) =>
    w.jsx(be.span, {
      ...e,
      ref: t,
      style: {
        position: "absolute",
        border: 0,
        width: 1,
        height: 1,
        padding: 0,
        margin: -1,
        overflow: "hidden",
        clip: "rect(0, 0, 0, 0)",
        whiteSpace: "nowrap",
        wordWrap: "normal",
        ...e.style,
      },
    })
  );
Ws.displayName = _y;
var Oy = Ws,
  Hu = "ToastProvider",
  [Qu, My, Ly] = hy("Toast"),
  [Ih, zk] = Bu("Toast", [Ly]),
  [Iy, Vs] = Ih(Hu),
  Dh = (e) => {
    const {
        __scopeToast: t,
        label: n = "Notification",
        duration: r = 5e3,
        swipeDirection: o = "right",
        swipeThreshold: i = 50,
        children: s,
      } = e,
      [l, a] = y.useState(null),
      [u, d] = y.useState(0),
      f = y.useRef(!1),
      c = y.useRef(!1);
    return (
      n.trim() ||
        console.error(
          `Invalid prop \`label\` supplied to \`${Hu}\`. Expected non-empty \`string\`.`
        ),
      w.jsx(Qu.Provider, {
        scope: t,
        children: w.jsx(Iy, {
          scope: t,
          label: n,
          duration: r,
          swipeDirection: o,
          swipeThreshold: i,
          toastCount: u,
          viewport: l,
          onViewportChange: a,
          onToastAdd: y.useCallback(() => d((v) => v + 1), []),
          onToastRemove: y.useCallback(() => d((v) => v - 1), []),
          isFocusedToastEscapeKeyDownRef: f,
          isClosePausedRef: c,
          children: s,
        }),
      })
    );
  };
Dh.displayName = Hu;
var zh = "ToastViewport",
  Dy = ["F8"],
  Ma = "toast.viewportPause",
  La = "toast.viewportResume",
  Fh = y.forwardRef((e, t) => {
    const {
        __scopeToast: n,
        hotkey: r = Dy,
        label: o = "Notifications ({hotkey})",
        ...i
      } = e,
      s = Vs(zh, n),
      l = My(n),
      a = y.useRef(null),
      u = y.useRef(null),
      d = y.useRef(null),
      f = y.useRef(null),
      c = yt(t, f, s.onViewportChange),
      v = r.join("+").replace(/Key/g, "").replace(/Digit/g, ""),
      x = s.toastCount > 0;
    y.useEffect(() => {
      const S = (h) => {
        var m;
        r.length !== 0 &&
          r.every((k) => h[k] || h.code === k) &&
          ((m = f.current) == null || m.focus());
      };
      return (
        document.addEventListener("keydown", S),
        () => document.removeEventListener("keydown", S)
      );
    }, [r]),
      y.useEffect(() => {
        const S = a.current,
          h = f.current;
        if (x && S && h) {
          const p = () => {
              if (!s.isClosePausedRef.current) {
                const b = new CustomEvent(Ma);
                h.dispatchEvent(b), (s.isClosePausedRef.current = !0);
              }
            },
            m = () => {
              if (s.isClosePausedRef.current) {
                const b = new CustomEvent(La);
                h.dispatchEvent(b), (s.isClosePausedRef.current = !1);
              }
            },
            k = (b) => {
              !S.contains(b.relatedTarget) && m();
            },
            E = () => {
              S.contains(document.activeElement) || m();
            };
          return (
            S.addEventListener("focusin", p),
            S.addEventListener("focusout", k),
            S.addEventListener("pointermove", p),
            S.addEventListener("pointerleave", E),
            window.addEventListener("blur", p),
            window.addEventListener("focus", m),
            () => {
              S.removeEventListener("focusin", p),
                S.removeEventListener("focusout", k),
                S.removeEventListener("pointermove", p),
                S.removeEventListener("pointerleave", E),
                window.removeEventListener("blur", p),
                window.removeEventListener("focus", m);
            }
          );
        }
      }, [x, s.isClosePausedRef]);
    const g = y.useCallback(
      ({ tabbingDirection: S }) => {
        const p = l().map((m) => {
          const k = m.ref.current,
            E = [k, ...Xy(k)];
          return S === "forwards" ? E : E.reverse();
        });
        return (S === "forwards" ? p.reverse() : p).flat();
      },
      [l]
    );
    return (
      y.useEffect(() => {
        const S = f.current;
        if (S) {
          const h = (p) => {
            var E, b, P;
            const m = p.altKey || p.ctrlKey || p.metaKey;
            if (p.key === "Tab" && !m) {
              const T = document.activeElement,
                I = p.shiftKey;
              if (p.target === S && I) {
                (E = u.current) == null || E.focus();
                return;
              }
              const D = g({ tabbingDirection: I ? "backwards" : "forwards" }),
                H = D.findIndex((O) => O === T);
              Ol(D.slice(H + 1))
                ? p.preventDefault()
                : I
                ? (b = u.current) == null || b.focus()
                : (P = d.current) == null || P.focus();
            }
          };
          return (
            S.addEventListener("keydown", h),
            () => S.removeEventListener("keydown", h)
          );
        }
      }, [l, g]),
      w.jsxs(by, {
        ref: a,
        role: "region",
        "aria-label": o.replace("{hotkey}", v),
        tabIndex: -1,
        style: { pointerEvents: x ? void 0 : "none" },
        children: [
          x &&
            w.jsx(Ia, {
              ref: u,
              onFocusFromOutsideViewport: () => {
                const S = g({ tabbingDirection: "forwards" });
                Ol(S);
              },
            }),
          w.jsx(Qu.Slot, {
            scope: n,
            children: w.jsx(be.ol, { tabIndex: -1, ...i, ref: c }),
          }),
          x &&
            w.jsx(Ia, {
              ref: d,
              onFocusFromOutsideViewport: () => {
                const S = g({ tabbingDirection: "backwards" });
                Ol(S);
              },
            }),
        ],
      })
    );
  });
Fh.displayName = zh;
var $h = "ToastFocusProxy",
  Ia = y.forwardRef((e, t) => {
    const { __scopeToast: n, onFocusFromOutsideViewport: r, ...o } = e,
      i = Vs($h, n);
    return w.jsx(Ws, {
      "aria-hidden": !0,
      tabIndex: 0,
      ...o,
      ref: t,
      style: { position: "fixed" },
      onFocus: (s) => {
        var u;
        const l = s.relatedTarget;
        !((u = i.viewport) != null && u.contains(l)) && r();
      },
    });
  });
Ia.displayName = $h;
var Hs = "Toast",
  zy = "toast.swipeStart",
  Fy = "toast.swipeMove",
  $y = "toast.swipeCancel",
  Uy = "toast.swipeEnd",
  Uh = y.forwardRef((e, t) => {
    const { forceMount: n, open: r, defaultOpen: o, onOpenChange: i, ...s } = e,
      [l = !0, a] = Ay({ prop: r, defaultProp: o, onChange: i });
    return w.jsx(Vu, {
      present: n || l,
      children: w.jsx(Vy, {
        open: l,
        ...s,
        ref: t,
        onClose: () => a(!1),
        onPause: xt(e.onPause),
        onResume: xt(e.onResume),
        onSwipeStart: ve(e.onSwipeStart, (u) => {
          u.currentTarget.setAttribute("data-swipe", "start");
        }),
        onSwipeMove: ve(e.onSwipeMove, (u) => {
          const { x: d, y: f } = u.detail.delta;
          u.currentTarget.setAttribute("data-swipe", "move"),
            u.currentTarget.style.setProperty(
              "--radix-toast-swipe-move-x",
              `${d}px`
            ),
            u.currentTarget.style.setProperty(
              "--radix-toast-swipe-move-y",
              `${f}px`
            );
        }),
        onSwipeCancel: ve(e.onSwipeCancel, (u) => {
          u.currentTarget.setAttribute("data-swipe", "cancel"),
            u.currentTarget.style.removeProperty("--radix-toast-swipe-move-x"),
            u.currentTarget.style.removeProperty("--radix-toast-swipe-move-y"),
            u.currentTarget.style.removeProperty("--radix-toast-swipe-end-x"),
            u.currentTarget.style.removeProperty("--radix-toast-swipe-end-y");
        }),
        onSwipeEnd: ve(e.onSwipeEnd, (u) => {
          const { x: d, y: f } = u.detail.delta;
          u.currentTarget.setAttribute("data-swipe", "end"),
            u.currentTarget.style.removeProperty("--radix-toast-swipe-move-x"),
            u.currentTarget.style.removeProperty("--radix-toast-swipe-move-y"),
            u.currentTarget.style.setProperty(
              "--radix-toast-swipe-end-x",
              `${d}px`
            ),
            u.currentTarget.style.setProperty(
              "--radix-toast-swipe-end-y",
              `${f}px`
            ),
            a(!1);
        }),
      }),
    });
  });
Uh.displayName = Hs;
var [By, Wy] = Ih(Hs, { onClose() {} }),
  Vy = y.forwardRef((e, t) => {
    const {
        __scopeToast: n,
        type: r = "foreground",
        duration: o,
        open: i,
        onClose: s,
        onEscapeKeyDown: l,
        onPause: a,
        onResume: u,
        onSwipeStart: d,
        onSwipeMove: f,
        onSwipeCancel: c,
        onSwipeEnd: v,
        ...x
      } = e,
      g = Vs(Hs, n),
      [S, h] = y.useState(null),
      p = yt(t, (O) => h(O)),
      m = y.useRef(null),
      k = y.useRef(null),
      E = o || g.duration,
      b = y.useRef(0),
      P = y.useRef(E),
      T = y.useRef(0),
      { onToastAdd: I, onToastRemove: _ } = g,
      $ = xt(() => {
        var Q;
        (S == null ? void 0 : S.contains(document.activeElement)) &&
          ((Q = g.viewport) == null || Q.focus()),
          s();
      }),
      D = y.useCallback(
        (O) => {
          !O ||
            O === 1 / 0 ||
            (window.clearTimeout(T.current),
            (b.current = new Date().getTime()),
            (T.current = window.setTimeout($, O)));
        },
        [$]
      );
    y.useEffect(() => {
      const O = g.viewport;
      if (O) {
        const Q = () => {
            D(P.current), u == null || u();
          },
          U = () => {
            const K = new Date().getTime() - b.current;
            (P.current = P.current - K),
              window.clearTimeout(T.current),
              a == null || a();
          };
        return (
          O.addEventListener(Ma, U),
          O.addEventListener(La, Q),
          () => {
            O.removeEventListener(Ma, U), O.removeEventListener(La, Q);
          }
        );
      }
    }, [g.viewport, E, a, u, D]),
      y.useEffect(() => {
        i && !g.isClosePausedRef.current && D(E);
      }, [i, E, g.isClosePausedRef, D]),
      y.useEffect(() => (I(), () => _()), [I, _]);
    const H = y.useMemo(() => (S ? Gh(S) : null), [S]);
    return g.viewport
      ? w.jsxs(w.Fragment, {
          children: [
            H &&
              w.jsx(Hy, {
                __scopeToast: n,
                role: "status",
                "aria-live": r === "foreground" ? "assertive" : "polite",
                "aria-atomic": !0,
                children: H,
              }),
            w.jsx(By, {
              scope: n,
              onClose: $,
              children: ni.createPortal(
                w.jsx(Qu.ItemSlot, {
                  scope: n,
                  children: w.jsx(Cy, {
                    asChild: !0,
                    onEscapeKeyDown: ve(l, () => {
                      g.isFocusedToastEscapeKeyDownRef.current || $(),
                        (g.isFocusedToastEscapeKeyDownRef.current = !1);
                    }),
                    children: w.jsx(be.li, {
                      role: "status",
                      "aria-live": "off",
                      "aria-atomic": !0,
                      tabIndex: 0,
                      "data-state": i ? "open" : "closed",
                      "data-swipe-direction": g.swipeDirection,
                      ...x,
                      ref: p,
                      style: {
                        userSelect: "none",
                        touchAction: "none",
                        ...e.style,
                      },
                      onKeyDown: ve(e.onKeyDown, (O) => {
                        O.key === "Escape" &&
                          (l == null || l(O.nativeEvent),
                          O.nativeEvent.defaultPrevented ||
                            ((g.isFocusedToastEscapeKeyDownRef.current = !0),
                            $()));
                      }),
                      onPointerDown: ve(e.onPointerDown, (O) => {
                        O.button === 0 &&
                          (m.current = { x: O.clientX, y: O.clientY });
                      }),
                      onPointerMove: ve(e.onPointerMove, (O) => {
                        if (!m.current) return;
                        const Q = O.clientX - m.current.x,
                          U = O.clientY - m.current.y,
                          K = !!k.current,
                          C = ["left", "right"].includes(g.swipeDirection),
                          A = ["left", "up"].includes(g.swipeDirection)
                            ? Math.min
                            : Math.max,
                          z = C ? A(0, Q) : 0,
                          L = C ? 0 : A(0, U),
                          F = O.pointerType === "touch" ? 10 : 2,
                          Y = { x: z, y: L },
                          le = { originalEvent: O, delta: Y };
                        K
                          ? ((k.current = Y), Ri(Fy, f, le, { discrete: !1 }))
                          : Pd(Y, g.swipeDirection, F)
                          ? ((k.current = Y),
                            Ri(zy, d, le, { discrete: !1 }),
                            O.target.setPointerCapture(O.pointerId))
                          : (Math.abs(Q) > F || Math.abs(U) > F) &&
                            (m.current = null);
                      }),
                      onPointerUp: ve(e.onPointerUp, (O) => {
                        const Q = k.current,
                          U = O.target;
                        if (
                          (U.hasPointerCapture(O.pointerId) &&
                            U.releasePointerCapture(O.pointerId),
                          (k.current = null),
                          (m.current = null),
                          Q)
                        ) {
                          const K = O.currentTarget,
                            C = { originalEvent: O, delta: Q };
                          Pd(Q, g.swipeDirection, g.swipeThreshold)
                            ? Ri(Uy, v, C, { discrete: !0 })
                            : Ri($y, c, C, { discrete: !0 }),
                            K.addEventListener(
                              "click",
                              (A) => A.preventDefault(),
                              { once: !0 }
                            );
                        }
                      }),
                    }),
                  }),
                }),
                g.viewport
              ),
            }),
          ],
        })
      : null;
  }),
  Hy = (e) => {
    const { __scopeToast: t, children: n, ...r } = e,
      o = Vs(Hs, t),
      [i, s] = y.useState(!1),
      [l, a] = y.useState(!1);
    return (
      Gy(() => s(!0)),
      y.useEffect(() => {
        const u = window.setTimeout(() => a(!0), 1e3);
        return () => window.clearTimeout(u);
      }, []),
      l
        ? null
        : w.jsx(Lh, {
            asChild: !0,
            children: w.jsx(Ws, {
              ...r,
              children:
                i && w.jsxs(w.Fragment, { children: [o.label, " ", n] }),
            }),
          })
    );
  },
  Qy = "ToastTitle",
  Bh = y.forwardRef((e, t) => {
    const { __scopeToast: n, ...r } = e;
    return w.jsx(be.div, { ...r, ref: t });
  });
Bh.displayName = Qy;
var Ky = "ToastDescription",
  Wh = y.forwardRef((e, t) => {
    const { __scopeToast: n, ...r } = e;
    return w.jsx(be.div, { ...r, ref: t });
  });
Wh.displayName = Ky;
var Vh = "ToastAction",
  Hh = y.forwardRef((e, t) => {
    const { altText: n, ...r } = e;
    return n.trim()
      ? w.jsx(Kh, {
          altText: n,
          asChild: !0,
          children: w.jsx(Ku, { ...r, ref: t }),
        })
      : (console.error(
          `Invalid prop \`altText\` supplied to \`${Vh}\`. Expected non-empty \`string\`.`
        ),
        null);
  });
Hh.displayName = Vh;
var Qh = "ToastClose",
  Ku = y.forwardRef((e, t) => {
    const { __scopeToast: n, ...r } = e,
      o = Wy(Qh, n);
    return w.jsx(Kh, {
      asChild: !0,
      children: w.jsx(be.button, {
        type: "button",
        ...r,
        ref: t,
        onClick: ve(e.onClick, o.onClose),
      }),
    });
  });
Ku.displayName = Qh;
var Kh = y.forwardRef((e, t) => {
  const { __scopeToast: n, altText: r, ...o } = e;
  return w.jsx(be.div, {
    "data-radix-toast-announce-exclude": "",
    "data-radix-toast-announce-alt": r || void 0,
    ...o,
    ref: t,
  });
});
function Gh(e) {
  const t = [];
  return (
    Array.from(e.childNodes).forEach((r) => {
      if (
        (r.nodeType === r.TEXT_NODE && r.textContent && t.push(r.textContent),
        Yy(r))
      ) {
        const o = r.ariaHidden || r.hidden || r.style.display === "none",
          i = r.dataset.radixToastAnnounceExclude === "";
        if (!o)
          if (i) {
            const s = r.dataset.radixToastAnnounceAlt;
            s && t.push(s);
          } else t.push(...Gh(r));
      }
    }),
    t
  );
}
function Ri(e, t, n, { discrete: r }) {
  const o = n.originalEvent.currentTarget,
    i = new CustomEvent(e, { bubbles: !0, cancelable: !0, detail: n });
  t && o.addEventListener(e, t, { once: !0 }),
    r ? jh(o, i) : o.dispatchEvent(i);
}
var Pd = (e, t, n = 0) => {
  const r = Math.abs(e.x),
    o = Math.abs(e.y),
    i = r > o;
  return t === "left" || t === "right" ? i && r > n : !i && o > n;
};
function Gy(e = () => {}) {
  const t = xt(e);
  Qt(() => {
    let n = 0,
      r = 0;
    return (
      (n = window.requestAnimationFrame(
        () => (r = window.requestAnimationFrame(t))
      )),
      () => {
        window.cancelAnimationFrame(n), window.cancelAnimationFrame(r);
      }
    );
  }, [t]);
}
function Yy(e) {
  return e.nodeType === e.ELEMENT_NODE;
}
function Xy(e) {
  const t = [],
    n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (r) => {
        const o = r.tagName === "INPUT" && r.type === "hidden";
        return r.disabled || r.hidden || o
          ? NodeFilter.FILTER_SKIP
          : r.tabIndex >= 0
          ? NodeFilter.FILTER_ACCEPT
          : NodeFilter.FILTER_SKIP;
      },
    });
  for (; n.nextNode(); ) t.push(n.currentNode);
  return t;
}
function Ol(e) {
  const t = document.activeElement;
  return e.some((n) =>
    n === t ? !0 : (n.focus(), document.activeElement !== t)
  );
}
var qy = Dh,
  Yh = Fh,
  Xh = Uh,
  qh = Bh,
  Jh = Wh,
  Zh = Hh,
  em = Ku;
function tm(e) {
  var t,
    n,
    r = "";
  if (typeof e == "string" || typeof e == "number") r += e;
  else if (typeof e == "object")
    if (Array.isArray(e)) {
      var o = e.length;
      for (t = 0; t < o; t++)
        e[t] && (n = tm(e[t])) && (r && (r += " "), (r += n));
    } else for (n in e) e[n] && (r && (r += " "), (r += n));
  return r;
}
function nm() {
  for (var e, t, n = 0, r = "", o = arguments.length; n < o; n++)
    (e = arguments[n]) && (t = tm(e)) && (r && (r += " "), (r += t));
  return r;
}
const Nd = (e) => (typeof e == "boolean" ? `${e}` : e === 0 ? "0" : e),
  Td = nm,
  Jy = (e, t) => (n) => {
    var r;
    if ((t == null ? void 0 : t.variants) == null)
      return Td(
        e,
        n == null ? void 0 : n.class,
        n == null ? void 0 : n.className
      );
    const { variants: o, defaultVariants: i } = t,
      s = Object.keys(o).map((u) => {
        const d = n == null ? void 0 : n[u],
          f = i == null ? void 0 : i[u];
        if (d === null) return null;
        const c = Nd(d) || Nd(f);
        return o[u][c];
      }),
      l =
        n &&
        Object.entries(n).reduce((u, d) => {
          let [f, c] = d;
          return c === void 0 || (u[f] = c), u;
        }, {}),
      a =
        t == null || (r = t.compoundVariants) === null || r === void 0
          ? void 0
          : r.reduce((u, d) => {
              let { class: f, className: c, ...v } = d;
              return Object.entries(v).every((x) => {
                let [g, S] = x;
                return Array.isArray(S)
                  ? S.includes({ ...i, ...l }[g])
                  : { ...i, ...l }[g] === S;
              })
                ? [...u, f, c]
                : u;
            }, []);
    return Td(
      e,
      s,
      a,
      n == null ? void 0 : n.class,
      n == null ? void 0 : n.className
    );
  };
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Zy = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(),
  rm = (...e) =>
    e
      .filter((t, n, r) => !!t && t.trim() !== "" && r.indexOf(t) === n)
      .join(" ")
      .trim();
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var ex = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const tx = y.forwardRef(
  (
    {
      color: e = "currentColor",
      size: t = 24,
      strokeWidth: n = 2,
      absoluteStrokeWidth: r,
      className: o = "",
      children: i,
      iconNode: s,
      ...l
    },
    a
  ) =>
    y.createElement(
      "svg",
      {
        ref: a,
        ...ex,
        width: t,
        height: t,
        stroke: e,
        strokeWidth: r ? (Number(n) * 24) / Number(t) : n,
        className: rm("lucide", o),
        ...l,
      },
      [
        ...s.map(([u, d]) => y.createElement(u, d)),
        ...(Array.isArray(i) ? i : [i]),
      ]
    )
);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Pe = (e, t) => {
  const n = y.forwardRef(({ className: r, ...o }, i) =>
    y.createElement(tx, {
      ref: i,
      iconNode: t,
      className: rm(`lucide-${Zy(e)}`, r),
      ...o,
    })
  );
  return (n.displayName = `${e}`), n;
};
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const nx = Pe("ArrowLeft", [
  ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
  ["path", { d: "M19 12H5", key: "x3x0zl" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Rd = Pe("ChartColumn", [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "M18 17V9", key: "2bz60n" }],
  ["path", { d: "M13 17V5", key: "1frdt8" }],
  ["path", { d: "M8 17v-3", key: "17ska0" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const rx = Pe("ChartPie", [
  [
    "path",
    {
      d: "M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z",
      key: "pzmjnu",
    },
  ],
  ["path", { d: "M21.21 15.89A10 10 0 1 1 8 2.83", key: "k2fpak" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ad = Pe("Code", [
  ["polyline", { points: "16 18 22 12 16 6", key: "z7tu5w" }],
  ["polyline", { points: "8 6 2 12 8 18", key: "1eg1df" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ml = Pe("Database", [
  ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }],
  ["path", { d: "M3 5V19A9 3 0 0 0 21 19V5", key: "1wlel7" }],
  ["path", { d: "M3 12A9 3 0 0 0 21 12", key: "mv7ke4" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ox = Pe("Download", [
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
  ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ix = Pe("FileCode", [
  ["path", { d: "M10 12.5 8 15l2 2.5", key: "1tg20x" }],
  ["path", { d: "m14 12.5 2 2.5-2 2.5", key: "yinavb" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  [
    "path",
    {
      d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z",
      key: "1mlx9k",
    },
  ],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const sx = Pe("GitBranch", [
  ["line", { x1: "6", x2: "6", y1: "3", y2: "15", key: "17qcm7" }],
  ["circle", { cx: "18", cy: "6", r: "3", key: "1h7g24" }],
  ["circle", { cx: "6", cy: "18", r: "3", key: "fqmcym" }],
  ["path", { d: "M18 9a9 9 0 0 1-9 9", key: "n2h4wq" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const om = Pe("Github", [
  [
    "path",
    {
      d: "M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4",
      key: "tonef",
    },
  ],
  ["path", { d: "M9 18c-4.51 2-5-2-7-2", key: "9comsn" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const lx = Pe("Globe", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  [
    "path",
    { d: "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20", key: "13o1zl" },
  ],
  ["path", { d: "M2 12h20", key: "9i4pu4" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const im = Pe("Linkedin", [
  [
    "path",
    {
      d: "M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z",
      key: "c2jq9f",
    },
  ],
  ["rect", { width: "4", height: "12", x: "2", y: "9", key: "mk3on5" }],
  ["circle", { cx: "4", cy: "4", r: "2", key: "bt5ra8" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const sm = Pe("Mail", [
  [
    "rect",
    { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" },
  ],
  ["path", { d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7", key: "1ocrg3" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ax = Pe("MapPin", [
  [
    "path",
    {
      d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
      key: "1r0f0z",
    },
  ],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ux = Pe("Moon", [
  ["path", { d: "M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z", key: "a7tn18" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const cx = Pe("Sun", [
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "m4.93 4.93 1.41 1.41", key: "149t6j" }],
  ["path", { d: "m17.66 17.66 1.41 1.41", key: "ptbguv" }],
  ["path", { d: "M2 12h2", key: "1t8f8n" }],
  ["path", { d: "M20 12h2", key: "1q8mjw" }],
  ["path", { d: "m6.34 17.66-1.41 1.41", key: "1m8zz5" }],
  ["path", { d: "m19.07 4.93-1.41 1.41", key: "1shlcs" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const dx = Pe("X", [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }],
]);
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const fx = Pe("Zap", [
    [
      "path",
      {
        d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
        key: "1xq2db",
      },
    ],
  ]),
  Gu = "-",
  px = (e) => {
    const t = mx(e),
      { conflictingClassGroups: n, conflictingClassGroupModifiers: r } = e;
    return {
      getClassGroupId: (s) => {
        const l = s.split(Gu);
        return l[0] === "" && l.length !== 1 && l.shift(), lm(l, t) || hx(s);
      },
      getConflictingClassGroupIds: (s, l) => {
        const a = n[s] || [];
        return l && r[s] ? [...a, ...r[s]] : a;
      },
    };
  },
  lm = (e, t) => {
    var s;
    if (e.length === 0) return t.classGroupId;
    const n = e[0],
      r = t.nextPart.get(n),
      o = r ? lm(e.slice(1), r) : void 0;
    if (o) return o;
    if (t.validators.length === 0) return;
    const i = e.join(Gu);
    return (s = t.validators.find(({ validator: l }) => l(i))) == null
      ? void 0
      : s.classGroupId;
  },
  jd = /^\[(.+)\]$/,
  hx = (e) => {
    if (jd.test(e)) {
      const t = jd.exec(e)[1],
        n = t == null ? void 0 : t.substring(0, t.indexOf(":"));
      if (n) return "arbitrary.." + n;
    }
  },
  mx = (e) => {
    const { theme: t, prefix: n } = e,
      r = { nextPart: new Map(), validators: [] };
    return (
      vx(Object.entries(e.classGroups), n).forEach(([i, s]) => {
        Da(s, r, i, t);
      }),
      r
    );
  },
  Da = (e, t, n, r) => {
    e.forEach((o) => {
      if (typeof o == "string") {
        const i = o === "" ? t : _d(t, o);
        i.classGroupId = n;
        return;
      }
      if (typeof o == "function") {
        if (gx(o)) {
          Da(o(r), t, n, r);
          return;
        }
        t.validators.push({ validator: o, classGroupId: n });
        return;
      }
      Object.entries(o).forEach(([i, s]) => {
        Da(s, _d(t, i), n, r);
      });
    });
  },
  _d = (e, t) => {
    let n = e;
    return (
      t.split(Gu).forEach((r) => {
        n.nextPart.has(r) ||
          n.nextPart.set(r, { nextPart: new Map(), validators: [] }),
          (n = n.nextPart.get(r));
      }),
      n
    );
  },
  gx = (e) => e.isThemeGetter,
  vx = (e, t) =>
    t
      ? e.map(([n, r]) => {
          const o = r.map((i) =>
            typeof i == "string"
              ? t + i
              : typeof i == "object"
              ? Object.fromEntries(
                  Object.entries(i).map(([s, l]) => [t + s, l])
                )
              : i
          );
          return [n, o];
        })
      : e,
  yx = (e) => {
    if (e < 1) return { get: () => {}, set: () => {} };
    let t = 0,
      n = new Map(),
      r = new Map();
    const o = (i, s) => {
      n.set(i, s), t++, t > e && ((t = 0), (r = n), (n = new Map()));
    };
    return {
      get(i) {
        let s = n.get(i);
        if (s !== void 0) return s;
        if ((s = r.get(i)) !== void 0) return o(i, s), s;
      },
      set(i, s) {
        n.has(i) ? n.set(i, s) : o(i, s);
      },
    };
  },
  am = "!",
  xx = (e) => {
    const { separator: t, experimentalParseClassName: n } = e,
      r = t.length === 1,
      o = t[0],
      i = t.length,
      s = (l) => {
        const a = [];
        let u = 0,
          d = 0,
          f;
        for (let S = 0; S < l.length; S++) {
          let h = l[S];
          if (u === 0) {
            if (h === o && (r || l.slice(S, S + i) === t)) {
              a.push(l.slice(d, S)), (d = S + i);
              continue;
            }
            if (h === "/") {
              f = S;
              continue;
            }
          }
          h === "[" ? u++ : h === "]" && u--;
        }
        const c = a.length === 0 ? l : l.substring(d),
          v = c.startsWith(am),
          x = v ? c.substring(1) : c,
          g = f && f > d ? f - d : void 0;
        return {
          modifiers: a,
          hasImportantModifier: v,
          baseClassName: x,
          maybePostfixModifierPosition: g,
        };
      };
    return n ? (l) => n({ className: l, parseClassName: s }) : s;
  },
  wx = (e) => {
    if (e.length <= 1) return e;
    const t = [];
    let n = [];
    return (
      e.forEach((r) => {
        r[0] === "[" ? (t.push(...n.sort(), r), (n = [])) : n.push(r);
      }),
      t.push(...n.sort()),
      t
    );
  },
  Sx = (e) => ({ cache: yx(e.cacheSize), parseClassName: xx(e), ...px(e) }),
  kx = /\s+/,
  Ex = (e, t) => {
    const {
        parseClassName: n,
        getClassGroupId: r,
        getConflictingClassGroupIds: o,
      } = t,
      i = [],
      s = e.trim().split(kx);
    let l = "";
    for (let a = s.length - 1; a >= 0; a -= 1) {
      const u = s[a],
        {
          modifiers: d,
          hasImportantModifier: f,
          baseClassName: c,
          maybePostfixModifierPosition: v,
        } = n(u);
      let x = !!v,
        g = r(x ? c.substring(0, v) : c);
      if (!g) {
        if (!x) {
          l = u + (l.length > 0 ? " " + l : l);
          continue;
        }
        if (((g = r(c)), !g)) {
          l = u + (l.length > 0 ? " " + l : l);
          continue;
        }
        x = !1;
      }
      const S = wx(d).join(":"),
        h = f ? S + am : S,
        p = h + g;
      if (i.includes(p)) continue;
      i.push(p);
      const m = o(g, x);
      for (let k = 0; k < m.length; ++k) {
        const E = m[k];
        i.push(h + E);
      }
      l = u + (l.length > 0 ? " " + l : l);
    }
    return l;
  };
function Cx() {
  let e = 0,
    t,
    n,
    r = "";
  for (; e < arguments.length; )
    (t = arguments[e++]) && (n = um(t)) && (r && (r += " "), (r += n));
  return r;
}
const um = (e) => {
  if (typeof e == "string") return e;
  let t,
    n = "";
  for (let r = 0; r < e.length; r++)
    e[r] && (t = um(e[r])) && (n && (n += " "), (n += t));
  return n;
};
function bx(e, ...t) {
  let n,
    r,
    o,
    i = s;
  function s(a) {
    const u = t.reduce((d, f) => f(d), e());
    return (n = Sx(u)), (r = n.cache.get), (o = n.cache.set), (i = l), l(a);
  }
  function l(a) {
    const u = r(a);
    if (u) return u;
    const d = Ex(a, n);
    return o(a, d), d;
  }
  return function () {
    return i(Cx.apply(null, arguments));
  };
}
const re = (e) => {
    const t = (n) => n[e] || [];
    return (t.isThemeGetter = !0), t;
  },
  cm = /^\[(?:([a-z-]+):)?(.+)\]$/i,
  Px = /^\d+\/\d+$/,
  Nx = new Set(["px", "full", "screen"]),
  Tx = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
  Rx =
    /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
  Ax = /^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/,
  jx = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
  _x =
    /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
  Lt = (e) => Nr(e) || Nx.has(e) || Px.test(e),
  nn = (e) => Xr(e, "length", $x),
  Nr = (e) => !!e && !Number.isNaN(Number(e)),
  Ll = (e) => Xr(e, "number", Nr),
  uo = (e) => !!e && Number.isInteger(Number(e)),
  Ox = (e) => e.endsWith("%") && Nr(e.slice(0, -1)),
  W = (e) => cm.test(e),
  rn = (e) => Tx.test(e),
  Mx = new Set(["length", "size", "percentage"]),
  Lx = (e) => Xr(e, Mx, dm),
  Ix = (e) => Xr(e, "position", dm),
  Dx = new Set(["image", "url"]),
  zx = (e) => Xr(e, Dx, Bx),
  Fx = (e) => Xr(e, "", Ux),
  co = () => !0,
  Xr = (e, t, n) => {
    const r = cm.exec(e);
    return r
      ? r[1]
        ? typeof t == "string"
          ? r[1] === t
          : t.has(r[1])
        : n(r[2])
      : !1;
  },
  $x = (e) => Rx.test(e) && !Ax.test(e),
  dm = () => !1,
  Ux = (e) => jx.test(e),
  Bx = (e) => _x.test(e),
  Wx = () => {
    const e = re("colors"),
      t = re("spacing"),
      n = re("blur"),
      r = re("brightness"),
      o = re("borderColor"),
      i = re("borderRadius"),
      s = re("borderSpacing"),
      l = re("borderWidth"),
      a = re("contrast"),
      u = re("grayscale"),
      d = re("hueRotate"),
      f = re("invert"),
      c = re("gap"),
      v = re("gradientColorStops"),
      x = re("gradientColorStopPositions"),
      g = re("inset"),
      S = re("margin"),
      h = re("opacity"),
      p = re("padding"),
      m = re("saturate"),
      k = re("scale"),
      E = re("sepia"),
      b = re("skew"),
      P = re("space"),
      T = re("translate"),
      I = () => ["auto", "contain", "none"],
      _ = () => ["auto", "hidden", "clip", "visible", "scroll"],
      $ = () => ["auto", W, t],
      D = () => [W, t],
      H = () => ["", Lt, nn],
      O = () => ["auto", Nr, W],
      Q = () => [
        "bottom",
        "center",
        "left",
        "left-bottom",
        "left-top",
        "right",
        "right-bottom",
        "right-top",
        "top",
      ],
      U = () => ["solid", "dashed", "dotted", "double", "none"],
      K = () => [
        "normal",
        "multiply",
        "screen",
        "overlay",
        "darken",
        "lighten",
        "color-dodge",
        "color-burn",
        "hard-light",
        "soft-light",
        "difference",
        "exclusion",
        "hue",
        "saturation",
        "color",
        "luminosity",
      ],
      C = () => [
        "start",
        "end",
        "center",
        "between",
        "around",
        "evenly",
        "stretch",
      ],
      A = () => ["", "0", W],
      z = () => [
        "auto",
        "avoid",
        "all",
        "avoid-page",
        "page",
        "left",
        "right",
        "column",
      ],
      L = () => [Nr, W];
    return {
      cacheSize: 500,
      separator: ":",
      theme: {
        colors: [co],
        spacing: [Lt, nn],
        blur: ["none", "", rn, W],
        brightness: L(),
        borderColor: [e],
        borderRadius: ["none", "", "full", rn, W],
        borderSpacing: D(),
        borderWidth: H(),
        contrast: L(),
        grayscale: A(),
        hueRotate: L(),
        invert: A(),
        gap: D(),
        gradientColorStops: [e],
        gradientColorStopPositions: [Ox, nn],
        inset: $(),
        margin: $(),
        opacity: L(),
        padding: D(),
        saturate: L(),
        scale: L(),
        sepia: A(),
        skew: L(),
        space: D(),
        translate: D(),
      },
      classGroups: {
        aspect: [{ aspect: ["auto", "square", "video", W] }],
        container: ["container"],
        columns: [{ columns: [rn] }],
        "break-after": [{ "break-after": z() }],
        "break-before": [{ "break-before": z() }],
        "break-inside": [
          { "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"] },
        ],
        "box-decoration": [{ "box-decoration": ["slice", "clone"] }],
        box: [{ box: ["border", "content"] }],
        display: [
          "block",
          "inline-block",
          "inline",
          "flex",
          "inline-flex",
          "table",
          "inline-table",
          "table-caption",
          "table-cell",
          "table-column",
          "table-column-group",
          "table-footer-group",
          "table-header-group",
          "table-row-group",
          "table-row",
          "flow-root",
          "grid",
          "inline-grid",
          "contents",
          "list-item",
          "hidden",
        ],
        float: [{ float: ["right", "left", "none", "start", "end"] }],
        clear: [{ clear: ["left", "right", "both", "none", "start", "end"] }],
        isolation: ["isolate", "isolation-auto"],
        "object-fit": [
          { object: ["contain", "cover", "fill", "none", "scale-down"] },
        ],
        "object-position": [{ object: [...Q(), W] }],
        overflow: [{ overflow: _() }],
        "overflow-x": [{ "overflow-x": _() }],
        "overflow-y": [{ "overflow-y": _() }],
        overscroll: [{ overscroll: I() }],
        "overscroll-x": [{ "overscroll-x": I() }],
        "overscroll-y": [{ "overscroll-y": I() }],
        position: ["static", "fixed", "absolute", "relative", "sticky"],
        inset: [{ inset: [g] }],
        "inset-x": [{ "inset-x": [g] }],
        "inset-y": [{ "inset-y": [g] }],
        start: [{ start: [g] }],
        end: [{ end: [g] }],
        top: [{ top: [g] }],
        right: [{ right: [g] }],
        bottom: [{ bottom: [g] }],
        left: [{ left: [g] }],
        visibility: ["visible", "invisible", "collapse"],
        z: [{ z: ["auto", uo, W] }],
        basis: [{ basis: $() }],
        "flex-direction": [
          { flex: ["row", "row-reverse", "col", "col-reverse"] },
        ],
        "flex-wrap": [{ flex: ["wrap", "wrap-reverse", "nowrap"] }],
        flex: [{ flex: ["1", "auto", "initial", "none", W] }],
        grow: [{ grow: A() }],
        shrink: [{ shrink: A() }],
        order: [{ order: ["first", "last", "none", uo, W] }],
        "grid-cols": [{ "grid-cols": [co] }],
        "col-start-end": [{ col: ["auto", { span: ["full", uo, W] }, W] }],
        "col-start": [{ "col-start": O() }],
        "col-end": [{ "col-end": O() }],
        "grid-rows": [{ "grid-rows": [co] }],
        "row-start-end": [{ row: ["auto", { span: [uo, W] }, W] }],
        "row-start": [{ "row-start": O() }],
        "row-end": [{ "row-end": O() }],
        "grid-flow": [
          { "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"] },
        ],
        "auto-cols": [{ "auto-cols": ["auto", "min", "max", "fr", W] }],
        "auto-rows": [{ "auto-rows": ["auto", "min", "max", "fr", W] }],
        gap: [{ gap: [c] }],
        "gap-x": [{ "gap-x": [c] }],
        "gap-y": [{ "gap-y": [c] }],
        "justify-content": [{ justify: ["normal", ...C()] }],
        "justify-items": [
          { "justify-items": ["start", "end", "center", "stretch"] },
        ],
        "justify-self": [
          { "justify-self": ["auto", "start", "end", "center", "stretch"] },
        ],
        "align-content": [{ content: ["normal", ...C(), "baseline"] }],
        "align-items": [
          { items: ["start", "end", "center", "baseline", "stretch"] },
        ],
        "align-self": [
          { self: ["auto", "start", "end", "center", "stretch", "baseline"] },
        ],
        "place-content": [{ "place-content": [...C(), "baseline"] }],
        "place-items": [
          { "place-items": ["start", "end", "center", "baseline", "stretch"] },
        ],
        "place-self": [
          { "place-self": ["auto", "start", "end", "center", "stretch"] },
        ],
        p: [{ p: [p] }],
        px: [{ px: [p] }],
        py: [{ py: [p] }],
        ps: [{ ps: [p] }],
        pe: [{ pe: [p] }],
        pt: [{ pt: [p] }],
        pr: [{ pr: [p] }],
        pb: [{ pb: [p] }],
        pl: [{ pl: [p] }],
        m: [{ m: [S] }],
        mx: [{ mx: [S] }],
        my: [{ my: [S] }],
        ms: [{ ms: [S] }],
        me: [{ me: [S] }],
        mt: [{ mt: [S] }],
        mr: [{ mr: [S] }],
        mb: [{ mb: [S] }],
        ml: [{ ml: [S] }],
        "space-x": [{ "space-x": [P] }],
        "space-x-reverse": ["space-x-reverse"],
        "space-y": [{ "space-y": [P] }],
        "space-y-reverse": ["space-y-reverse"],
        w: [{ w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", W, t] }],
        "min-w": [{ "min-w": [W, t, "min", "max", "fit"] }],
        "max-w": [
          {
            "max-w": [
              W,
              t,
              "none",
              "full",
              "min",
              "max",
              "fit",
              "prose",
              { screen: [rn] },
              rn,
            ],
          },
        ],
        h: [{ h: [W, t, "auto", "min", "max", "fit", "svh", "lvh", "dvh"] }],
        "min-h": [
          { "min-h": [W, t, "min", "max", "fit", "svh", "lvh", "dvh"] },
        ],
        "max-h": [
          { "max-h": [W, t, "min", "max", "fit", "svh", "lvh", "dvh"] },
        ],
        size: [{ size: [W, t, "auto", "min", "max", "fit"] }],
        "font-size": [{ text: ["base", rn, nn] }],
        "font-smoothing": ["antialiased", "subpixel-antialiased"],
        "font-style": ["italic", "not-italic"],
        "font-weight": [
          {
            font: [
              "thin",
              "extralight",
              "light",
              "normal",
              "medium",
              "semibold",
              "bold",
              "extrabold",
              "black",
              Ll,
            ],
          },
        ],
        "font-family": [{ font: [co] }],
        "fvn-normal": ["normal-nums"],
        "fvn-ordinal": ["ordinal"],
        "fvn-slashed-zero": ["slashed-zero"],
        "fvn-figure": ["lining-nums", "oldstyle-nums"],
        "fvn-spacing": ["proportional-nums", "tabular-nums"],
        "fvn-fraction": ["diagonal-fractions", "stacked-fractons"],
        tracking: [
          {
            tracking: [
              "tighter",
              "tight",
              "normal",
              "wide",
              "wider",
              "widest",
              W,
            ],
          },
        ],
        "line-clamp": [{ "line-clamp": ["none", Nr, Ll] }],
        leading: [
          {
            leading: [
              "none",
              "tight",
              "snug",
              "normal",
              "relaxed",
              "loose",
              Lt,
              W,
            ],
          },
        ],
        "list-image": [{ "list-image": ["none", W] }],
        "list-style-type": [{ list: ["none", "disc", "decimal", W] }],
        "list-style-position": [{ list: ["inside", "outside"] }],
        "placeholder-color": [{ placeholder: [e] }],
        "placeholder-opacity": [{ "placeholder-opacity": [h] }],
        "text-alignment": [
          { text: ["left", "center", "right", "justify", "start", "end"] },
        ],
        "text-color": [{ text: [e] }],
        "text-opacity": [{ "text-opacity": [h] }],
        "text-decoration": [
          "underline",
          "overline",
          "line-through",
          "no-underline",
        ],
        "text-decoration-style": [{ decoration: [...U(), "wavy"] }],
        "text-decoration-thickness": [
          { decoration: ["auto", "from-font", Lt, nn] },
        ],
        "underline-offset": [{ "underline-offset": ["auto", Lt, W] }],
        "text-decoration-color": [{ decoration: [e] }],
        "text-transform": [
          "uppercase",
          "lowercase",
          "capitalize",
          "normal-case",
        ],
        "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
        "text-wrap": [{ text: ["wrap", "nowrap", "balance", "pretty"] }],
        indent: [{ indent: D() }],
        "vertical-align": [
          {
            align: [
              "baseline",
              "top",
              "middle",
              "bottom",
              "text-top",
              "text-bottom",
              "sub",
              "super",
              W,
            ],
          },
        ],
        whitespace: [
          {
            whitespace: [
              "normal",
              "nowrap",
              "pre",
              "pre-line",
              "pre-wrap",
              "break-spaces",
            ],
          },
        ],
        break: [{ break: ["normal", "words", "all", "keep"] }],
        hyphens: [{ hyphens: ["none", "manual", "auto"] }],
        content: [{ content: ["none", W] }],
        "bg-attachment": [{ bg: ["fixed", "local", "scroll"] }],
        "bg-clip": [{ "bg-clip": ["border", "padding", "content", "text"] }],
        "bg-opacity": [{ "bg-opacity": [h] }],
        "bg-origin": [{ "bg-origin": ["border", "padding", "content"] }],
        "bg-position": [{ bg: [...Q(), Ix] }],
        "bg-repeat": [
          { bg: ["no-repeat", { repeat: ["", "x", "y", "round", "space"] }] },
        ],
        "bg-size": [{ bg: ["auto", "cover", "contain", Lx] }],
        "bg-image": [
          {
            bg: [
              "none",
              { "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"] },
              zx,
            ],
          },
        ],
        "bg-color": [{ bg: [e] }],
        "gradient-from-pos": [{ from: [x] }],
        "gradient-via-pos": [{ via: [x] }],
        "gradient-to-pos": [{ to: [x] }],
        "gradient-from": [{ from: [v] }],
        "gradient-via": [{ via: [v] }],
        "gradient-to": [{ to: [v] }],
        rounded: [{ rounded: [i] }],
        "rounded-s": [{ "rounded-s": [i] }],
        "rounded-e": [{ "rounded-e": [i] }],
        "rounded-t": [{ "rounded-t": [i] }],
        "rounded-r": [{ "rounded-r": [i] }],
        "rounded-b": [{ "rounded-b": [i] }],
        "rounded-l": [{ "rounded-l": [i] }],
        "rounded-ss": [{ "rounded-ss": [i] }],
        "rounded-se": [{ "rounded-se": [i] }],
        "rounded-ee": [{ "rounded-ee": [i] }],
        "rounded-es": [{ "rounded-es": [i] }],
        "rounded-tl": [{ "rounded-tl": [i] }],
        "rounded-tr": [{ "rounded-tr": [i] }],
        "rounded-br": [{ "rounded-br": [i] }],
        "rounded-bl": [{ "rounded-bl": [i] }],
        "border-w": [{ border: [l] }],
        "border-w-x": [{ "border-x": [l] }],
        "border-w-y": [{ "border-y": [l] }],
        "border-w-s": [{ "border-s": [l] }],
        "border-w-e": [{ "border-e": [l] }],
        "border-w-t": [{ "border-t": [l] }],
        "border-w-r": [{ "border-r": [l] }],
        "border-w-b": [{ "border-b": [l] }],
        "border-w-l": [{ "border-l": [l] }],
        "border-opacity": [{ "border-opacity": [h] }],
        "border-style": [{ border: [...U(), "hidden"] }],
        "divide-x": [{ "divide-x": [l] }],
        "divide-x-reverse": ["divide-x-reverse"],
        "divide-y": [{ "divide-y": [l] }],
        "divide-y-reverse": ["divide-y-reverse"],
        "divide-opacity": [{ "divide-opacity": [h] }],
        "divide-style": [{ divide: U() }],
        "border-color": [{ border: [o] }],
        "border-color-x": [{ "border-x": [o] }],
        "border-color-y": [{ "border-y": [o] }],
        "border-color-s": [{ "border-s": [o] }],
        "border-color-e": [{ "border-e": [o] }],
        "border-color-t": [{ "border-t": [o] }],
        "border-color-r": [{ "border-r": [o] }],
        "border-color-b": [{ "border-b": [o] }],
        "border-color-l": [{ "border-l": [o] }],
        "divide-color": [{ divide: [o] }],
        "outline-style": [{ outline: ["", ...U()] }],
        "outline-offset": [{ "outline-offset": [Lt, W] }],
        "outline-w": [{ outline: [Lt, nn] }],
        "outline-color": [{ outline: [e] }],
        "ring-w": [{ ring: H() }],
        "ring-w-inset": ["ring-inset"],
        "ring-color": [{ ring: [e] }],
        "ring-opacity": [{ "ring-opacity": [h] }],
        "ring-offset-w": [{ "ring-offset": [Lt, nn] }],
        "ring-offset-color": [{ "ring-offset": [e] }],
        shadow: [{ shadow: ["", "inner", "none", rn, Fx] }],
        "shadow-color": [{ shadow: [co] }],
        opacity: [{ opacity: [h] }],
        "mix-blend": [{ "mix-blend": [...K(), "plus-lighter", "plus-darker"] }],
        "bg-blend": [{ "bg-blend": K() }],
        filter: [{ filter: ["", "none"] }],
        blur: [{ blur: [n] }],
        brightness: [{ brightness: [r] }],
        contrast: [{ contrast: [a] }],
        "drop-shadow": [{ "drop-shadow": ["", "none", rn, W] }],
        grayscale: [{ grayscale: [u] }],
        "hue-rotate": [{ "hue-rotate": [d] }],
        invert: [{ invert: [f] }],
        saturate: [{ saturate: [m] }],
        sepia: [{ sepia: [E] }],
        "backdrop-filter": [{ "backdrop-filter": ["", "none"] }],
        "backdrop-blur": [{ "backdrop-blur": [n] }],
        "backdrop-brightness": [{ "backdrop-brightness": [r] }],
        "backdrop-contrast": [{ "backdrop-contrast": [a] }],
        "backdrop-grayscale": [{ "backdrop-grayscale": [u] }],
        "backdrop-hue-rotate": [{ "backdrop-hue-rotate": [d] }],
        "backdrop-invert": [{ "backdrop-invert": [f] }],
        "backdrop-opacity": [{ "backdrop-opacity": [h] }],
        "backdrop-saturate": [{ "backdrop-saturate": [m] }],
        "backdrop-sepia": [{ "backdrop-sepia": [E] }],
        "border-collapse": [{ border: ["collapse", "separate"] }],
        "border-spacing": [{ "border-spacing": [s] }],
        "border-spacing-x": [{ "border-spacing-x": [s] }],
        "border-spacing-y": [{ "border-spacing-y": [s] }],
        "table-layout": [{ table: ["auto", "fixed"] }],
        caption: [{ caption: ["top", "bottom"] }],
        transition: [
          {
            transition: [
              "none",
              "all",
              "",
              "colors",
              "opacity",
              "shadow",
              "transform",
              W,
            ],
          },
        ],
        duration: [{ duration: L() }],
        ease: [{ ease: ["linear", "in", "out", "in-out", W] }],
        delay: [{ delay: L() }],
        animate: [{ animate: ["none", "spin", "ping", "pulse", "bounce", W] }],
        transform: [{ transform: ["", "gpu", "none"] }],
        scale: [{ scale: [k] }],
        "scale-x": [{ "scale-x": [k] }],
        "scale-y": [{ "scale-y": [k] }],
        rotate: [{ rotate: [uo, W] }],
        "translate-x": [{ "translate-x": [T] }],
        "translate-y": [{ "translate-y": [T] }],
        "skew-x": [{ "skew-x": [b] }],
        "skew-y": [{ "skew-y": [b] }],
        "transform-origin": [
          {
            origin: [
              "center",
              "top",
              "top-right",
              "right",
              "bottom-right",
              "bottom",
              "bottom-left",
              "left",
              "top-left",
              W,
            ],
          },
        ],
        accent: [{ accent: ["auto", e] }],
        appearance: [{ appearance: ["none", "auto"] }],
        cursor: [
          {
            cursor: [
              "auto",
              "default",
              "pointer",
              "wait",
              "text",
              "move",
              "help",
              "not-allowed",
              "none",
              "context-menu",
              "progress",
              "cell",
              "crosshair",
              "vertical-text",
              "alias",
              "copy",
              "no-drop",
              "grab",
              "grabbing",
              "all-scroll",
              "col-resize",
              "row-resize",
              "n-resize",
              "e-resize",
              "s-resize",
              "w-resize",
              "ne-resize",
              "nw-resize",
              "se-resize",
              "sw-resize",
              "ew-resize",
              "ns-resize",
              "nesw-resize",
              "nwse-resize",
              "zoom-in",
              "zoom-out",
              W,
            ],
          },
        ],
        "caret-color": [{ caret: [e] }],
        "pointer-events": [{ "pointer-events": ["none", "auto"] }],
        resize: [{ resize: ["none", "y", "x", ""] }],
        "scroll-behavior": [{ scroll: ["auto", "smooth"] }],
        "scroll-m": [{ "scroll-m": D() }],
        "scroll-mx": [{ "scroll-mx": D() }],
        "scroll-my": [{ "scroll-my": D() }],
        "scroll-ms": [{ "scroll-ms": D() }],
        "scroll-me": [{ "scroll-me": D() }],
        "scroll-mt": [{ "scroll-mt": D() }],
        "scroll-mr": [{ "scroll-mr": D() }],
        "scroll-mb": [{ "scroll-mb": D() }],
        "scroll-ml": [{ "scroll-ml": D() }],
        "scroll-p": [{ "scroll-p": D() }],
        "scroll-px": [{ "scroll-px": D() }],
        "scroll-py": [{ "scroll-py": D() }],
        "scroll-ps": [{ "scroll-ps": D() }],
        "scroll-pe": [{ "scroll-pe": D() }],
        "scroll-pt": [{ "scroll-pt": D() }],
        "scroll-pr": [{ "scroll-pr": D() }],
        "scroll-pb": [{ "scroll-pb": D() }],
        "scroll-pl": [{ "scroll-pl": D() }],
        "snap-align": [{ snap: ["start", "end", "center", "align-none"] }],
        "snap-stop": [{ snap: ["normal", "always"] }],
        "snap-type": [{ snap: ["none", "x", "y", "both"] }],
        "snap-strictness": [{ snap: ["mandatory", "proximity"] }],
        touch: [{ touch: ["auto", "none", "manipulation"] }],
        "touch-x": [{ "touch-pan": ["x", "left", "right"] }],
        "touch-y": [{ "touch-pan": ["y", "up", "down"] }],
        "touch-pz": ["touch-pinch-zoom"],
        select: [{ select: ["none", "text", "all", "auto"] }],
        "will-change": [
          { "will-change": ["auto", "scroll", "contents", "transform", W] },
        ],
        fill: [{ fill: [e, "none"] }],
        "stroke-w": [{ stroke: [Lt, nn, Ll] }],
        stroke: [{ stroke: [e, "none"] }],
        sr: ["sr-only", "not-sr-only"],
        "forced-color-adjust": [{ "forced-color-adjust": ["auto", "none"] }],
      },
      conflictingClassGroups: {
        overflow: ["overflow-x", "overflow-y"],
        overscroll: ["overscroll-x", "overscroll-y"],
        inset: [
          "inset-x",
          "inset-y",
          "start",
          "end",
          "top",
          "right",
          "bottom",
          "left",
        ],
        "inset-x": ["right", "left"],
        "inset-y": ["top", "bottom"],
        flex: ["basis", "grow", "shrink"],
        gap: ["gap-x", "gap-y"],
        p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
        px: ["pr", "pl"],
        py: ["pt", "pb"],
        m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
        mx: ["mr", "ml"],
        my: ["mt", "mb"],
        size: ["w", "h"],
        "font-size": ["leading"],
        "fvn-normal": [
          "fvn-ordinal",
          "fvn-slashed-zero",
          "fvn-figure",
          "fvn-spacing",
          "fvn-fraction",
        ],
        "fvn-ordinal": ["fvn-normal"],
        "fvn-slashed-zero": ["fvn-normal"],
        "fvn-figure": ["fvn-normal"],
        "fvn-spacing": ["fvn-normal"],
        "fvn-fraction": ["fvn-normal"],
        "line-clamp": ["display", "overflow"],
        rounded: [
          "rounded-s",
          "rounded-e",
          "rounded-t",
          "rounded-r",
          "rounded-b",
          "rounded-l",
          "rounded-ss",
          "rounded-se",
          "rounded-ee",
          "rounded-es",
          "rounded-tl",
          "rounded-tr",
          "rounded-br",
          "rounded-bl",
        ],
        "rounded-s": ["rounded-ss", "rounded-es"],
        "rounded-e": ["rounded-se", "rounded-ee"],
        "rounded-t": ["rounded-tl", "rounded-tr"],
        "rounded-r": ["rounded-tr", "rounded-br"],
        "rounded-b": ["rounded-br", "rounded-bl"],
        "rounded-l": ["rounded-tl", "rounded-bl"],
        "border-spacing": ["border-spacing-x", "border-spacing-y"],
        "border-w": [
          "border-w-s",
          "border-w-e",
          "border-w-t",
          "border-w-r",
          "border-w-b",
          "border-w-l",
        ],
        "border-w-x": ["border-w-r", "border-w-l"],
        "border-w-y": ["border-w-t", "border-w-b"],
        "border-color": [
          "border-color-s",
          "border-color-e",
          "border-color-t",
          "border-color-r",
          "border-color-b",
          "border-color-l",
        ],
        "border-color-x": ["border-color-r", "border-color-l"],
        "border-color-y": ["border-color-t", "border-color-b"],
        "scroll-m": [
          "scroll-mx",
          "scroll-my",
          "scroll-ms",
          "scroll-me",
          "scroll-mt",
          "scroll-mr",
          "scroll-mb",
          "scroll-ml",
        ],
        "scroll-mx": ["scroll-mr", "scroll-ml"],
        "scroll-my": ["scroll-mt", "scroll-mb"],
        "scroll-p": [
          "scroll-px",
          "scroll-py",
          "scroll-ps",
          "scroll-pe",
          "scroll-pt",
          "scroll-pr",
          "scroll-pb",
          "scroll-pl",
        ],
        "scroll-px": ["scroll-pr", "scroll-pl"],
        "scroll-py": ["scroll-pt", "scroll-pb"],
        touch: ["touch-x", "touch-y", "touch-pz"],
        "touch-x": ["touch"],
        "touch-y": ["touch"],
        "touch-pz": ["touch"],
      },
      conflictingClassGroupModifiers: { "font-size": ["leading"] },
    };
  },
  Vx = bx(Wx);
function Ot(...e) {
  return Vx(nm(e));
}
const Hx = qy,
  fm = y.forwardRef(({ className: e, ...t }, n) =>
    w.jsx(Yh, {
      ref: n,
      className: Ot(
        "fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]",
        e
      ),
      ...t,
    })
  );
fm.displayName = Yh.displayName;
const Qx = Jy(
    "group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-6 pr-8 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full",
    {
      variants: {
        variant: {
          default: "border bg-background text-foreground",
          destructive:
            "destructive group border-destructive bg-destructive text-destructive-foreground",
        },
      },
      defaultVariants: { variant: "default" },
    }
  ),
  pm = y.forwardRef(({ className: e, variant: t, ...n }, r) =>
    w.jsx(Xh, { ref: r, className: Ot(Qx({ variant: t }), e), ...n })
  );
pm.displayName = Xh.displayName;
const Kx = y.forwardRef(({ className: e, ...t }, n) =>
  w.jsx(Zh, {
    ref: n,
    className: Ot(
      "inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-background transition-colors hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive",
      e
    ),
    ...t,
  })
);
Kx.displayName = Zh.displayName;
const hm = y.forwardRef(({ className: e, ...t }, n) =>
  w.jsx(em, {
    ref: n,
    className: Ot(
      "absolute right-2 top-2 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-2 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600",
      e
    ),
    "toast-close": "",
    ...t,
    children: w.jsx(dx, { className: "h-4 w-4" }),
  })
);
hm.displayName = em.displayName;
const mm = y.forwardRef(({ className: e, ...t }, n) =>
  w.jsx(qh, { ref: n, className: Ot("text-sm font-semibold", e), ...t })
);
mm.displayName = qh.displayName;
const gm = y.forwardRef(({ className: e, ...t }, n) =>
  w.jsx(Jh, { ref: n, className: Ot("text-sm opacity-90", e), ...t })
);
gm.displayName = Jh.displayName;
function Gx() {
  const { toasts: e } = ly();
  return w.jsxs(Hx, {
    children: [
      e.map(function ({ id: t, title: n, description: r, action: o, ...i }) {
        return w.jsxs(
          pm,
          {
            ...i,
            children: [
              w.jsxs("div", {
                className: "grid gap-1",
                children: [
                  n && w.jsx(mm, { children: n }),
                  r && w.jsx(gm, { children: r }),
                ],
              }),
              o,
              w.jsx(hm, {}),
            ],
          },
          t
        );
      }),
      w.jsx(fm, {}),
    ],
  });
}
var Od = ["light", "dark"],
  Yx = "(prefers-color-scheme: dark)",
  Xx = y.createContext(void 0),
  qx = { setTheme: (e) => {}, themes: [] },
  Jx = () => {
    var e;
    return (e = y.useContext(Xx)) != null ? e : qx;
  };
y.memo(
  ({
    forcedTheme: e,
    storageKey: t,
    attribute: n,
    enableSystem: r,
    enableColorScheme: o,
    defaultTheme: i,
    value: s,
    attrs: l,
    nonce: a,
  }) => {
    let u = i === "system",
      d =
        n === "class"
          ? `var d=document.documentElement,c=d.classList;${`c.remove(${l
              .map((x) => `'${x}'`)
              .join(",")})`};`
          : `var d=document.documentElement,n='${n}',s='setAttribute';`,
      f = o
        ? Od.includes(i) && i
          ? `if(e==='light'||e==='dark'||!e)d.style.colorScheme=e||'${i}'`
          : "if(e==='light'||e==='dark')d.style.colorScheme=e"
        : "",
      c = (x, g = !1, S = !0) => {
        let h = s ? s[x] : x,
          p = g ? x + "|| ''" : `'${h}'`,
          m = "";
        return (
          o &&
            S &&
            !g &&
            Od.includes(x) &&
            (m += `d.style.colorScheme = '${x}';`),
          n === "class"
            ? g || h
              ? (m += `c.add(${p})`)
              : (m += "null")
            : h && (m += `d[s](n,${p})`),
          m
        );
      },
      v = e
        ? `!function(){${d}${c(e)}}()`
        : r
        ? `!function(){try{${d}var e=localStorage.getItem('${t}');if('system'===e||(!e&&${u})){var t='${Yx}',m=window.matchMedia(t);if(m.media!==t||m.matches){${c(
            "dark"
          )}}else{${c("light")}}}else if(e){${
            s ? `var x=${JSON.stringify(s)};` : ""
          }${c(s ? "x[e]" : "e", !0)}}${
            u ? "" : "else{" + c(i, !1, !1) + "}"
          }${f}}catch(e){}}()`
        : `!function(){try{${d}var e=localStorage.getItem('${t}');if(e){${
            s ? `var x=${JSON.stringify(s)};` : ""
          }${c(s ? "x[e]" : "e", !0)}}else{${c(
            i,
            !1,
            !1
          )};}${f}}catch(t){}}();`;
    return y.createElement("script", {
      nonce: a,
      dangerouslySetInnerHTML: { __html: v },
    });
  }
);
var Zx = (e) => {
    switch (e) {
      case "success":
        return nw;
      case "info":
        return ow;
      case "warning":
        return rw;
      case "error":
        return iw;
      default:
        return null;
    }
  },
  ew = Array(12).fill(0),
  tw = ({ visible: e }) =>
    j.createElement(
      "div",
      { className: "sonner-loading-wrapper", "data-visible": e },
      j.createElement(
        "div",
        { className: "sonner-spinner" },
        ew.map((t, n) =>
          j.createElement("div", {
            className: "sonner-loading-bar",
            key: `spinner-bar-${n}`,
          })
        )
      )
    ),
  nw = j.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      height: "20",
      width: "20",
    },
    j.createElement("path", {
      fillRule: "evenodd",
      d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z",
      clipRule: "evenodd",
    })
  ),
  rw = j.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 24 24",
      fill: "currentColor",
      height: "20",
      width: "20",
    },
    j.createElement("path", {
      fillRule: "evenodd",
      d: "M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z",
      clipRule: "evenodd",
    })
  ),
  ow = j.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      height: "20",
      width: "20",
    },
    j.createElement("path", {
      fillRule: "evenodd",
      d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z",
      clipRule: "evenodd",
    })
  ),
  iw = j.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      height: "20",
      width: "20",
    },
    j.createElement("path", {
      fillRule: "evenodd",
      d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z",
      clipRule: "evenodd",
    })
  ),
  sw = () => {
    let [e, t] = j.useState(document.hidden);
    return (
      j.useEffect(() => {
        let n = () => {
          t(document.hidden);
        };
        return (
          document.addEventListener("visibilitychange", n),
          () => window.removeEventListener("visibilitychange", n)
        );
      }, []),
      e
    );
  },
  za = 1,
  lw = class {
    constructor() {
      (this.subscribe = (e) => (
        this.subscribers.push(e),
        () => {
          let t = this.subscribers.indexOf(e);
          this.subscribers.splice(t, 1);
        }
      )),
        (this.publish = (e) => {
          this.subscribers.forEach((t) => t(e));
        }),
        (this.addToast = (e) => {
          this.publish(e), (this.toasts = [...this.toasts, e]);
        }),
        (this.create = (e) => {
          var t;
          let { message: n, ...r } = e,
            o =
              typeof (e == null ? void 0 : e.id) == "number" ||
              ((t = e.id) == null ? void 0 : t.length) > 0
                ? e.id
                : za++,
            i = this.toasts.find((l) => l.id === o),
            s = e.dismissible === void 0 ? !0 : e.dismissible;
          return (
            i
              ? (this.toasts = this.toasts.map((l) =>
                  l.id === o
                    ? (this.publish({ ...l, ...e, id: o, title: n }),
                      { ...l, ...e, id: o, dismissible: s, title: n })
                    : l
                ))
              : this.addToast({ title: n, ...r, dismissible: s, id: o }),
            o
          );
        }),
        (this.dismiss = (e) => (
          e ||
            this.toasts.forEach((t) => {
              this.subscribers.forEach((n) => n({ id: t.id, dismiss: !0 }));
            }),
          this.subscribers.forEach((t) => t({ id: e, dismiss: !0 })),
          e
        )),
        (this.message = (e, t) => this.create({ ...t, message: e })),
        (this.error = (e, t) =>
          this.create({ ...t, message: e, type: "error" })),
        (this.success = (e, t) =>
          this.create({ ...t, type: "success", message: e })),
        (this.info = (e, t) => this.create({ ...t, type: "info", message: e })),
        (this.warning = (e, t) =>
          this.create({ ...t, type: "warning", message: e })),
        (this.loading = (e, t) =>
          this.create({ ...t, type: "loading", message: e })),
        (this.promise = (e, t) => {
          if (!t) return;
          let n;
          t.loading !== void 0 &&
            (n = this.create({
              ...t,
              promise: e,
              type: "loading",
              message: t.loading,
              description:
                typeof t.description != "function" ? t.description : void 0,
            }));
          let r = e instanceof Promise ? e : e(),
            o = n !== void 0;
          return (
            r
              .then(async (i) => {
                if (uw(i) && !i.ok) {
                  o = !1;
                  let s =
                      typeof t.error == "function"
                        ? await t.error(`HTTP error! status: ${i.status}`)
                        : t.error,
                    l =
                      typeof t.description == "function"
                        ? await t.description(`HTTP error! status: ${i.status}`)
                        : t.description;
                  this.create({
                    id: n,
                    type: "error",
                    message: s,
                    description: l,
                  });
                } else if (t.success !== void 0) {
                  o = !1;
                  let s =
                      typeof t.success == "function"
                        ? await t.success(i)
                        : t.success,
                    l =
                      typeof t.description == "function"
                        ? await t.description(i)
                        : t.description;
                  this.create({
                    id: n,
                    type: "success",
                    message: s,
                    description: l,
                  });
                }
              })
              .catch(async (i) => {
                if (t.error !== void 0) {
                  o = !1;
                  let s =
                      typeof t.error == "function" ? await t.error(i) : t.error,
                    l =
                      typeof t.description == "function"
                        ? await t.description(i)
                        : t.description;
                  this.create({
                    id: n,
                    type: "error",
                    message: s,
                    description: l,
                  });
                }
              })
              .finally(() => {
                var i;
                o && (this.dismiss(n), (n = void 0)),
                  (i = t.finally) == null || i.call(t);
              }),
            n
          );
        }),
        (this.custom = (e, t) => {
          let n = (t == null ? void 0 : t.id) || za++;
          return this.create({ jsx: e(n), id: n, ...t }), n;
        }),
        (this.subscribers = []),
        (this.toasts = []);
    }
  },
  Qe = new lw(),
  aw = (e, t) => {
    let n = (t == null ? void 0 : t.id) || za++;
    return Qe.addToast({ title: e, ...t, id: n }), n;
  },
  uw = (e) =>
    e &&
    typeof e == "object" &&
    "ok" in e &&
    typeof e.ok == "boolean" &&
    "status" in e &&
    typeof e.status == "number",
  cw = aw,
  dw = () => Qe.toasts,
  fw = Object.assign(
    cw,
    {
      success: Qe.success,
      info: Qe.info,
      warning: Qe.warning,
      error: Qe.error,
      custom: Qe.custom,
      message: Qe.message,
      promise: Qe.promise,
      dismiss: Qe.dismiss,
      loading: Qe.loading,
    },
    { getHistory: dw }
  );
function pw(e, { insertAt: t } = {}) {
  if (typeof document > "u") return;
  let n = document.head || document.getElementsByTagName("head")[0],
    r = document.createElement("style");
  (r.type = "text/css"),
    t === "top" && n.firstChild
      ? n.insertBefore(r, n.firstChild)
      : n.appendChild(r),
    r.styleSheet
      ? (r.styleSheet.cssText = e)
      : r.appendChild(document.createTextNode(e));
}
pw(`:where(html[dir="ltr"]),:where([data-sonner-toaster][dir="ltr"]){--toast-icon-margin-start: -3px;--toast-icon-margin-end: 4px;--toast-svg-margin-start: -1px;--toast-svg-margin-end: 0px;--toast-button-margin-start: auto;--toast-button-margin-end: 0;--toast-close-button-start: 0;--toast-close-button-end: unset;--toast-close-button-transform: translate(-35%, -35%)}:where(html[dir="rtl"]),:where([data-sonner-toaster][dir="rtl"]){--toast-icon-margin-start: 4px;--toast-icon-margin-end: -3px;--toast-svg-margin-start: 0px;--toast-svg-margin-end: -1px;--toast-button-margin-start: 0;--toast-button-margin-end: auto;--toast-close-button-start: unset;--toast-close-button-end: 0;--toast-close-button-transform: translate(35%, -35%)}:where([data-sonner-toaster]){position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1: hsl(0, 0%, 99%);--gray2: hsl(0, 0%, 97.3%);--gray3: hsl(0, 0%, 95.1%);--gray4: hsl(0, 0%, 93%);--gray5: hsl(0, 0%, 90.9%);--gray6: hsl(0, 0%, 88.7%);--gray7: hsl(0, 0%, 85.8%);--gray8: hsl(0, 0%, 78%);--gray9: hsl(0, 0%, 56.1%);--gray10: hsl(0, 0%, 52.3%);--gray11: hsl(0, 0%, 43.5%);--gray12: hsl(0, 0%, 9%);--border-radius: 8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:none;z-index:999999999}:where([data-sonner-toaster][data-x-position="right"]){right:max(var(--offset),env(safe-area-inset-right))}:where([data-sonner-toaster][data-x-position="left"]){left:max(var(--offset),env(safe-area-inset-left))}:where([data-sonner-toaster][data-x-position="center"]){left:50%;transform:translate(-50%)}:where([data-sonner-toaster][data-y-position="top"]){top:max(var(--offset),env(safe-area-inset-top))}:where([data-sonner-toaster][data-y-position="bottom"]){bottom:max(var(--offset),env(safe-area-inset-bottom))}:where([data-sonner-toast]){--y: translateY(100%);--lift-amount: calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);filter:blur(0);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:none;overflow-wrap:anywhere}:where([data-sonner-toast][data-styled="true"]){padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px #0000001a;width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}:where([data-sonner-toast]:focus-visible){box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}:where([data-sonner-toast][data-y-position="top"]){top:0;--y: translateY(-100%);--lift: 1;--lift-amount: calc(1 * var(--gap))}:where([data-sonner-toast][data-y-position="bottom"]){bottom:0;--y: translateY(100%);--lift: -1;--lift-amount: calc(var(--lift) * var(--gap))}:where([data-sonner-toast]) :where([data-description]){font-weight:400;line-height:1.4;color:inherit}:where([data-sonner-toast]) :where([data-title]){font-weight:500;line-height:1.5;color:inherit}:where([data-sonner-toast]) :where([data-icon]){display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}:where([data-sonner-toast][data-promise="true"]) :where([data-icon])>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}:where([data-sonner-toast]) :where([data-icon])>*{flex-shrink:0}:where([data-sonner-toast]) :where([data-icon]) svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}:where([data-sonner-toast]) :where([data-content]){display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;cursor:pointer;outline:none;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}:where([data-sonner-toast]) :where([data-button]):focus-visible{box-shadow:0 0 0 2px #0006}:where([data-sonner-toast]) :where([data-button]):first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}:where([data-sonner-toast]) :where([data-cancel]){color:var(--normal-text);background:rgba(0,0,0,.08)}:where([data-sonner-toast][data-theme="dark"]) :where([data-cancel]){background:rgba(255,255,255,.3)}:where([data-sonner-toast]) :where([data-close-button]){position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;background:var(--gray1);color:var(--gray12);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}:where([data-sonner-toast]) :where([data-close-button]):focus-visible{box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}:where([data-sonner-toast]) :where([data-disabled="true"]){cursor:not-allowed}:where([data-sonner-toast]):hover :where([data-close-button]):hover{background:var(--gray2);border-color:var(--gray5)}:where([data-sonner-toast][data-swiping="true"]):before{content:"";position:absolute;left:0;right:0;height:100%;z-index:-1}:where([data-sonner-toast][data-y-position="top"][data-swiping="true"]):before{bottom:50%;transform:scaleY(3) translateY(50%)}:where([data-sonner-toast][data-y-position="bottom"][data-swiping="true"]):before{top:50%;transform:scaleY(3) translateY(-50%)}:where([data-sonner-toast][data-swiping="false"][data-removed="true"]):before{content:"";position:absolute;inset:0;transform:scaleY(2)}:where([data-sonner-toast]):after{content:"";position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}:where([data-sonner-toast][data-mounted="true"]){--y: translateY(0);opacity:1}:where([data-sonner-toast][data-expanded="false"][data-front="false"]){--scale: var(--toasts-before) * .05 + 1;--y: translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}:where([data-sonner-toast])>*{transition:opacity .4s}:where([data-sonner-toast][data-expanded="false"][data-front="false"][data-styled="true"])>*{opacity:0}:where([data-sonner-toast][data-visible="false"]){opacity:0;pointer-events:none}:where([data-sonner-toast][data-mounted="true"][data-expanded="true"]){--y: translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}:where([data-sonner-toast][data-removed="true"][data-front="true"][data-swipe-out="false"]){--y: translateY(calc(var(--lift) * -100%));opacity:0}:where([data-sonner-toast][data-removed="true"][data-front="false"][data-swipe-out="false"][data-expanded="true"]){--y: translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}:where([data-sonner-toast][data-removed="true"][data-front="false"][data-swipe-out="false"][data-expanded="false"]){--y: translateY(40%);opacity:0;transition:transform .5s,opacity .2s}:where([data-sonner-toast][data-removed="true"][data-front="false"]):before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount, 0px));transition:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation:swipe-out .2s ease-out forwards}@keyframes swipe-out{0%{transform:translateY(calc(var(--lift) * var(--offset) + var(--swipe-amount)));opacity:1}to{transform:translateY(calc(var(--lift) * var(--offset) + var(--swipe-amount) + var(--lift) * -100%));opacity:0}}@media (max-width: 600px){[data-sonner-toaster]{position:fixed;--mobile-offset: 16px;right:var(--mobile-offset);left:var(--mobile-offset);width:100%}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset)}[data-sonner-toaster][data-y-position=bottom]{bottom:20px}[data-sonner-toaster][data-y-position=top]{top:20px}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset);right:var(--mobile-offset);transform:none}}[data-sonner-toaster][data-theme=light]{--normal-bg: #fff;--normal-border: var(--gray4);--normal-text: var(--gray12);--success-bg: hsl(143, 85%, 96%);--success-border: hsl(145, 92%, 91%);--success-text: hsl(140, 100%, 27%);--info-bg: hsl(208, 100%, 97%);--info-border: hsl(221, 91%, 91%);--info-text: hsl(210, 92%, 45%);--warning-bg: hsl(49, 100%, 97%);--warning-border: hsl(49, 91%, 91%);--warning-text: hsl(31, 92%, 45%);--error-bg: hsl(359, 100%, 97%);--error-border: hsl(359, 100%, 94%);--error-text: hsl(360, 100%, 45%)}[data-sonner-toaster][data-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg: #000;--normal-border: hsl(0, 0%, 20%);--normal-text: var(--gray1)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg: #fff;--normal-border: var(--gray3);--normal-text: var(--gray12)}[data-sonner-toaster][data-theme=dark]{--normal-bg: #000;--normal-border: hsl(0, 0%, 20%);--normal-text: var(--gray1);--success-bg: hsl(150, 100%, 6%);--success-border: hsl(147, 100%, 12%);--success-text: hsl(150, 86%, 65%);--info-bg: hsl(215, 100%, 6%);--info-border: hsl(223, 100%, 12%);--info-text: hsl(216, 87%, 65%);--warning-bg: hsl(64, 100%, 6%);--warning-border: hsl(60, 100%, 12%);--warning-text: hsl(46, 87%, 65%);--error-bg: hsl(358, 76%, 10%);--error-border: hsl(357, 89%, 16%);--error-text: hsl(358, 100%, 81%)}[data-rich-colors=true][data-sonner-toast][data-type=success],[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info],[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning],[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error],[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size: 16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:nth-child(1){animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}to{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}to{opacity:.15}}@media (prefers-reduced-motion){[data-sonner-toast],[data-sonner-toast]>*,.sonner-loading-bar{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}
`);
function Ai(e) {
  return e.label !== void 0;
}
var hw = 3,
  mw = "32px",
  gw = 4e3,
  vw = 356,
  yw = 14,
  xw = 20,
  ww = 200;
function Sw(...e) {
  return e.filter(Boolean).join(" ");
}
var kw = (e) => {
  var t, n, r, o, i, s, l, a, u, d;
  let {
      invert: f,
      toast: c,
      unstyled: v,
      interacting: x,
      setHeights: g,
      visibleToasts: S,
      heights: h,
      index: p,
      toasts: m,
      expanded: k,
      removeToast: E,
      defaultRichColors: b,
      closeButton: P,
      style: T,
      cancelButtonStyle: I,
      actionButtonStyle: _,
      className: $ = "",
      descriptionClassName: D = "",
      duration: H,
      position: O,
      gap: Q,
      loadingIcon: U,
      expandByDefault: K,
      classNames: C,
      icons: A,
      closeButtonAriaLabel: z = "Close toast",
      pauseWhenPageIsHidden: L,
      cn: F,
    } = e,
    [Y, le] = j.useState(!1),
    [Ve, J] = j.useState(!1),
    [at, Xt] = j.useState(!1),
    [qt, Jt] = j.useState(!1),
    [si, or] = j.useState(0),
    [In, eo] = j.useState(0),
    li = j.useRef(null),
    Zt = j.useRef(null),
    el = p === 0,
    tl = p + 1 <= S,
    Se = c.type,
    ir = c.dismissible !== !1,
    kg = c.className || "",
    Eg = c.descriptionClassName || "",
    ai = j.useMemo(
      () => h.findIndex((B) => B.toastId === c.id) || 0,
      [h, c.id]
    ),
    Cg = j.useMemo(() => {
      var B;
      return (B = c.closeButton) != null ? B : P;
    }, [c.closeButton, P]),
    ac = j.useMemo(() => c.duration || H || gw, [c.duration, H]),
    nl = j.useRef(0),
    sr = j.useRef(0),
    uc = j.useRef(0),
    lr = j.useRef(null),
    [cc, bg] = O.split("-"),
    dc = j.useMemo(
      () => h.reduce((B, ne, ee) => (ee >= ai ? B : B + ne.height), 0),
      [h, ai]
    ),
    fc = sw(),
    Pg = c.invert || f,
    rl = Se === "loading";
  (sr.current = j.useMemo(() => ai * Q + dc, [ai, dc])),
    j.useEffect(() => {
      le(!0);
    }, []),
    j.useLayoutEffect(() => {
      if (!Y) return;
      let B = Zt.current,
        ne = B.style.height;
      B.style.height = "auto";
      let ee = B.getBoundingClientRect().height;
      (B.style.height = ne),
        eo(ee),
        g((kt) =>
          kt.find((Et) => Et.toastId === c.id)
            ? kt.map((Et) => (Et.toastId === c.id ? { ...Et, height: ee } : Et))
            : [{ toastId: c.id, height: ee, position: c.position }, ...kt]
        );
    }, [Y, c.title, c.description, g, c.id]);
  let en = j.useCallback(() => {
    J(!0),
      or(sr.current),
      g((B) => B.filter((ne) => ne.toastId !== c.id)),
      setTimeout(() => {
        E(c);
      }, ww);
  }, [c, E, g, sr]);
  j.useEffect(() => {
    if (
      (c.promise && Se === "loading") ||
      c.duration === 1 / 0 ||
      c.type === "loading"
    )
      return;
    let B,
      ne = ac;
    return (
      k || x || (L && fc)
        ? (() => {
            if (uc.current < nl.current) {
              let ee = new Date().getTime() - nl.current;
              ne = ne - ee;
            }
            uc.current = new Date().getTime();
          })()
        : ne !== 1 / 0 &&
          ((nl.current = new Date().getTime()),
          (B = setTimeout(() => {
            var ee;
            (ee = c.onAutoClose) == null || ee.call(c, c), en();
          }, ne))),
      () => clearTimeout(B)
    );
  }, [k, x, K, c, ac, en, c.promise, Se, L, fc]),
    j.useEffect(() => {
      let B = Zt.current;
      if (B) {
        let ne = B.getBoundingClientRect().height;
        return (
          eo(ne),
          g((ee) => [
            { toastId: c.id, height: ne, position: c.position },
            ...ee,
          ]),
          () => g((ee) => ee.filter((kt) => kt.toastId !== c.id))
        );
      }
    }, [g, c.id]),
    j.useEffect(() => {
      c.delete && en();
    }, [en, c.delete]);
  function Ng() {
    return A != null && A.loading
      ? j.createElement(
          "div",
          { className: "sonner-loader", "data-visible": Se === "loading" },
          A.loading
        )
      : U
      ? j.createElement(
          "div",
          { className: "sonner-loader", "data-visible": Se === "loading" },
          U
        )
      : j.createElement(tw, { visible: Se === "loading" });
  }
  return j.createElement(
    "li",
    {
      "aria-live": c.important ? "assertive" : "polite",
      "aria-atomic": "true",
      role: "status",
      tabIndex: 0,
      ref: Zt,
      className: F(
        $,
        kg,
        C == null ? void 0 : C.toast,
        (t = c == null ? void 0 : c.classNames) == null ? void 0 : t.toast,
        C == null ? void 0 : C.default,
        C == null ? void 0 : C[Se],
        (n = c == null ? void 0 : c.classNames) == null ? void 0 : n[Se]
      ),
      "data-sonner-toast": "",
      "data-rich-colors": (r = c.richColors) != null ? r : b,
      "data-styled": !(c.jsx || c.unstyled || v),
      "data-mounted": Y,
      "data-promise": !!c.promise,
      "data-removed": Ve,
      "data-visible": tl,
      "data-y-position": cc,
      "data-x-position": bg,
      "data-index": p,
      "data-front": el,
      "data-swiping": at,
      "data-dismissible": ir,
      "data-type": Se,
      "data-invert": Pg,
      "data-swipe-out": qt,
      "data-expanded": !!(k || (K && Y)),
      style: {
        "--index": p,
        "--toasts-before": p,
        "--z-index": m.length - p,
        "--offset": `${Ve ? si : sr.current}px`,
        "--initial-height": K ? "auto" : `${In}px`,
        ...T,
        ...c.style,
      },
      onPointerDown: (B) => {
        rl ||
          !ir ||
          ((li.current = new Date()),
          or(sr.current),
          B.target.setPointerCapture(B.pointerId),
          B.target.tagName !== "BUTTON" &&
            (Xt(!0), (lr.current = { x: B.clientX, y: B.clientY })));
      },
      onPointerUp: () => {
        var B, ne, ee, kt;
        if (qt || !ir) return;
        lr.current = null;
        let Et = Number(
            ((B = Zt.current) == null
              ? void 0
              : B.style.getPropertyValue("--swipe-amount").replace("px", "")) ||
              0
          ),
          ui =
            new Date().getTime() -
            ((ne = li.current) == null ? void 0 : ne.getTime()),
          Tg = Math.abs(Et) / ui;
        if (Math.abs(Et) >= xw || Tg > 0.11) {
          or(sr.current),
            (ee = c.onDismiss) == null || ee.call(c, c),
            en(),
            Jt(!0);
          return;
        }
        (kt = Zt.current) == null ||
          kt.style.setProperty("--swipe-amount", "0px"),
          Xt(!1);
      },
      onPointerMove: (B) => {
        var ne;
        if (!lr.current || !ir) return;
        let ee = B.clientY - lr.current.y,
          kt = B.clientX - lr.current.x,
          Et = (cc === "top" ? Math.min : Math.max)(0, ee),
          ui = B.pointerType === "touch" ? 10 : 2;
        Math.abs(Et) > ui
          ? (ne = Zt.current) == null ||
            ne.style.setProperty("--swipe-amount", `${ee}px`)
          : Math.abs(kt) > ui && (lr.current = null);
      },
    },
    Cg && !c.jsx
      ? j.createElement(
          "button",
          {
            "aria-label": z,
            "data-disabled": rl,
            "data-close-button": !0,
            onClick:
              rl || !ir
                ? () => {}
                : () => {
                    var B;
                    en(), (B = c.onDismiss) == null || B.call(c, c);
                  },
            className: F(
              C == null ? void 0 : C.closeButton,
              (o = c == null ? void 0 : c.classNames) == null
                ? void 0
                : o.closeButton
            ),
          },
          j.createElement(
            "svg",
            {
              xmlns: "http://www.w3.org/2000/svg",
              width: "12",
              height: "12",
              viewBox: "0 0 24 24",
              fill: "none",
              stroke: "currentColor",
              strokeWidth: "1.5",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            },
            j.createElement("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
            j.createElement("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
          )
        )
      : null,
    c.jsx || j.isValidElement(c.title)
      ? c.jsx || c.title
      : j.createElement(
          j.Fragment,
          null,
          Se || c.icon || c.promise
            ? j.createElement(
                "div",
                {
                  "data-icon": "",
                  className: F(
                    C == null ? void 0 : C.icon,
                    (i = c == null ? void 0 : c.classNames) == null
                      ? void 0
                      : i.icon
                  ),
                },
                c.promise || (c.type === "loading" && !c.icon)
                  ? c.icon || Ng()
                  : null,
                c.type !== "loading"
                  ? c.icon || (A == null ? void 0 : A[Se]) || Zx(Se)
                  : null
              )
            : null,
          j.createElement(
            "div",
            {
              "data-content": "",
              className: F(
                C == null ? void 0 : C.content,
                (s = c == null ? void 0 : c.classNames) == null
                  ? void 0
                  : s.content
              ),
            },
            j.createElement(
              "div",
              {
                "data-title": "",
                className: F(
                  C == null ? void 0 : C.title,
                  (l = c == null ? void 0 : c.classNames) == null
                    ? void 0
                    : l.title
                ),
              },
              c.title
            ),
            c.description
              ? j.createElement(
                  "div",
                  {
                    "data-description": "",
                    className: F(
                      D,
                      Eg,
                      C == null ? void 0 : C.description,
                      (a = c == null ? void 0 : c.classNames) == null
                        ? void 0
                        : a.description
                    ),
                  },
                  c.description
                )
              : null
          ),
          j.isValidElement(c.cancel)
            ? c.cancel
            : c.cancel && Ai(c.cancel)
            ? j.createElement(
                "button",
                {
                  "data-button": !0,
                  "data-cancel": !0,
                  style: c.cancelButtonStyle || I,
                  onClick: (B) => {
                    var ne, ee;
                    Ai(c.cancel) &&
                      ir &&
                      ((ee = (ne = c.cancel).onClick) == null || ee.call(ne, B),
                      en());
                  },
                  className: F(
                    C == null ? void 0 : C.cancelButton,
                    (u = c == null ? void 0 : c.classNames) == null
                      ? void 0
                      : u.cancelButton
                  ),
                },
                c.cancel.label
              )
            : null,
          j.isValidElement(c.action)
            ? c.action
            : c.action && Ai(c.action)
            ? j.createElement(
                "button",
                {
                  "data-button": !0,
                  "data-action": !0,
                  style: c.actionButtonStyle || _,
                  onClick: (B) => {
                    var ne, ee;
                    Ai(c.action) &&
                      (B.defaultPrevented ||
                        ((ee = (ne = c.action).onClick) == null ||
                          ee.call(ne, B),
                        en()));
                  },
                  className: F(
                    C == null ? void 0 : C.actionButton,
                    (d = c == null ? void 0 : c.classNames) == null
                      ? void 0
                      : d.actionButton
                  ),
                },
                c.action.label
              )
            : null
        )
  );
};
function Md() {
  if (typeof window > "u" || typeof document > "u") return "ltr";
  let e = document.documentElement.getAttribute("dir");
  return e === "auto" || !e
    ? window.getComputedStyle(document.documentElement).direction
    : e;
}
var Ew = (e) => {
  let {
      invert: t,
      position: n = "bottom-right",
      hotkey: r = ["altKey", "KeyT"],
      expand: o,
      closeButton: i,
      className: s,
      offset: l,
      theme: a = "light",
      richColors: u,
      duration: d,
      style: f,
      visibleToasts: c = hw,
      toastOptions: v,
      dir: x = Md(),
      gap: g = yw,
      loadingIcon: S,
      icons: h,
      containerAriaLabel: p = "Notifications",
      pauseWhenPageIsHidden: m,
      cn: k = Sw,
    } = e,
    [E, b] = j.useState([]),
    P = j.useMemo(
      () =>
        Array.from(
          new Set(
            [n].concat(E.filter((L) => L.position).map((L) => L.position))
          )
        ),
      [E, n]
    ),
    [T, I] = j.useState([]),
    [_, $] = j.useState(!1),
    [D, H] = j.useState(!1),
    [O, Q] = j.useState(
      a !== "system"
        ? a
        : typeof window < "u" &&
          window.matchMedia &&
          window.matchMedia("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light"
    ),
    U = j.useRef(null),
    K = r.join("+").replace(/Key/g, "").replace(/Digit/g, ""),
    C = j.useRef(null),
    A = j.useRef(!1),
    z = j.useCallback(
      (L) => {
        var F;
        ((F = E.find((Y) => Y.id === L.id)) != null && F.delete) ||
          Qe.dismiss(L.id),
          b((Y) => Y.filter(({ id: le }) => le !== L.id));
      },
      [E]
    );
  return (
    j.useEffect(
      () =>
        Qe.subscribe((L) => {
          if (L.dismiss) {
            b((F) => F.map((Y) => (Y.id === L.id ? { ...Y, delete: !0 } : Y)));
            return;
          }
          setTimeout(() => {
            Nh.flushSync(() => {
              b((F) => {
                let Y = F.findIndex((le) => le.id === L.id);
                return Y !== -1
                  ? [...F.slice(0, Y), { ...F[Y], ...L }, ...F.slice(Y + 1)]
                  : [L, ...F];
              });
            });
          });
        }),
      []
    ),
    j.useEffect(() => {
      if (a !== "system") {
        Q(a);
        return;
      }
      a === "system" &&
        (window.matchMedia &&
        window.matchMedia("(prefers-color-scheme: dark)").matches
          ? Q("dark")
          : Q("light")),
        typeof window < "u" &&
          window
            .matchMedia("(prefers-color-scheme: dark)")
            .addEventListener("change", ({ matches: L }) => {
              Q(L ? "dark" : "light");
            });
    }, [a]),
    j.useEffect(() => {
      E.length <= 1 && $(!1);
    }, [E]),
    j.useEffect(() => {
      let L = (F) => {
        var Y, le;
        r.every((Ve) => F[Ve] || F.code === Ve) &&
          ($(!0), (Y = U.current) == null || Y.focus()),
          F.code === "Escape" &&
            (document.activeElement === U.current ||
              ((le = U.current) != null &&
                le.contains(document.activeElement))) &&
            $(!1);
      };
      return (
        document.addEventListener("keydown", L),
        () => document.removeEventListener("keydown", L)
      );
    }, [r]),
    j.useEffect(() => {
      if (U.current)
        return () => {
          C.current &&
            (C.current.focus({ preventScroll: !0 }),
            (C.current = null),
            (A.current = !1));
        };
    }, [U.current]),
    E.length
      ? j.createElement(
          "section",
          { "aria-label": `${p} ${K}`, tabIndex: -1 },
          P.map((L, F) => {
            var Y;
            let [le, Ve] = L.split("-");
            return j.createElement(
              "ol",
              {
                key: L,
                dir: x === "auto" ? Md() : x,
                tabIndex: -1,
                ref: U,
                className: s,
                "data-sonner-toaster": !0,
                "data-theme": O,
                "data-y-position": le,
                "data-x-position": Ve,
                style: {
                  "--front-toast-height": `${
                    ((Y = T[0]) == null ? void 0 : Y.height) || 0
                  }px`,
                  "--offset": typeof l == "number" ? `${l}px` : l || mw,
                  "--width": `${vw}px`,
                  "--gap": `${g}px`,
                  ...f,
                },
                onBlur: (J) => {
                  A.current &&
                    !J.currentTarget.contains(J.relatedTarget) &&
                    ((A.current = !1),
                    C.current &&
                      (C.current.focus({ preventScroll: !0 }),
                      (C.current = null)));
                },
                onFocus: (J) => {
                  (J.target instanceof HTMLElement &&
                    J.target.dataset.dismissible === "false") ||
                    A.current ||
                    ((A.current = !0), (C.current = J.relatedTarget));
                },
                onMouseEnter: () => $(!0),
                onMouseMove: () => $(!0),
                onMouseLeave: () => {
                  D || $(!1);
                },
                onPointerDown: (J) => {
                  (J.target instanceof HTMLElement &&
                    J.target.dataset.dismissible === "false") ||
                    H(!0);
                },
                onPointerUp: () => H(!1),
              },
              E.filter((J) => (!J.position && F === 0) || J.position === L).map(
                (J, at) => {
                  var Xt, qt;
                  return j.createElement(kw, {
                    key: J.id,
                    icons: h,
                    index: at,
                    toast: J,
                    defaultRichColors: u,
                    duration:
                      (Xt = v == null ? void 0 : v.duration) != null ? Xt : d,
                    className: v == null ? void 0 : v.className,
                    descriptionClassName:
                      v == null ? void 0 : v.descriptionClassName,
                    invert: t,
                    visibleToasts: c,
                    closeButton:
                      (qt = v == null ? void 0 : v.closeButton) != null
                        ? qt
                        : i,
                    interacting: D,
                    position: L,
                    style: v == null ? void 0 : v.style,
                    unstyled: v == null ? void 0 : v.unstyled,
                    classNames: v == null ? void 0 : v.classNames,
                    cancelButtonStyle: v == null ? void 0 : v.cancelButtonStyle,
                    actionButtonStyle: v == null ? void 0 : v.actionButtonStyle,
                    removeToast: z,
                    toasts: E.filter((Jt) => Jt.position == J.position),
                    heights: T.filter((Jt) => Jt.position == J.position),
                    setHeights: I,
                    expandByDefault: o,
                    gap: g,
                    loadingIcon: S,
                    expanded: _,
                    pauseWhenPageIsHidden: m,
                    cn: k,
                  });
                }
              )
            );
          })
        )
      : null
  );
};
const Cw = ({ ...e }) => {
    const { theme: t = "system" } = Jx();
    return w.jsx(Ew, {
      theme: t,
      className: "toaster group",
      toastOptions: {
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton:
            "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton:
            "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground",
        },
      },
      ...e,
    });
  },
  bw = ["top", "right", "bottom", "left"],
  Rn = Math.min,
  Ge = Math.max,
  ws = Math.round,
  ji = Math.floor,
  An = (e) => ({ x: e, y: e }),
  Pw = { left: "right", right: "left", bottom: "top", top: "bottom" },
  Nw = { start: "end", end: "start" };
function Fa(e, t, n) {
  return Ge(e, Rn(t, n));
}
function Kt(e, t) {
  return typeof e == "function" ? e(t) : e;
}
function Gt(e) {
  return e.split("-")[0];
}
function qr(e) {
  return e.split("-")[1];
}
function Yu(e) {
  return e === "x" ? "y" : "x";
}
function Xu(e) {
  return e === "y" ? "height" : "width";
}
function jn(e) {
  return ["top", "bottom"].includes(Gt(e)) ? "y" : "x";
}
function qu(e) {
  return Yu(jn(e));
}
function Tw(e, t, n) {
  n === void 0 && (n = !1);
  const r = qr(e),
    o = qu(e),
    i = Xu(o);
  let s =
    o === "x"
      ? r === (n ? "end" : "start")
        ? "right"
        : "left"
      : r === "start"
      ? "bottom"
      : "top";
  return t.reference[i] > t.floating[i] && (s = Ss(s)), [s, Ss(s)];
}
function Rw(e) {
  const t = Ss(e);
  return [$a(e), t, $a(t)];
}
function $a(e) {
  return e.replace(/start|end/g, (t) => Nw[t]);
}
function Aw(e, t, n) {
  const r = ["left", "right"],
    o = ["right", "left"],
    i = ["top", "bottom"],
    s = ["bottom", "top"];
  switch (e) {
    case "top":
    case "bottom":
      return n ? (t ? o : r) : t ? r : o;
    case "left":
    case "right":
      return t ? i : s;
    default:
      return [];
  }
}
function jw(e, t, n, r) {
  const o = qr(e);
  let i = Aw(Gt(e), n === "start", r);
  return (
    o && ((i = i.map((s) => s + "-" + o)), t && (i = i.concat(i.map($a)))), i
  );
}
function Ss(e) {
  return e.replace(/left|right|bottom|top/g, (t) => Pw[t]);
}
function _w(e) {
  return { top: 0, right: 0, bottom: 0, left: 0, ...e };
}
function vm(e) {
  return typeof e != "number"
    ? _w(e)
    : { top: e, right: e, bottom: e, left: e };
}
function ks(e) {
  const { x: t, y: n, width: r, height: o } = e;
  return {
    width: r,
    height: o,
    top: n,
    left: t,
    right: t + r,
    bottom: n + o,
    x: t,
    y: n,
  };
}
function Ld(e, t, n) {
  let { reference: r, floating: o } = e;
  const i = jn(t),
    s = qu(t),
    l = Xu(s),
    a = Gt(t),
    u = i === "y",
    d = r.x + r.width / 2 - o.width / 2,
    f = r.y + r.height / 2 - o.height / 2,
    c = r[l] / 2 - o[l] / 2;
  let v;
  switch (a) {
    case "top":
      v = { x: d, y: r.y - o.height };
      break;
    case "bottom":
      v = { x: d, y: r.y + r.height };
      break;
    case "right":
      v = { x: r.x + r.width, y: f };
      break;
    case "left":
      v = { x: r.x - o.width, y: f };
      break;
    default:
      v = { x: r.x, y: r.y };
  }
  switch (qr(t)) {
    case "start":
      v[s] -= c * (n && u ? -1 : 1);
      break;
    case "end":
      v[s] += c * (n && u ? -1 : 1);
      break;
  }
  return v;
}
const Ow = async (e, t, n) => {
  const {
      placement: r = "bottom",
      strategy: o = "absolute",
      middleware: i = [],
      platform: s,
    } = n,
    l = i.filter(Boolean),
    a = await (s.isRTL == null ? void 0 : s.isRTL(t));
  let u = await s.getElementRects({ reference: e, floating: t, strategy: o }),
    { x: d, y: f } = Ld(u, r, a),
    c = r,
    v = {},
    x = 0;
  for (let g = 0; g < l.length; g++) {
    const { name: S, fn: h } = l[g],
      {
        x: p,
        y: m,
        data: k,
        reset: E,
      } = await h({
        x: d,
        y: f,
        initialPlacement: r,
        placement: c,
        strategy: o,
        middlewareData: v,
        rects: u,
        platform: s,
        elements: { reference: e, floating: t },
      });
    (d = p ?? d),
      (f = m ?? f),
      (v = { ...v, [S]: { ...v[S], ...k } }),
      E &&
        x <= 50 &&
        (x++,
        typeof E == "object" &&
          (E.placement && (c = E.placement),
          E.rects &&
            (u =
              E.rects === !0
                ? await s.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: o,
                  })
                : E.rects),
          ({ x: d, y: f } = Ld(u, c, a))),
        (g = -1));
  }
  return { x: d, y: f, placement: c, strategy: o, middlewareData: v };
};
async function Wo(e, t) {
  var n;
  t === void 0 && (t = {});
  const { x: r, y: o, platform: i, rects: s, elements: l, strategy: a } = e,
    {
      boundary: u = "clippingAncestors",
      rootBoundary: d = "viewport",
      elementContext: f = "floating",
      altBoundary: c = !1,
      padding: v = 0,
    } = Kt(t, e),
    x = vm(v),
    S = l[c ? (f === "floating" ? "reference" : "floating") : f],
    h = ks(
      await i.getClippingRect({
        element:
          (n = await (i.isElement == null ? void 0 : i.isElement(S))) == null ||
          n
            ? S
            : S.contextElement ||
              (await (i.getDocumentElement == null
                ? void 0
                : i.getDocumentElement(l.floating))),
        boundary: u,
        rootBoundary: d,
        strategy: a,
      })
    ),
    p =
      f === "floating"
        ? { x: r, y: o, width: s.floating.width, height: s.floating.height }
        : s.reference,
    m = await (i.getOffsetParent == null
      ? void 0
      : i.getOffsetParent(l.floating)),
    k = (await (i.isElement == null ? void 0 : i.isElement(m)))
      ? (await (i.getScale == null ? void 0 : i.getScale(m))) || { x: 1, y: 1 }
      : { x: 1, y: 1 },
    E = ks(
      i.convertOffsetParentRelativeRectToViewportRelativeRect
        ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({
            elements: l,
            rect: p,
            offsetParent: m,
            strategy: a,
          })
        : p
    );
  return {
    top: (h.top - E.top + x.top) / k.y,
    bottom: (E.bottom - h.bottom + x.bottom) / k.y,
    left: (h.left - E.left + x.left) / k.x,
    right: (E.right - h.right + x.right) / k.x,
  };
}
const Mw = (e) => ({
    name: "arrow",
    options: e,
    async fn(t) {
      const {
          x: n,
          y: r,
          placement: o,
          rects: i,
          platform: s,
          elements: l,
          middlewareData: a,
        } = t,
        { element: u, padding: d = 0 } = Kt(e, t) || {};
      if (u == null) return {};
      const f = vm(d),
        c = { x: n, y: r },
        v = qu(o),
        x = Xu(v),
        g = await s.getDimensions(u),
        S = v === "y",
        h = S ? "top" : "left",
        p = S ? "bottom" : "right",
        m = S ? "clientHeight" : "clientWidth",
        k = i.reference[x] + i.reference[v] - c[v] - i.floating[x],
        E = c[v] - i.reference[v],
        b = await (s.getOffsetParent == null ? void 0 : s.getOffsetParent(u));
      let P = b ? b[m] : 0;
      (!P || !(await (s.isElement == null ? void 0 : s.isElement(b)))) &&
        (P = l.floating[m] || i.floating[x]);
      const T = k / 2 - E / 2,
        I = P / 2 - g[x] / 2 - 1,
        _ = Rn(f[h], I),
        $ = Rn(f[p], I),
        D = _,
        H = P - g[x] - $,
        O = P / 2 - g[x] / 2 + T,
        Q = Fa(D, O, H),
        U =
          !a.arrow &&
          qr(o) != null &&
          O !== Q &&
          i.reference[x] / 2 - (O < D ? _ : $) - g[x] / 2 < 0,
        K = U ? (O < D ? O - D : O - H) : 0;
      return {
        [v]: c[v] + K,
        data: {
          [v]: Q,
          centerOffset: O - Q - K,
          ...(U && { alignmentOffset: K }),
        },
        reset: U,
      };
    },
  }),
  Lw = function (e) {
    return (
      e === void 0 && (e = {}),
      {
        name: "flip",
        options: e,
        async fn(t) {
          var n, r;
          const {
              placement: o,
              middlewareData: i,
              rects: s,
              initialPlacement: l,
              platform: a,
              elements: u,
            } = t,
            {
              mainAxis: d = !0,
              crossAxis: f = !0,
              fallbackPlacements: c,
              fallbackStrategy: v = "bestFit",
              fallbackAxisSideDirection: x = "none",
              flipAlignment: g = !0,
              ...S
            } = Kt(e, t);
          if ((n = i.arrow) != null && n.alignmentOffset) return {};
          const h = Gt(o),
            p = jn(l),
            m = Gt(l) === l,
            k = await (a.isRTL == null ? void 0 : a.isRTL(u.floating)),
            E = c || (m || !g ? [Ss(l)] : Rw(l)),
            b = x !== "none";
          !c && b && E.push(...jw(l, g, x, k));
          const P = [l, ...E],
            T = await Wo(t, S),
            I = [];
          let _ = ((r = i.flip) == null ? void 0 : r.overflows) || [];
          if ((d && I.push(T[h]), f)) {
            const O = Tw(o, s, k);
            I.push(T[O[0]], T[O[1]]);
          }
          if (
            ((_ = [..._, { placement: o, overflows: I }]),
            !I.every((O) => O <= 0))
          ) {
            var $, D;
            const O = ((($ = i.flip) == null ? void 0 : $.index) || 0) + 1,
              Q = P[O];
            if (Q)
              return {
                data: { index: O, overflows: _ },
                reset: { placement: Q },
              };
            let U =
              (D = _.filter((K) => K.overflows[0] <= 0).sort(
                (K, C) => K.overflows[1] - C.overflows[1]
              )[0]) == null
                ? void 0
                : D.placement;
            if (!U)
              switch (v) {
                case "bestFit": {
                  var H;
                  const K =
                    (H = _.filter((C) => {
                      if (b) {
                        const A = jn(C.placement);
                        return A === p || A === "y";
                      }
                      return !0;
                    })
                      .map((C) => [
                        C.placement,
                        C.overflows
                          .filter((A) => A > 0)
                          .reduce((A, z) => A + z, 0),
                      ])
                      .sort((C, A) => C[1] - A[1])[0]) == null
                      ? void 0
                      : H[0];
                  K && (U = K);
                  break;
                }
                case "initialPlacement":
                  U = l;
                  break;
              }
            if (o !== U) return { reset: { placement: U } };
          }
          return {};
        },
      }
    );
  };
function Id(e, t) {
  return {
    top: e.top - t.height,
    right: e.right - t.width,
    bottom: e.bottom - t.height,
    left: e.left - t.width,
  };
}
function Dd(e) {
  return bw.some((t) => e[t] >= 0);
}
const Iw = function (e) {
  return (
    e === void 0 && (e = {}),
    {
      name: "hide",
      options: e,
      async fn(t) {
        const { rects: n } = t,
          { strategy: r = "referenceHidden", ...o } = Kt(e, t);
        switch (r) {
          case "referenceHidden": {
            const i = await Wo(t, { ...o, elementContext: "reference" }),
              s = Id(i, n.reference);
            return {
              data: { referenceHiddenOffsets: s, referenceHidden: Dd(s) },
            };
          }
          case "escaped": {
            const i = await Wo(t, { ...o, altBoundary: !0 }),
              s = Id(i, n.floating);
            return { data: { escapedOffsets: s, escaped: Dd(s) } };
          }
          default:
            return {};
        }
      },
    }
  );
};
async function Dw(e, t) {
  const { placement: n, platform: r, elements: o } = e,
    i = await (r.isRTL == null ? void 0 : r.isRTL(o.floating)),
    s = Gt(n),
    l = qr(n),
    a = jn(n) === "y",
    u = ["left", "top"].includes(s) ? -1 : 1,
    d = i && a ? -1 : 1,
    f = Kt(t, e);
  let {
    mainAxis: c,
    crossAxis: v,
    alignmentAxis: x,
  } = typeof f == "number"
    ? { mainAxis: f, crossAxis: 0, alignmentAxis: null }
    : {
        mainAxis: f.mainAxis || 0,
        crossAxis: f.crossAxis || 0,
        alignmentAxis: f.alignmentAxis,
      };
  return (
    l && typeof x == "number" && (v = l === "end" ? x * -1 : x),
    a ? { x: v * d, y: c * u } : { x: c * u, y: v * d }
  );
}
const zw = function (e) {
    return (
      e === void 0 && (e = 0),
      {
        name: "offset",
        options: e,
        async fn(t) {
          var n, r;
          const { x: o, y: i, placement: s, middlewareData: l } = t,
            a = await Dw(t, e);
          return s === ((n = l.offset) == null ? void 0 : n.placement) &&
            (r = l.arrow) != null &&
            r.alignmentOffset
            ? {}
            : { x: o + a.x, y: i + a.y, data: { ...a, placement: s } };
        },
      }
    );
  },
  Fw = function (e) {
    return (
      e === void 0 && (e = {}),
      {
        name: "shift",
        options: e,
        async fn(t) {
          const { x: n, y: r, placement: o } = t,
            {
              mainAxis: i = !0,
              crossAxis: s = !1,
              limiter: l = {
                fn: (S) => {
                  let { x: h, y: p } = S;
                  return { x: h, y: p };
                },
              },
              ...a
            } = Kt(e, t),
            u = { x: n, y: r },
            d = await Wo(t, a),
            f = jn(Gt(o)),
            c = Yu(f);
          let v = u[c],
            x = u[f];
          if (i) {
            const S = c === "y" ? "top" : "left",
              h = c === "y" ? "bottom" : "right",
              p = v + d[S],
              m = v - d[h];
            v = Fa(p, v, m);
          }
          if (s) {
            const S = f === "y" ? "top" : "left",
              h = f === "y" ? "bottom" : "right",
              p = x + d[S],
              m = x - d[h];
            x = Fa(p, x, m);
          }
          const g = l.fn({ ...t, [c]: v, [f]: x });
          return {
            ...g,
            data: { x: g.x - n, y: g.y - r, enabled: { [c]: i, [f]: s } },
          };
        },
      }
    );
  },
  $w = function (e) {
    return (
      e === void 0 && (e = {}),
      {
        options: e,
        fn(t) {
          const { x: n, y: r, placement: o, rects: i, middlewareData: s } = t,
            { offset: l = 0, mainAxis: a = !0, crossAxis: u = !0 } = Kt(e, t),
            d = { x: n, y: r },
            f = jn(o),
            c = Yu(f);
          let v = d[c],
            x = d[f];
          const g = Kt(l, t),
            S =
              typeof g == "number"
                ? { mainAxis: g, crossAxis: 0 }
                : { mainAxis: 0, crossAxis: 0, ...g };
          if (a) {
            const m = c === "y" ? "height" : "width",
              k = i.reference[c] - i.floating[m] + S.mainAxis,
              E = i.reference[c] + i.reference[m] - S.mainAxis;
            v < k ? (v = k) : v > E && (v = E);
          }
          if (u) {
            var h, p;
            const m = c === "y" ? "width" : "height",
              k = ["top", "left"].includes(Gt(o)),
              E =
                i.reference[f] -
                i.floating[m] +
                ((k && ((h = s.offset) == null ? void 0 : h[f])) || 0) +
                (k ? 0 : S.crossAxis),
              b =
                i.reference[f] +
                i.reference[m] +
                (k ? 0 : ((p = s.offset) == null ? void 0 : p[f]) || 0) -
                (k ? S.crossAxis : 0);
            x < E ? (x = E) : x > b && (x = b);
          }
          return { [c]: v, [f]: x };
        },
      }
    );
  },
  Uw = function (e) {
    return (
      e === void 0 && (e = {}),
      {
        name: "size",
        options: e,
        async fn(t) {
          var n, r;
          const { placement: o, rects: i, platform: s, elements: l } = t,
            { apply: a = () => {}, ...u } = Kt(e, t),
            d = await Wo(t, u),
            f = Gt(o),
            c = qr(o),
            v = jn(o) === "y",
            { width: x, height: g } = i.floating;
          let S, h;
          f === "top" || f === "bottom"
            ? ((S = f),
              (h =
                c ===
                ((await (s.isRTL == null ? void 0 : s.isRTL(l.floating)))
                  ? "start"
                  : "end")
                  ? "left"
                  : "right"))
            : ((h = f), (S = c === "end" ? "top" : "bottom"));
          const p = g - d.top - d.bottom,
            m = x - d.left - d.right,
            k = Rn(g - d[S], p),
            E = Rn(x - d[h], m),
            b = !t.middlewareData.shift;
          let P = k,
            T = E;
          if (
            ((n = t.middlewareData.shift) != null && n.enabled.x && (T = m),
            (r = t.middlewareData.shift) != null && r.enabled.y && (P = p),
            b && !c)
          ) {
            const _ = Ge(d.left, 0),
              $ = Ge(d.right, 0),
              D = Ge(d.top, 0),
              H = Ge(d.bottom, 0);
            v
              ? (T = x - 2 * (_ !== 0 || $ !== 0 ? _ + $ : Ge(d.left, d.right)))
              : (P =
                  g - 2 * (D !== 0 || H !== 0 ? D + H : Ge(d.top, d.bottom)));
          }
          await a({ ...t, availableWidth: T, availableHeight: P });
          const I = await s.getDimensions(l.floating);
          return x !== I.width || g !== I.height
            ? { reset: { rects: !0 } }
            : {};
        },
      }
    );
  };
function Qs() {
  return typeof window < "u";
}
function Jr(e) {
  return ym(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function qe(e) {
  var t;
  return (
    (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) ||
    window
  );
}
function Mt(e) {
  var t;
  return (t = (ym(e) ? e.ownerDocument : e.document) || window.document) == null
    ? void 0
    : t.documentElement;
}
function ym(e) {
  return Qs() ? e instanceof Node || e instanceof qe(e).Node : !1;
}
function wt(e) {
  return Qs() ? e instanceof Element || e instanceof qe(e).Element : !1;
}
function _t(e) {
  return Qs() ? e instanceof HTMLElement || e instanceof qe(e).HTMLElement : !1;
}
function zd(e) {
  return !Qs() || typeof ShadowRoot > "u"
    ? !1
    : e instanceof ShadowRoot || e instanceof qe(e).ShadowRoot;
}
function ri(e) {
  const { overflow: t, overflowX: n, overflowY: r, display: o } = St(e);
  return (
    /auto|scroll|overlay|hidden|clip/.test(t + r + n) &&
    !["inline", "contents"].includes(o)
  );
}
function Bw(e) {
  return ["table", "td", "th"].includes(Jr(e));
}
function Ks(e) {
  return [":popover-open", ":modal"].some((t) => {
    try {
      return e.matches(t);
    } catch {
      return !1;
    }
  });
}
function Ju(e) {
  const t = Zu(),
    n = wt(e) ? St(e) : e;
  return (
    n.transform !== "none" ||
    n.perspective !== "none" ||
    (n.containerType ? n.containerType !== "normal" : !1) ||
    (!t && (n.backdropFilter ? n.backdropFilter !== "none" : !1)) ||
    (!t && (n.filter ? n.filter !== "none" : !1)) ||
    ["transform", "perspective", "filter"].some((r) =>
      (n.willChange || "").includes(r)
    ) ||
    ["paint", "layout", "strict", "content"].some((r) =>
      (n.contain || "").includes(r)
    )
  );
}
function Ww(e) {
  let t = _n(e);
  for (; _t(t) && !Hr(t); ) {
    if (Ju(t)) return t;
    if (Ks(t)) return null;
    t = _n(t);
  }
  return null;
}
function Zu() {
  return typeof CSS > "u" || !CSS.supports
    ? !1
    : CSS.supports("-webkit-backdrop-filter", "none");
}
function Hr(e) {
  return ["html", "body", "#document"].includes(Jr(e));
}
function St(e) {
  return qe(e).getComputedStyle(e);
}
function Gs(e) {
  return wt(e)
    ? { scrollLeft: e.scrollLeft, scrollTop: e.scrollTop }
    : { scrollLeft: e.scrollX, scrollTop: e.scrollY };
}
function _n(e) {
  if (Jr(e) === "html") return e;
  const t = e.assignedSlot || e.parentNode || (zd(e) && e.host) || Mt(e);
  return zd(t) ? t.host : t;
}
function xm(e) {
  const t = _n(e);
  return Hr(t)
    ? e.ownerDocument
      ? e.ownerDocument.body
      : e.body
    : _t(t) && ri(t)
    ? t
    : xm(t);
}
function Vo(e, t, n) {
  var r;
  t === void 0 && (t = []), n === void 0 && (n = !0);
  const o = xm(e),
    i = o === ((r = e.ownerDocument) == null ? void 0 : r.body),
    s = qe(o);
  if (i) {
    const l = Ua(s);
    return t.concat(
      s,
      s.visualViewport || [],
      ri(o) ? o : [],
      l && n ? Vo(l) : []
    );
  }
  return t.concat(o, Vo(o, [], n));
}
function Ua(e) {
  return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
function wm(e) {
  const t = St(e);
  let n = parseFloat(t.width) || 0,
    r = parseFloat(t.height) || 0;
  const o = _t(e),
    i = o ? e.offsetWidth : n,
    s = o ? e.offsetHeight : r,
    l = ws(n) !== i || ws(r) !== s;
  return l && ((n = i), (r = s)), { width: n, height: r, $: l };
}
function ec(e) {
  return wt(e) ? e : e.contextElement;
}
function Tr(e) {
  const t = ec(e);
  if (!_t(t)) return An(1);
  const n = t.getBoundingClientRect(),
    { width: r, height: o, $: i } = wm(t);
  let s = (i ? ws(n.width) : n.width) / r,
    l = (i ? ws(n.height) : n.height) / o;
  return (
    (!s || !Number.isFinite(s)) && (s = 1),
    (!l || !Number.isFinite(l)) && (l = 1),
    { x: s, y: l }
  );
}
const Vw = An(0);
function Sm(e) {
  const t = qe(e);
  return !Zu() || !t.visualViewport
    ? Vw
    : { x: t.visualViewport.offsetLeft, y: t.visualViewport.offsetTop };
}
function Hw(e, t, n) {
  return t === void 0 && (t = !1), !n || (t && n !== qe(e)) ? !1 : t;
}
function Zn(e, t, n, r) {
  t === void 0 && (t = !1), n === void 0 && (n = !1);
  const o = e.getBoundingClientRect(),
    i = ec(e);
  let s = An(1);
  t && (r ? wt(r) && (s = Tr(r)) : (s = Tr(e)));
  const l = Hw(i, n, r) ? Sm(i) : An(0);
  let a = (o.left + l.x) / s.x,
    u = (o.top + l.y) / s.y,
    d = o.width / s.x,
    f = o.height / s.y;
  if (i) {
    const c = qe(i),
      v = r && wt(r) ? qe(r) : r;
    let x = c,
      g = Ua(x);
    for (; g && r && v !== x; ) {
      const S = Tr(g),
        h = g.getBoundingClientRect(),
        p = St(g),
        m = h.left + (g.clientLeft + parseFloat(p.paddingLeft)) * S.x,
        k = h.top + (g.clientTop + parseFloat(p.paddingTop)) * S.y;
      (a *= S.x),
        (u *= S.y),
        (d *= S.x),
        (f *= S.y),
        (a += m),
        (u += k),
        (x = qe(g)),
        (g = Ua(x));
    }
  }
  return ks({ width: d, height: f, x: a, y: u });
}
function Qw(e) {
  let { elements: t, rect: n, offsetParent: r, strategy: o } = e;
  const i = o === "fixed",
    s = Mt(r),
    l = t ? Ks(t.floating) : !1;
  if (r === s || (l && i)) return n;
  let a = { scrollLeft: 0, scrollTop: 0 },
    u = An(1);
  const d = An(0),
    f = _t(r);
  if (
    (f || (!f && !i)) &&
    ((Jr(r) !== "body" || ri(s)) && (a = Gs(r)), _t(r))
  ) {
    const c = Zn(r);
    (u = Tr(r)), (d.x = c.x + r.clientLeft), (d.y = c.y + r.clientTop);
  }
  return {
    width: n.width * u.x,
    height: n.height * u.y,
    x: n.x * u.x - a.scrollLeft * u.x + d.x,
    y: n.y * u.y - a.scrollTop * u.y + d.y,
  };
}
function Kw(e) {
  return Array.from(e.getClientRects());
}
function Ba(e, t) {
  const n = Gs(e).scrollLeft;
  return t ? t.left + n : Zn(Mt(e)).left + n;
}
function Gw(e) {
  const t = Mt(e),
    n = Gs(e),
    r = e.ownerDocument.body,
    o = Ge(t.scrollWidth, t.clientWidth, r.scrollWidth, r.clientWidth),
    i = Ge(t.scrollHeight, t.clientHeight, r.scrollHeight, r.clientHeight);
  let s = -n.scrollLeft + Ba(e);
  const l = -n.scrollTop;
  return (
    St(r).direction === "rtl" && (s += Ge(t.clientWidth, r.clientWidth) - o),
    { width: o, height: i, x: s, y: l }
  );
}
function Yw(e, t) {
  const n = qe(e),
    r = Mt(e),
    o = n.visualViewport;
  let i = r.clientWidth,
    s = r.clientHeight,
    l = 0,
    a = 0;
  if (o) {
    (i = o.width), (s = o.height);
    const u = Zu();
    (!u || (u && t === "fixed")) && ((l = o.offsetLeft), (a = o.offsetTop));
  }
  return { width: i, height: s, x: l, y: a };
}
function Xw(e, t) {
  const n = Zn(e, !0, t === "fixed"),
    r = n.top + e.clientTop,
    o = n.left + e.clientLeft,
    i = _t(e) ? Tr(e) : An(1),
    s = e.clientWidth * i.x,
    l = e.clientHeight * i.y,
    a = o * i.x,
    u = r * i.y;
  return { width: s, height: l, x: a, y: u };
}
function Fd(e, t, n) {
  let r;
  if (t === "viewport") r = Yw(e, n);
  else if (t === "document") r = Gw(Mt(e));
  else if (wt(t)) r = Xw(t, n);
  else {
    const o = Sm(e);
    r = { ...t, x: t.x - o.x, y: t.y - o.y };
  }
  return ks(r);
}
function km(e, t) {
  const n = _n(e);
  return n === t || !wt(n) || Hr(n)
    ? !1
    : St(n).position === "fixed" || km(n, t);
}
function qw(e, t) {
  const n = t.get(e);
  if (n) return n;
  let r = Vo(e, [], !1).filter((l) => wt(l) && Jr(l) !== "body"),
    o = null;
  const i = St(e).position === "fixed";
  let s = i ? _n(e) : e;
  for (; wt(s) && !Hr(s); ) {
    const l = St(s),
      a = Ju(s);
    !a && l.position === "fixed" && (o = null),
      (
        i
          ? !a && !o
          : (!a &&
              l.position === "static" &&
              !!o &&
              ["absolute", "fixed"].includes(o.position)) ||
            (ri(s) && !a && km(e, s))
      )
        ? (r = r.filter((d) => d !== s))
        : (o = l),
      (s = _n(s));
  }
  return t.set(e, r), r;
}
function Jw(e) {
  let { element: t, boundary: n, rootBoundary: r, strategy: o } = e;
  const s = [
      ...(n === "clippingAncestors"
        ? Ks(t)
          ? []
          : qw(t, this._c)
        : [].concat(n)),
      r,
    ],
    l = s[0],
    a = s.reduce((u, d) => {
      const f = Fd(t, d, o);
      return (
        (u.top = Ge(f.top, u.top)),
        (u.right = Rn(f.right, u.right)),
        (u.bottom = Rn(f.bottom, u.bottom)),
        (u.left = Ge(f.left, u.left)),
        u
      );
    }, Fd(t, l, o));
  return {
    width: a.right - a.left,
    height: a.bottom - a.top,
    x: a.left,
    y: a.top,
  };
}
function Zw(e) {
  const { width: t, height: n } = wm(e);
  return { width: t, height: n };
}
function e1(e, t, n) {
  const r = _t(t),
    o = Mt(t),
    i = n === "fixed",
    s = Zn(e, !0, i, t);
  let l = { scrollLeft: 0, scrollTop: 0 };
  const a = An(0);
  if (r || (!r && !i))
    if (((Jr(t) !== "body" || ri(o)) && (l = Gs(t)), r)) {
      const v = Zn(t, !0, i, t);
      (a.x = v.x + t.clientLeft), (a.y = v.y + t.clientTop);
    } else o && (a.x = Ba(o));
  let u = 0,
    d = 0;
  if (o && !r && !i) {
    const v = o.getBoundingClientRect();
    (d = v.top + l.scrollTop), (u = v.left + l.scrollLeft - Ba(o, v));
  }
  const f = s.left + l.scrollLeft - a.x - u,
    c = s.top + l.scrollTop - a.y - d;
  return { x: f, y: c, width: s.width, height: s.height };
}
function Il(e) {
  return St(e).position === "static";
}
function $d(e, t) {
  if (!_t(e) || St(e).position === "fixed") return null;
  if (t) return t(e);
  let n = e.offsetParent;
  return Mt(e) === n && (n = n.ownerDocument.body), n;
}
function Em(e, t) {
  const n = qe(e);
  if (Ks(e)) return n;
  if (!_t(e)) {
    let o = _n(e);
    for (; o && !Hr(o); ) {
      if (wt(o) && !Il(o)) return o;
      o = _n(o);
    }
    return n;
  }
  let r = $d(e, t);
  for (; r && Bw(r) && Il(r); ) r = $d(r, t);
  return r && Hr(r) && Il(r) && !Ju(r) ? n : r || Ww(e) || n;
}
const t1 = async function (e) {
  const t = this.getOffsetParent || Em,
    n = this.getDimensions,
    r = await n(e.floating);
  return {
    reference: e1(e.reference, await t(e.floating), e.strategy),
    floating: { x: 0, y: 0, width: r.width, height: r.height },
  };
};
function n1(e) {
  return St(e).direction === "rtl";
}
const r1 = {
  convertOffsetParentRelativeRectToViewportRelativeRect: Qw,
  getDocumentElement: Mt,
  getClippingRect: Jw,
  getOffsetParent: Em,
  getElementRects: t1,
  getClientRects: Kw,
  getDimensions: Zw,
  getScale: Tr,
  isElement: wt,
  isRTL: n1,
};
function o1(e, t) {
  let n = null,
    r;
  const o = Mt(e);
  function i() {
    var l;
    clearTimeout(r), (l = n) == null || l.disconnect(), (n = null);
  }
  function s(l, a) {
    l === void 0 && (l = !1), a === void 0 && (a = 1), i();
    const { left: u, top: d, width: f, height: c } = e.getBoundingClientRect();
    if ((l || t(), !f || !c)) return;
    const v = ji(d),
      x = ji(o.clientWidth - (u + f)),
      g = ji(o.clientHeight - (d + c)),
      S = ji(u),
      p = {
        rootMargin: -v + "px " + -x + "px " + -g + "px " + -S + "px",
        threshold: Ge(0, Rn(1, a)) || 1,
      };
    let m = !0;
    function k(E) {
      const b = E[0].intersectionRatio;
      if (b !== a) {
        if (!m) return s();
        b
          ? s(!1, b)
          : (r = setTimeout(() => {
              s(!1, 1e-7);
            }, 1e3));
      }
      m = !1;
    }
    try {
      n = new IntersectionObserver(k, { ...p, root: o.ownerDocument });
    } catch {
      n = new IntersectionObserver(k, p);
    }
    n.observe(e);
  }
  return s(!0), i;
}
function i1(e, t, n, r) {
  r === void 0 && (r = {});
  const {
      ancestorScroll: o = !0,
      ancestorResize: i = !0,
      elementResize: s = typeof ResizeObserver == "function",
      layoutShift: l = typeof IntersectionObserver == "function",
      animationFrame: a = !1,
    } = r,
    u = ec(e),
    d = o || i ? [...(u ? Vo(u) : []), ...Vo(t)] : [];
  d.forEach((h) => {
    o && h.addEventListener("scroll", n, { passive: !0 }),
      i && h.addEventListener("resize", n);
  });
  const f = u && l ? o1(u, n) : null;
  let c = -1,
    v = null;
  s &&
    ((v = new ResizeObserver((h) => {
      let [p] = h;
      p &&
        p.target === u &&
        v &&
        (v.unobserve(t),
        cancelAnimationFrame(c),
        (c = requestAnimationFrame(() => {
          var m;
          (m = v) == null || m.observe(t);
        }))),
        n();
    })),
    u && !a && v.observe(u),
    v.observe(t));
  let x,
    g = a ? Zn(e) : null;
  a && S();
  function S() {
    const h = Zn(e);
    g &&
      (h.x !== g.x ||
        h.y !== g.y ||
        h.width !== g.width ||
        h.height !== g.height) &&
      n(),
      (g = h),
      (x = requestAnimationFrame(S));
  }
  return (
    n(),
    () => {
      var h;
      d.forEach((p) => {
        o && p.removeEventListener("scroll", n),
          i && p.removeEventListener("resize", n);
      }),
        f == null || f(),
        (h = v) == null || h.disconnect(),
        (v = null),
        a && cancelAnimationFrame(x);
    }
  );
}
const s1 = zw,
  l1 = Fw,
  a1 = Lw,
  u1 = Uw,
  c1 = Iw,
  Ud = Mw,
  d1 = $w,
  f1 = (e, t, n) => {
    const r = new Map(),
      o = { platform: r1, ...n },
      i = { ...o.platform, _c: r };
    return Ow(e, t, { ...o, platform: i });
  };
var Ki = typeof document < "u" ? y.useLayoutEffect : y.useEffect;
function Es(e, t) {
  if (e === t) return !0;
  if (typeof e != typeof t) return !1;
  if (typeof e == "function" && e.toString() === t.toString()) return !0;
  let n, r, o;
  if (e && t && typeof e == "object") {
    if (Array.isArray(e)) {
      if (((n = e.length), n !== t.length)) return !1;
      for (r = n; r-- !== 0; ) if (!Es(e[r], t[r])) return !1;
      return !0;
    }
    if (((o = Object.keys(e)), (n = o.length), n !== Object.keys(t).length))
      return !1;
    for (r = n; r-- !== 0; ) if (!{}.hasOwnProperty.call(t, o[r])) return !1;
    for (r = n; r-- !== 0; ) {
      const i = o[r];
      if (!(i === "_owner" && e.$$typeof) && !Es(e[i], t[i])) return !1;
    }
    return !0;
  }
  return e !== e && t !== t;
}
function Cm(e) {
  return typeof window > "u"
    ? 1
    : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function Bd(e, t) {
  const n = Cm(e);
  return Math.round(t * n) / n;
}
function Dl(e) {
  const t = y.useRef(e);
  return (
    Ki(() => {
      t.current = e;
    }),
    t
  );
}
function p1(e) {
  e === void 0 && (e = {});
  const {
      placement: t = "bottom",
      strategy: n = "absolute",
      middleware: r = [],
      platform: o,
      elements: { reference: i, floating: s } = {},
      transform: l = !0,
      whileElementsMounted: a,
      open: u,
    } = e,
    [d, f] = y.useState({
      x: 0,
      y: 0,
      strategy: n,
      placement: t,
      middlewareData: {},
      isPositioned: !1,
    }),
    [c, v] = y.useState(r);
  Es(c, r) || v(r);
  const [x, g] = y.useState(null),
    [S, h] = y.useState(null),
    p = y.useCallback((C) => {
      C !== b.current && ((b.current = C), g(C));
    }, []),
    m = y.useCallback((C) => {
      C !== P.current && ((P.current = C), h(C));
    }, []),
    k = i || x,
    E = s || S,
    b = y.useRef(null),
    P = y.useRef(null),
    T = y.useRef(d),
    I = a != null,
    _ = Dl(a),
    $ = Dl(o),
    D = Dl(u),
    H = y.useCallback(() => {
      if (!b.current || !P.current) return;
      const C = { placement: t, strategy: n, middleware: c };
      $.current && (C.platform = $.current),
        f1(b.current, P.current, C).then((A) => {
          const z = { ...A, isPositioned: D.current !== !1 };
          O.current &&
            !Es(T.current, z) &&
            ((T.current = z),
            ni.flushSync(() => {
              f(z);
            }));
        });
    }, [c, t, n, $, D]);
  Ki(() => {
    u === !1 &&
      T.current.isPositioned &&
      ((T.current.isPositioned = !1), f((C) => ({ ...C, isPositioned: !1 })));
  }, [u]);
  const O = y.useRef(!1);
  Ki(
    () => (
      (O.current = !0),
      () => {
        O.current = !1;
      }
    ),
    []
  ),
    Ki(() => {
      if ((k && (b.current = k), E && (P.current = E), k && E)) {
        if (_.current) return _.current(k, E, H);
        H();
      }
    }, [k, E, H, _, I]);
  const Q = y.useMemo(
      () => ({ reference: b, floating: P, setReference: p, setFloating: m }),
      [p, m]
    ),
    U = y.useMemo(() => ({ reference: k, floating: E }), [k, E]),
    K = y.useMemo(() => {
      const C = { position: n, left: 0, top: 0 };
      if (!U.floating) return C;
      const A = Bd(U.floating, d.x),
        z = Bd(U.floating, d.y);
      return l
        ? {
            ...C,
            transform: "translate(" + A + "px, " + z + "px)",
            ...(Cm(U.floating) >= 1.5 && { willChange: "transform" }),
          }
        : { position: n, left: A, top: z };
    }, [n, l, U.floating, d.x, d.y]);
  return y.useMemo(
    () => ({ ...d, update: H, refs: Q, elements: U, floatingStyles: K }),
    [d, H, Q, U, K]
  );
}
const h1 = (e) => {
    function t(n) {
      return {}.hasOwnProperty.call(n, "current");
    }
    return {
      name: "arrow",
      options: e,
      fn(n) {
        const { element: r, padding: o } = typeof e == "function" ? e(n) : e;
        return r && t(r)
          ? r.current != null
            ? Ud({ element: r.current, padding: o }).fn(n)
            : {}
          : r
          ? Ud({ element: r, padding: o }).fn(n)
          : {};
      },
    };
  },
  m1 = (e, t) => ({ ...s1(e), options: [e, t] }),
  g1 = (e, t) => ({ ...l1(e), options: [e, t] }),
  v1 = (e, t) => ({ ...d1(e), options: [e, t] }),
  y1 = (e, t) => ({ ...a1(e), options: [e, t] }),
  x1 = (e, t) => ({ ...u1(e), options: [e, t] }),
  w1 = (e, t) => ({ ...c1(e), options: [e, t] }),
  S1 = (e, t) => ({ ...h1(e), options: [e, t] });
var k1 = "Arrow",
  bm = y.forwardRef((e, t) => {
    const { children: n, width: r = 10, height: o = 5, ...i } = e;
    return w.jsx(be.svg, {
      ...i,
      ref: t,
      width: r,
      height: o,
      viewBox: "0 0 30 10",
      preserveAspectRatio: "none",
      children: e.asChild ? n : w.jsx("polygon", { points: "0,0 30,0 15,10" }),
    });
  });
bm.displayName = k1;
var E1 = bm;
function C1(e, t = []) {
  let n = [];
  function r(i, s) {
    const l = y.createContext(s),
      a = n.length;
    n = [...n, s];
    function u(f) {
      const { scope: c, children: v, ...x } = f,
        g = (c == null ? void 0 : c[e][a]) || l,
        S = y.useMemo(() => x, Object.values(x));
      return w.jsx(g.Provider, { value: S, children: v });
    }
    function d(f, c) {
      const v = (c == null ? void 0 : c[e][a]) || l,
        x = y.useContext(v);
      if (x) return x;
      if (s !== void 0) return s;
      throw new Error(`\`${f}\` must be used within \`${i}\``);
    }
    return (u.displayName = i + "Provider"), [u, d];
  }
  const o = () => {
    const i = n.map((s) => y.createContext(s));
    return function (l) {
      const a = (l == null ? void 0 : l[e]) || i;
      return y.useMemo(() => ({ [`__scope${e}`]: { ...l, [e]: a } }), [l, a]);
    };
  };
  return (o.scopeName = e), [r, b1(o, ...t)];
}
function b1(...e) {
  const t = e[0];
  if (e.length === 1) return t;
  const n = () => {
    const r = e.map((o) => ({ useScope: o(), scopeName: o.scopeName }));
    return function (i) {
      const s = r.reduce((l, { useScope: a, scopeName: u }) => {
        const f = a(i)[`__scope${u}`];
        return { ...l, ...f };
      }, {});
      return y.useMemo(() => ({ [`__scope${t.scopeName}`]: s }), [s]);
    };
  };
  return (n.scopeName = t.scopeName), n;
}
function P1(e) {
  const [t, n] = y.useState(void 0);
  return (
    Qt(() => {
      if (e) {
        n({ width: e.offsetWidth, height: e.offsetHeight });
        const r = new ResizeObserver((o) => {
          if (!Array.isArray(o) || !o.length) return;
          const i = o[0];
          let s, l;
          if ("borderBoxSize" in i) {
            const a = i.borderBoxSize,
              u = Array.isArray(a) ? a[0] : a;
            (s = u.inlineSize), (l = u.blockSize);
          } else (s = e.offsetWidth), (l = e.offsetHeight);
          n({ width: s, height: l });
        });
        return r.observe(e, { box: "border-box" }), () => r.unobserve(e);
      } else n(void 0);
    }, [e]),
    t
  );
}
var Pm = "Popper",
  [Nm, Tm] = C1(Pm),
  [Fk, Rm] = Nm(Pm),
  Am = "PopperAnchor",
  jm = y.forwardRef((e, t) => {
    const { __scopePopper: n, virtualRef: r, ...o } = e,
      i = Rm(Am, n),
      s = y.useRef(null),
      l = yt(t, s);
    return (
      y.useEffect(() => {
        i.onAnchorChange((r == null ? void 0 : r.current) || s.current);
      }),
      r ? null : w.jsx(be.div, { ...o, ref: l })
    );
  });
jm.displayName = Am;
var tc = "PopperContent",
  [N1, T1] = Nm(tc),
  _m = y.forwardRef((e, t) => {
    var at, Xt, qt, Jt, si, or;
    const {
        __scopePopper: n,
        side: r = "bottom",
        sideOffset: o = 0,
        align: i = "center",
        alignOffset: s = 0,
        arrowPadding: l = 0,
        avoidCollisions: a = !0,
        collisionBoundary: u = [],
        collisionPadding: d = 0,
        sticky: f = "partial",
        hideWhenDetached: c = !1,
        updatePositionStrategy: v = "optimized",
        onPlaced: x,
        ...g
      } = e,
      S = Rm(tc, n),
      [h, p] = y.useState(null),
      m = yt(t, (In) => p(In)),
      [k, E] = y.useState(null),
      b = P1(k),
      P = (b == null ? void 0 : b.width) ?? 0,
      T = (b == null ? void 0 : b.height) ?? 0,
      I = r + (i !== "center" ? "-" + i : ""),
      _ =
        typeof d == "number"
          ? d
          : { top: 0, right: 0, bottom: 0, left: 0, ...d },
      $ = Array.isArray(u) ? u : [u],
      D = $.length > 0,
      H = { padding: _, boundary: $.filter(A1), altBoundary: D },
      {
        refs: O,
        floatingStyles: Q,
        placement: U,
        isPositioned: K,
        middlewareData: C,
      } = p1({
        strategy: "fixed",
        placement: I,
        whileElementsMounted: (...In) =>
          i1(...In, { animationFrame: v === "always" }),
        elements: { reference: S.anchor },
        middleware: [
          m1({ mainAxis: o + T, alignmentAxis: s }),
          a &&
            g1({
              mainAxis: !0,
              crossAxis: !1,
              limiter: f === "partial" ? v1() : void 0,
              ...H,
            }),
          a && y1({ ...H }),
          x1({
            ...H,
            apply: ({
              elements: In,
              rects: eo,
              availableWidth: li,
              availableHeight: Zt,
            }) => {
              const { width: el, height: tl } = eo.reference,
                Se = In.floating.style;
              Se.setProperty("--radix-popper-available-width", `${li}px`),
                Se.setProperty("--radix-popper-available-height", `${Zt}px`),
                Se.setProperty("--radix-popper-anchor-width", `${el}px`),
                Se.setProperty("--radix-popper-anchor-height", `${tl}px`);
            },
          }),
          k && S1({ element: k, padding: l }),
          j1({ arrowWidth: P, arrowHeight: T }),
          c && w1({ strategy: "referenceHidden", ...H }),
        ],
      }),
      [A, z] = Lm(U),
      L = xt(x);
    Qt(() => {
      K && (L == null || L());
    }, [K, L]);
    const F = (at = C.arrow) == null ? void 0 : at.x,
      Y = (Xt = C.arrow) == null ? void 0 : Xt.y,
      le = ((qt = C.arrow) == null ? void 0 : qt.centerOffset) !== 0,
      [Ve, J] = y.useState();
    return (
      Qt(() => {
        h && J(window.getComputedStyle(h).zIndex);
      }, [h]),
      w.jsx("div", {
        ref: O.setFloating,
        "data-radix-popper-content-wrapper": "",
        style: {
          ...Q,
          transform: K ? Q.transform : "translate(0, -200%)",
          minWidth: "max-content",
          zIndex: Ve,
          "--radix-popper-transform-origin": [
            (Jt = C.transformOrigin) == null ? void 0 : Jt.x,
            (si = C.transformOrigin) == null ? void 0 : si.y,
          ].join(" "),
          ...(((or = C.hide) == null ? void 0 : or.referenceHidden) && {
            visibility: "hidden",
            pointerEvents: "none",
          }),
        },
        dir: e.dir,
        children: w.jsx(N1, {
          scope: n,
          placedSide: A,
          onArrowChange: E,
          arrowX: F,
          arrowY: Y,
          shouldHideArrow: le,
          children: w.jsx(be.div, {
            "data-side": A,
            "data-align": z,
            ...g,
            ref: m,
            style: { ...g.style, animation: K ? void 0 : "none" },
          }),
        }),
      })
    );
  });
_m.displayName = tc;
var Om = "PopperArrow",
  R1 = { top: "bottom", right: "left", bottom: "top", left: "right" },
  Mm = y.forwardRef(function (t, n) {
    const { __scopePopper: r, ...o } = t,
      i = T1(Om, r),
      s = R1[i.placedSide];
    return w.jsx("span", {
      ref: i.onArrowChange,
      style: {
        position: "absolute",
        left: i.arrowX,
        top: i.arrowY,
        [s]: 0,
        transformOrigin: {
          top: "",
          right: "0 0",
          bottom: "center 0",
          left: "100% 0",
        }[i.placedSide],
        transform: {
          top: "translateY(100%)",
          right: "translateY(50%) rotate(90deg) translateX(-50%)",
          bottom: "rotate(180deg)",
          left: "translateY(50%) rotate(-90deg) translateX(50%)",
        }[i.placedSide],
        visibility: i.shouldHideArrow ? "hidden" : void 0,
      },
      children: w.jsx(E1, {
        ...o,
        ref: n,
        style: { ...o.style, display: "block" },
      }),
    });
  });
Mm.displayName = Om;
function A1(e) {
  return e !== null;
}
var j1 = (e) => ({
  name: "transformOrigin",
  options: e,
  fn(t) {
    var S, h, p;
    const { placement: n, rects: r, middlewareData: o } = t,
      s = ((S = o.arrow) == null ? void 0 : S.centerOffset) !== 0,
      l = s ? 0 : e.arrowWidth,
      a = s ? 0 : e.arrowHeight,
      [u, d] = Lm(n),
      f = { start: "0%", center: "50%", end: "100%" }[d],
      c = (((h = o.arrow) == null ? void 0 : h.x) ?? 0) + l / 2,
      v = (((p = o.arrow) == null ? void 0 : p.y) ?? 0) + a / 2;
    let x = "",
      g = "";
    return (
      u === "bottom"
        ? ((x = s ? f : `${c}px`), (g = `${-a}px`))
        : u === "top"
        ? ((x = s ? f : `${c}px`), (g = `${r.floating.height + a}px`))
        : u === "right"
        ? ((x = `${-a}px`), (g = s ? f : `${v}px`))
        : u === "left" &&
          ((x = `${r.floating.width + a}px`), (g = s ? f : `${v}px`)),
      { data: { x, y: g } }
    );
  },
});
function Lm(e) {
  const [t, n = "center"] = e.split("-");
  return [t, n];
}
var _1 = jm,
  O1 = _m,
  M1 = Mm,
  [Ys, $k] = Bu("Tooltip", [Tm]),
  nc = Tm(),
  Im = "TooltipProvider",
  L1 = 700,
  Wd = "tooltip.open",
  [I1, Dm] = Ys(Im),
  zm = (e) => {
    const {
        __scopeTooltip: t,
        delayDuration: n = L1,
        skipDelayDuration: r = 300,
        disableHoverableContent: o = !1,
        children: i,
      } = e,
      [s, l] = y.useState(!0),
      a = y.useRef(!1),
      u = y.useRef(0);
    return (
      y.useEffect(() => {
        const d = u.current;
        return () => window.clearTimeout(d);
      }, []),
      w.jsx(I1, {
        scope: t,
        isOpenDelayed: s,
        delayDuration: n,
        onOpen: y.useCallback(() => {
          window.clearTimeout(u.current), l(!1);
        }, []),
        onClose: y.useCallback(() => {
          window.clearTimeout(u.current),
            (u.current = window.setTimeout(() => l(!0), r));
        }, [r]),
        isPointerInTransitRef: a,
        onPointerInTransitChange: y.useCallback((d) => {
          a.current = d;
        }, []),
        disableHoverableContent: o,
        children: i,
      })
    );
  };
zm.displayName = Im;
var Fm = "Tooltip",
  [Uk, Xs] = Ys(Fm),
  Wa = "TooltipTrigger",
  D1 = y.forwardRef((e, t) => {
    const { __scopeTooltip: n, ...r } = e,
      o = Xs(Wa, n),
      i = Dm(Wa, n),
      s = nc(n),
      l = y.useRef(null),
      a = yt(t, l, o.onTriggerChange),
      u = y.useRef(!1),
      d = y.useRef(!1),
      f = y.useCallback(() => (u.current = !1), []);
    return (
      y.useEffect(
        () => () => document.removeEventListener("pointerup", f),
        [f]
      ),
      w.jsx(_1, {
        asChild: !0,
        ...s,
        children: w.jsx(be.button, {
          "aria-describedby": o.open ? o.contentId : void 0,
          "data-state": o.stateAttribute,
          ...r,
          ref: a,
          onPointerMove: ve(e.onPointerMove, (c) => {
            c.pointerType !== "touch" &&
              !d.current &&
              !i.isPointerInTransitRef.current &&
              (o.onTriggerEnter(), (d.current = !0));
          }),
          onPointerLeave: ve(e.onPointerLeave, () => {
            o.onTriggerLeave(), (d.current = !1);
          }),
          onPointerDown: ve(e.onPointerDown, () => {
            (u.current = !0),
              document.addEventListener("pointerup", f, { once: !0 });
          }),
          onFocus: ve(e.onFocus, () => {
            u.current || o.onOpen();
          }),
          onBlur: ve(e.onBlur, o.onClose),
          onClick: ve(e.onClick, o.onClose),
        }),
      })
    );
  });
D1.displayName = Wa;
var z1 = "TooltipPortal",
  [Bk, F1] = Ys(z1, { forceMount: void 0 }),
  Qr = "TooltipContent",
  $m = y.forwardRef((e, t) => {
    const n = F1(Qr, e.__scopeTooltip),
      { forceMount: r = n.forceMount, side: o = "top", ...i } = e,
      s = Xs(Qr, e.__scopeTooltip);
    return w.jsx(Vu, {
      present: r || s.open,
      children: s.disableHoverableContent
        ? w.jsx(Um, { side: o, ...i, ref: t })
        : w.jsx($1, { side: o, ...i, ref: t }),
    });
  }),
  $1 = y.forwardRef((e, t) => {
    const n = Xs(Qr, e.__scopeTooltip),
      r = Dm(Qr, e.__scopeTooltip),
      o = y.useRef(null),
      i = yt(t, o),
      [s, l] = y.useState(null),
      { trigger: a, onClose: u } = n,
      d = o.current,
      { onPointerInTransitChange: f } = r,
      c = y.useCallback(() => {
        l(null), f(!1);
      }, [f]),
      v = y.useCallback(
        (x, g) => {
          const S = x.currentTarget,
            h = { x: x.clientX, y: x.clientY },
            p = V1(h, S.getBoundingClientRect()),
            m = H1(h, p),
            k = Q1(g.getBoundingClientRect()),
            E = G1([...m, ...k]);
          l(E), f(!0);
        },
        [f]
      );
    return (
      y.useEffect(() => () => c(), [c]),
      y.useEffect(() => {
        if (a && d) {
          const x = (S) => v(S, d),
            g = (S) => v(S, a);
          return (
            a.addEventListener("pointerleave", x),
            d.addEventListener("pointerleave", g),
            () => {
              a.removeEventListener("pointerleave", x),
                d.removeEventListener("pointerleave", g);
            }
          );
        }
      }, [a, d, v, c]),
      y.useEffect(() => {
        if (s) {
          const x = (g) => {
            const S = g.target,
              h = { x: g.clientX, y: g.clientY },
              p =
                (a == null ? void 0 : a.contains(S)) ||
                (d == null ? void 0 : d.contains(S)),
              m = !K1(h, s);
            p ? c() : m && (c(), u());
          };
          return (
            document.addEventListener("pointermove", x),
            () => document.removeEventListener("pointermove", x)
          );
        }
      }, [a, d, s, u, c]),
      w.jsx(Um, { ...e, ref: i })
    );
  }),
  [U1, B1] = Ys(Fm, { isInside: !1 }),
  Um = y.forwardRef((e, t) => {
    const {
        __scopeTooltip: n,
        children: r,
        "aria-label": o,
        onEscapeKeyDown: i,
        onPointerDownOutside: s,
        ...l
      } = e,
      a = Xs(Qr, n),
      u = nc(n),
      { onClose: d } = a;
    return (
      y.useEffect(
        () => (
          document.addEventListener(Wd, d),
          () => document.removeEventListener(Wd, d)
        ),
        [d]
      ),
      y.useEffect(() => {
        if (a.trigger) {
          const f = (c) => {
            const v = c.target;
            v != null && v.contains(a.trigger) && d();
          };
          return (
            window.addEventListener("scroll", f, { capture: !0 }),
            () => window.removeEventListener("scroll", f, { capture: !0 })
          );
        }
      }, [a.trigger, d]),
      w.jsx(Wu, {
        asChild: !0,
        disableOutsidePointerEvents: !1,
        onEscapeKeyDown: i,
        onPointerDownOutside: s,
        onFocusOutside: (f) => f.preventDefault(),
        onDismiss: d,
        children: w.jsxs(O1, {
          "data-state": a.stateAttribute,
          ...u,
          ...l,
          ref: t,
          style: {
            ...l.style,
            "--radix-tooltip-content-transform-origin":
              "var(--radix-popper-transform-origin)",
            "--radix-tooltip-content-available-width":
              "var(--radix-popper-available-width)",
            "--radix-tooltip-content-available-height":
              "var(--radix-popper-available-height)",
            "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
            "--radix-tooltip-trigger-height":
              "var(--radix-popper-anchor-height)",
          },
          children: [
            w.jsx(Ah, { children: r }),
            w.jsx(U1, {
              scope: n,
              isInside: !0,
              children: w.jsx(Oy, {
                id: a.contentId,
                role: "tooltip",
                children: o || r,
              }),
            }),
          ],
        }),
      })
    );
  });
$m.displayName = Qr;
var Bm = "TooltipArrow",
  W1 = y.forwardRef((e, t) => {
    const { __scopeTooltip: n, ...r } = e,
      o = nc(n);
    return B1(Bm, n).isInside ? null : w.jsx(M1, { ...o, ...r, ref: t });
  });
W1.displayName = Bm;
function V1(e, t) {
  const n = Math.abs(t.top - e.y),
    r = Math.abs(t.bottom - e.y),
    o = Math.abs(t.right - e.x),
    i = Math.abs(t.left - e.x);
  switch (Math.min(n, r, o, i)) {
    case i:
      return "left";
    case o:
      return "right";
    case n:
      return "top";
    case r:
      return "bottom";
    default:
      throw new Error("unreachable");
  }
}
function H1(e, t, n = 5) {
  const r = [];
  switch (t) {
    case "top":
      r.push({ x: e.x - n, y: e.y + n }, { x: e.x + n, y: e.y + n });
      break;
    case "bottom":
      r.push({ x: e.x - n, y: e.y - n }, { x: e.x + n, y: e.y - n });
      break;
    case "left":
      r.push({ x: e.x + n, y: e.y - n }, { x: e.x + n, y: e.y + n });
      break;
    case "right":
      r.push({ x: e.x - n, y: e.y - n }, { x: e.x - n, y: e.y + n });
      break;
  }
  return r;
}
function Q1(e) {
  const { top: t, right: n, bottom: r, left: o } = e;
  return [
    { x: o, y: t },
    { x: n, y: t },
    { x: n, y: r },
    { x: o, y: r },
  ];
}
function K1(e, t) {
  const { x: n, y: r } = e;
  let o = !1;
  for (let i = 0, s = t.length - 1; i < t.length; s = i++) {
    const l = t[i].x,
      a = t[i].y,
      u = t[s].x,
      d = t[s].y;
    a > r != d > r && n < ((u - l) * (r - a)) / (d - a) + l && (o = !o);
  }
  return o;
}
function G1(e) {
  const t = e.slice();
  return (
    t.sort((n, r) =>
      n.x < r.x ? -1 : n.x > r.x ? 1 : n.y < r.y ? -1 : n.y > r.y ? 1 : 0
    ),
    Y1(t)
  );
}
function Y1(e) {
  if (e.length <= 1) return e.slice();
  const t = [];
  for (let r = 0; r < e.length; r++) {
    const o = e[r];
    for (; t.length >= 2; ) {
      const i = t[t.length - 1],
        s = t[t.length - 2];
      if ((i.x - s.x) * (o.y - s.y) >= (i.y - s.y) * (o.x - s.x)) t.pop();
      else break;
    }
    t.push(o);
  }
  t.pop();
  const n = [];
  for (let r = e.length - 1; r >= 0; r--) {
    const o = e[r];
    for (; n.length >= 2; ) {
      const i = n[n.length - 1],
        s = n[n.length - 2];
      if ((i.x - s.x) * (o.y - s.y) >= (i.y - s.y) * (o.x - s.x)) n.pop();
      else break;
    }
    n.push(o);
  }
  return (
    n.pop(),
    t.length === 1 && n.length === 1 && t[0].x === n[0].x && t[0].y === n[0].y
      ? t
      : t.concat(n)
  );
}
var X1 = zm,
  Wm = $m;
const q1 = X1,
  J1 = y.forwardRef(({ className: e, sideOffset: t = 4, ...n }, r) =>
    w.jsx(Wm, {
      ref: r,
      sideOffset: t,
      className: Ot(
        "z-50 overflow-hidden rounded-md border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        e
      ),
      ...n,
    })
  );
J1.displayName = Wm.displayName;
var qs = class {
    constructor() {
      (this.listeners = new Set()),
        (this.subscribe = this.subscribe.bind(this));
    }
    subscribe(e) {
      return (
        this.listeners.add(e),
        this.onSubscribe(),
        () => {
          this.listeners.delete(e), this.onUnsubscribe();
        }
      );
    }
    hasListeners() {
      return this.listeners.size > 0;
    }
    onSubscribe() {}
    onUnsubscribe() {}
  },
  Js = typeof window > "u" || "Deno" in globalThis;
function dt() {}
function Z1(e, t) {
  return typeof e == "function" ? e(t) : e;
}
function eS(e) {
  return typeof e == "number" && e >= 0 && e !== 1 / 0;
}
function tS(e, t) {
  return Math.max(e + (t || 0) - Date.now(), 0);
}
function Vd(e, t) {
  return typeof e == "function" ? e(t) : e;
}
function nS(e, t) {
  return typeof e == "function" ? e(t) : e;
}
function Hd(e, t) {
  const {
    type: n = "all",
    exact: r,
    fetchStatus: o,
    predicate: i,
    queryKey: s,
    stale: l,
  } = e;
  if (s) {
    if (r) {
      if (t.queryHash !== rc(s, t.options)) return !1;
    } else if (!Qo(t.queryKey, s)) return !1;
  }
  if (n !== "all") {
    const a = t.isActive();
    if ((n === "active" && !a) || (n === "inactive" && a)) return !1;
  }
  return !(
    (typeof l == "boolean" && t.isStale() !== l) ||
    (o && o !== t.state.fetchStatus) ||
    (i && !i(t))
  );
}
function Qd(e, t) {
  const { exact: n, status: r, predicate: o, mutationKey: i } = e;
  if (i) {
    if (!t.options.mutationKey) return !1;
    if (n) {
      if (Ho(t.options.mutationKey) !== Ho(i)) return !1;
    } else if (!Qo(t.options.mutationKey, i)) return !1;
  }
  return !((r && t.state.status !== r) || (o && !o(t)));
}
function rc(e, t) {
  return ((t == null ? void 0 : t.queryKeyHashFn) || Ho)(e);
}
function Ho(e) {
  return JSON.stringify(e, (t, n) =>
    Va(n)
      ? Object.keys(n)
          .sort()
          .reduce((r, o) => ((r[o] = n[o]), r), {})
      : n
  );
}
function Qo(e, t) {
  return e === t
    ? !0
    : typeof e != typeof t
    ? !1
    : e && t && typeof e == "object" && typeof t == "object"
    ? !Object.keys(t).some((n) => !Qo(e[n], t[n]))
    : !1;
}
function Vm(e, t) {
  if (e === t) return e;
  const n = Kd(e) && Kd(t);
  if (n || (Va(e) && Va(t))) {
    const r = n ? e : Object.keys(e),
      o = r.length,
      i = n ? t : Object.keys(t),
      s = i.length,
      l = n ? [] : {};
    let a = 0;
    for (let u = 0; u < s; u++) {
      const d = n ? u : i[u];
      ((!n && r.includes(d)) || n) && e[d] === void 0 && t[d] === void 0
        ? ((l[d] = void 0), a++)
        : ((l[d] = Vm(e[d], t[d])), l[d] === e[d] && e[d] !== void 0 && a++);
    }
    return o === s && a === o ? e : l;
  }
  return t;
}
function Kd(e) {
  return Array.isArray(e) && e.length === Object.keys(e).length;
}
function Va(e) {
  if (!Gd(e)) return !1;
  const t = e.constructor;
  if (t === void 0) return !0;
  const n = t.prototype;
  return !(
    !Gd(n) ||
    !n.hasOwnProperty("isPrototypeOf") ||
    Object.getPrototypeOf(e) !== Object.prototype
  );
}
function Gd(e) {
  return Object.prototype.toString.call(e) === "[object Object]";
}
function rS(e) {
  return new Promise((t) => {
    setTimeout(t, e);
  });
}
function oS(e, t, n) {
  return typeof n.structuralSharing == "function"
    ? n.structuralSharing(e, t)
    : n.structuralSharing !== !1
    ? Vm(e, t)
    : t;
}
function iS(e, t, n = 0) {
  const r = [...e, t];
  return n && r.length > n ? r.slice(1) : r;
}
function sS(e, t, n = 0) {
  const r = [t, ...e];
  return n && r.length > n ? r.slice(0, -1) : r;
}
var oc = Symbol();
function Hm(e, t) {
  return !e.queryFn && t != null && t.initialPromise
    ? () => t.initialPromise
    : !e.queryFn || e.queryFn === oc
    ? () => Promise.reject(new Error(`Missing queryFn: '${e.queryHash}'`))
    : e.queryFn;
}
var Bn,
  cn,
  Rr,
  sf,
  lS =
    ((sf = class extends qs {
      constructor() {
        super();
        q(this, Bn);
        q(this, cn);
        q(this, Rr);
        V(this, Rr, (t) => {
          if (!Js && window.addEventListener) {
            const n = () => t();
            return (
              window.addEventListener("visibilitychange", n, !1),
              () => {
                window.removeEventListener("visibilitychange", n);
              }
            );
          }
        });
      }
      onSubscribe() {
        N(this, cn) || this.setEventListener(N(this, Rr));
      }
      onUnsubscribe() {
        var t;
        this.hasListeners() ||
          ((t = N(this, cn)) == null || t.call(this), V(this, cn, void 0));
      }
      setEventListener(t) {
        var n;
        V(this, Rr, t),
          (n = N(this, cn)) == null || n.call(this),
          V(
            this,
            cn,
            t((r) => {
              typeof r == "boolean" ? this.setFocused(r) : this.onFocus();
            })
          );
      }
      setFocused(t) {
        N(this, Bn) !== t && (V(this, Bn, t), this.onFocus());
      }
      onFocus() {
        const t = this.isFocused();
        this.listeners.forEach((n) => {
          n(t);
        });
      }
      isFocused() {
        var t;
        return typeof N(this, Bn) == "boolean"
          ? N(this, Bn)
          : ((t = globalThis.document) == null ? void 0 : t.visibilityState) !==
              "hidden";
      }
    }),
    (Bn = new WeakMap()),
    (cn = new WeakMap()),
    (Rr = new WeakMap()),
    sf),
  Qm = new lS(),
  Ar,
  dn,
  jr,
  lf,
  aS =
    ((lf = class extends qs {
      constructor() {
        super();
        q(this, Ar, !0);
        q(this, dn);
        q(this, jr);
        V(this, jr, (t) => {
          if (!Js && window.addEventListener) {
            const n = () => t(!0),
              r = () => t(!1);
            return (
              window.addEventListener("online", n, !1),
              window.addEventListener("offline", r, !1),
              () => {
                window.removeEventListener("online", n),
                  window.removeEventListener("offline", r);
              }
            );
          }
        });
      }
      onSubscribe() {
        N(this, dn) || this.setEventListener(N(this, jr));
      }
      onUnsubscribe() {
        var t;
        this.hasListeners() ||
          ((t = N(this, dn)) == null || t.call(this), V(this, dn, void 0));
      }
      setEventListener(t) {
        var n;
        V(this, jr, t),
          (n = N(this, dn)) == null || n.call(this),
          V(this, dn, t(this.setOnline.bind(this)));
      }
      setOnline(t) {
        N(this, Ar) !== t &&
          (V(this, Ar, t),
          this.listeners.forEach((r) => {
            r(t);
          }));
      }
      isOnline() {
        return N(this, Ar);
      }
    }),
    (Ar = new WeakMap()),
    (dn = new WeakMap()),
    (jr = new WeakMap()),
    lf),
  Cs = new aS();
function uS() {
  let e, t;
  const n = new Promise((o, i) => {
    (e = o), (t = i);
  });
  (n.status = "pending"), n.catch(() => {});
  function r(o) {
    Object.assign(n, o), delete n.resolve, delete n.reject;
  }
  return (
    (n.resolve = (o) => {
      r({ status: "fulfilled", value: o }), e(o);
    }),
    (n.reject = (o) => {
      r({ status: "rejected", reason: o }), t(o);
    }),
    n
  );
}
function cS(e) {
  return Math.min(1e3 * 2 ** e, 3e4);
}
function Km(e) {
  return (e ?? "online") === "online" ? Cs.isOnline() : !0;
}
var Gm = class extends Error {
  constructor(e) {
    super("CancelledError"),
      (this.revert = e == null ? void 0 : e.revert),
      (this.silent = e == null ? void 0 : e.silent);
  }
};
function zl(e) {
  return e instanceof Gm;
}
function Ym(e) {
  let t = !1,
    n = 0,
    r = !1,
    o;
  const i = uS(),
    s = (g) => {
      var S;
      r || (c(new Gm(g)), (S = e.abort) == null || S.call(e));
    },
    l = () => {
      t = !0;
    },
    a = () => {
      t = !1;
    },
    u = () =>
      Qm.isFocused() &&
      (e.networkMode === "always" || Cs.isOnline()) &&
      e.canRun(),
    d = () => Km(e.networkMode) && e.canRun(),
    f = (g) => {
      var S;
      r ||
        ((r = !0),
        (S = e.onSuccess) == null || S.call(e, g),
        o == null || o(),
        i.resolve(g));
    },
    c = (g) => {
      var S;
      r ||
        ((r = !0),
        (S = e.onError) == null || S.call(e, g),
        o == null || o(),
        i.reject(g));
    },
    v = () =>
      new Promise((g) => {
        var S;
        (o = (h) => {
          (r || u()) && g(h);
        }),
          (S = e.onPause) == null || S.call(e);
      }).then(() => {
        var g;
        (o = void 0), r || (g = e.onContinue) == null || g.call(e);
      }),
    x = () => {
      if (r) return;
      let g;
      const S = n === 0 ? e.initialPromise : void 0;
      try {
        g = S ?? e.fn();
      } catch (h) {
        g = Promise.reject(h);
      }
      Promise.resolve(g)
        .then(f)
        .catch((h) => {
          var b;
          if (r) return;
          const p = e.retry ?? (Js ? 0 : 3),
            m = e.retryDelay ?? cS,
            k = typeof m == "function" ? m(n, h) : m,
            E =
              p === !0 ||
              (typeof p == "number" && n < p) ||
              (typeof p == "function" && p(n, h));
          if (t || !E) {
            c(h);
            return;
          }
          n++,
            (b = e.onFail) == null || b.call(e, n, h),
            rS(k)
              .then(() => (u() ? void 0 : v()))
              .then(() => {
                t ? c(h) : x();
              });
        });
    };
  return {
    promise: i,
    cancel: s,
    continue: () => (o == null || o(), i),
    cancelRetry: l,
    continueRetry: a,
    canStart: d,
    start: () => (d() ? x() : v().then(x), i),
  };
}
function dS() {
  let e = [],
    t = 0,
    n = (l) => {
      l();
    },
    r = (l) => {
      l();
    },
    o = (l) => setTimeout(l, 0);
  const i = (l) => {
      t
        ? e.push(l)
        : o(() => {
            n(l);
          });
    },
    s = () => {
      const l = e;
      (e = []),
        l.length &&
          o(() => {
            r(() => {
              l.forEach((a) => {
                n(a);
              });
            });
          });
    };
  return {
    batch: (l) => {
      let a;
      t++;
      try {
        a = l();
      } finally {
        t--, t || s();
      }
      return a;
    },
    batchCalls:
      (l) =>
      (...a) => {
        i(() => {
          l(...a);
        });
      },
    schedule: i,
    setNotifyFunction: (l) => {
      n = l;
    },
    setBatchNotifyFunction: (l) => {
      r = l;
    },
    setScheduler: (l) => {
      o = l;
    },
  };
}
var Le = dS(),
  Wn,
  af,
  Xm =
    ((af = class {
      constructor() {
        q(this, Wn);
      }
      destroy() {
        this.clearGcTimeout();
      }
      scheduleGc() {
        this.clearGcTimeout(),
          eS(this.gcTime) &&
            V(
              this,
              Wn,
              setTimeout(() => {
                this.optionalRemove();
              }, this.gcTime)
            );
      }
      updateGcTime(e) {
        this.gcTime = Math.max(
          this.gcTime || 0,
          e ?? (Js ? 1 / 0 : 5 * 60 * 1e3)
        );
      }
      clearGcTimeout() {
        N(this, Wn) && (clearTimeout(N(this, Wn)), V(this, Wn, void 0));
      }
    }),
    (Wn = new WeakMap()),
    af),
  _r,
  Or,
  tt,
  Ae,
  Yo,
  Vn,
  ft,
  It,
  uf,
  fS =
    ((uf = class extends Xm {
      constructor(t) {
        super();
        q(this, ft);
        q(this, _r);
        q(this, Or);
        q(this, tt);
        q(this, Ae);
        q(this, Yo);
        q(this, Vn);
        V(this, Vn, !1),
          V(this, Yo, t.defaultOptions),
          this.setOptions(t.options),
          (this.observers = []),
          V(this, tt, t.cache),
          (this.queryKey = t.queryKey),
          (this.queryHash = t.queryHash),
          V(this, _r, hS(this.options)),
          (this.state = t.state ?? N(this, _r)),
          this.scheduleGc();
      }
      get meta() {
        return this.options.meta;
      }
      get promise() {
        var t;
        return (t = N(this, Ae)) == null ? void 0 : t.promise;
      }
      setOptions(t) {
        (this.options = { ...N(this, Yo), ...t }),
          this.updateGcTime(this.options.gcTime);
      }
      optionalRemove() {
        !this.observers.length &&
          this.state.fetchStatus === "idle" &&
          N(this, tt).remove(this);
      }
      setData(t, n) {
        const r = oS(this.state.data, t, this.options);
        return (
          Ne(this, ft, It).call(this, {
            data: r,
            type: "success",
            dataUpdatedAt: n == null ? void 0 : n.updatedAt,
            manual: n == null ? void 0 : n.manual,
          }),
          r
        );
      }
      setState(t, n) {
        Ne(this, ft, It).call(this, {
          type: "setState",
          state: t,
          setStateOptions: n,
        });
      }
      cancel(t) {
        var r, o;
        const n = (r = N(this, Ae)) == null ? void 0 : r.promise;
        return (
          (o = N(this, Ae)) == null || o.cancel(t),
          n ? n.then(dt).catch(dt) : Promise.resolve()
        );
      }
      destroy() {
        super.destroy(), this.cancel({ silent: !0 });
      }
      reset() {
        this.destroy(), this.setState(N(this, _r));
      }
      isActive() {
        return this.observers.some((t) => nS(t.options.enabled, this) !== !1);
      }
      isDisabled() {
        return this.getObserversCount() > 0
          ? !this.isActive()
          : this.options.queryFn === oc ||
              this.state.dataUpdateCount + this.state.errorUpdateCount === 0;
      }
      isStale() {
        return this.state.isInvalidated
          ? !0
          : this.getObserversCount() > 0
          ? this.observers.some((t) => t.getCurrentResult().isStale)
          : this.state.data === void 0;
      }
      isStaleByTime(t = 0) {
        return (
          this.state.isInvalidated ||
          this.state.data === void 0 ||
          !tS(this.state.dataUpdatedAt, t)
        );
      }
      onFocus() {
        var n;
        const t = this.observers.find((r) => r.shouldFetchOnWindowFocus());
        t == null || t.refetch({ cancelRefetch: !1 }),
          (n = N(this, Ae)) == null || n.continue();
      }
      onOnline() {
        var n;
        const t = this.observers.find((r) => r.shouldFetchOnReconnect());
        t == null || t.refetch({ cancelRefetch: !1 }),
          (n = N(this, Ae)) == null || n.continue();
      }
      addObserver(t) {
        this.observers.includes(t) ||
          (this.observers.push(t),
          this.clearGcTimeout(),
          N(this, tt).notify({
            type: "observerAdded",
            query: this,
            observer: t,
          }));
      }
      removeObserver(t) {
        this.observers.includes(t) &&
          ((this.observers = this.observers.filter((n) => n !== t)),
          this.observers.length ||
            (N(this, Ae) &&
              (N(this, Vn)
                ? N(this, Ae).cancel({ revert: !0 })
                : N(this, Ae).cancelRetry()),
            this.scheduleGc()),
          N(this, tt).notify({
            type: "observerRemoved",
            query: this,
            observer: t,
          }));
      }
      getObserversCount() {
        return this.observers.length;
      }
      invalidate() {
        this.state.isInvalidated ||
          Ne(this, ft, It).call(this, { type: "invalidate" });
      }
      fetch(t, n) {
        var a, u, d;
        if (this.state.fetchStatus !== "idle") {
          if (this.state.data !== void 0 && n != null && n.cancelRefetch)
            this.cancel({ silent: !0 });
          else if (N(this, Ae))
            return N(this, Ae).continueRetry(), N(this, Ae).promise;
        }
        if ((t && this.setOptions(t), !this.options.queryFn)) {
          const f = this.observers.find((c) => c.options.queryFn);
          f && this.setOptions(f.options);
        }
        const r = new AbortController(),
          o = (f) => {
            Object.defineProperty(f, "signal", {
              enumerable: !0,
              get: () => (V(this, Vn, !0), r.signal),
            });
          },
          i = () => {
            const f = Hm(this.options, n),
              c = { queryKey: this.queryKey, meta: this.meta };
            return (
              o(c),
              V(this, Vn, !1),
              this.options.persister ? this.options.persister(f, c, this) : f(c)
            );
          },
          s = {
            fetchOptions: n,
            options: this.options,
            queryKey: this.queryKey,
            state: this.state,
            fetchFn: i,
          };
        o(s),
          (a = this.options.behavior) == null || a.onFetch(s, this),
          V(this, Or, this.state),
          (this.state.fetchStatus === "idle" ||
            this.state.fetchMeta !==
              ((u = s.fetchOptions) == null ? void 0 : u.meta)) &&
            Ne(this, ft, It).call(this, {
              type: "fetch",
              meta: (d = s.fetchOptions) == null ? void 0 : d.meta,
            });
        const l = (f) => {
          var c, v, x, g;
          (zl(f) && f.silent) ||
            Ne(this, ft, It).call(this, { type: "error", error: f }),
            zl(f) ||
              ((v = (c = N(this, tt).config).onError) == null ||
                v.call(c, f, this),
              (g = (x = N(this, tt).config).onSettled) == null ||
                g.call(x, this.state.data, f, this)),
            this.scheduleGc();
        };
        return (
          V(
            this,
            Ae,
            Ym({
              initialPromise: n == null ? void 0 : n.initialPromise,
              fn: s.fetchFn,
              abort: r.abort.bind(r),
              onSuccess: (f) => {
                var c, v, x, g;
                if (f === void 0) {
                  l(new Error(`${this.queryHash} data is undefined`));
                  return;
                }
                try {
                  this.setData(f);
                } catch (S) {
                  l(S);
                  return;
                }
                (v = (c = N(this, tt).config).onSuccess) == null ||
                  v.call(c, f, this),
                  (g = (x = N(this, tt).config).onSettled) == null ||
                    g.call(x, f, this.state.error, this),
                  this.scheduleGc();
              },
              onError: l,
              onFail: (f, c) => {
                Ne(this, ft, It).call(this, {
                  type: "failed",
                  failureCount: f,
                  error: c,
                });
              },
              onPause: () => {
                Ne(this, ft, It).call(this, { type: "pause" });
              },
              onContinue: () => {
                Ne(this, ft, It).call(this, { type: "continue" });
              },
              retry: s.options.retry,
              retryDelay: s.options.retryDelay,
              networkMode: s.options.networkMode,
              canRun: () => !0,
            })
          ),
          N(this, Ae).start()
        );
      }
    }),
    (_r = new WeakMap()),
    (Or = new WeakMap()),
    (tt = new WeakMap()),
    (Ae = new WeakMap()),
    (Yo = new WeakMap()),
    (Vn = new WeakMap()),
    (ft = new WeakSet()),
    (It = function (t) {
      const n = (r) => {
        switch (t.type) {
          case "failed":
            return {
              ...r,
              fetchFailureCount: t.failureCount,
              fetchFailureReason: t.error,
            };
          case "pause":
            return { ...r, fetchStatus: "paused" };
          case "continue":
            return { ...r, fetchStatus: "fetching" };
          case "fetch":
            return {
              ...r,
              ...pS(r.data, this.options),
              fetchMeta: t.meta ?? null,
            };
          case "success":
            return {
              ...r,
              data: t.data,
              dataUpdateCount: r.dataUpdateCount + 1,
              dataUpdatedAt: t.dataUpdatedAt ?? Date.now(),
              error: null,
              isInvalidated: !1,
              status: "success",
              ...(!t.manual && {
                fetchStatus: "idle",
                fetchFailureCount: 0,
                fetchFailureReason: null,
              }),
            };
          case "error":
            const o = t.error;
            return zl(o) && o.revert && N(this, Or)
              ? { ...N(this, Or), fetchStatus: "idle" }
              : {
                  ...r,
                  error: o,
                  errorUpdateCount: r.errorUpdateCount + 1,
                  errorUpdatedAt: Date.now(),
                  fetchFailureCount: r.fetchFailureCount + 1,
                  fetchFailureReason: o,
                  fetchStatus: "idle",
                  status: "error",
                };
          case "invalidate":
            return { ...r, isInvalidated: !0 };
          case "setState":
            return { ...r, ...t.state };
        }
      };
      (this.state = n(this.state)),
        Le.batch(() => {
          this.observers.forEach((r) => {
            r.onQueryUpdate();
          }),
            N(this, tt).notify({ query: this, type: "updated", action: t });
        });
    }),
    uf);
function pS(e, t) {
  return {
    fetchFailureCount: 0,
    fetchFailureReason: null,
    fetchStatus: Km(t.networkMode) ? "fetching" : "paused",
    ...(e === void 0 && { error: null, status: "pending" }),
  };
}
function hS(e) {
  const t =
      typeof e.initialData == "function" ? e.initialData() : e.initialData,
    n = t !== void 0,
    r = n
      ? typeof e.initialDataUpdatedAt == "function"
        ? e.initialDataUpdatedAt()
        : e.initialDataUpdatedAt
      : 0;
  return {
    data: t,
    dataUpdateCount: 0,
    dataUpdatedAt: n ? r ?? Date.now() : 0,
    error: null,
    errorUpdateCount: 0,
    errorUpdatedAt: 0,
    fetchFailureCount: 0,
    fetchFailureReason: null,
    fetchMeta: null,
    isInvalidated: !1,
    status: n ? "success" : "pending",
    fetchStatus: "idle",
  };
}
var Pt,
  cf,
  mS =
    ((cf = class extends qs {
      constructor(t = {}) {
        super();
        q(this, Pt);
        (this.config = t), V(this, Pt, new Map());
      }
      build(t, n, r) {
        const o = n.queryKey,
          i = n.queryHash ?? rc(o, n);
        let s = this.get(i);
        return (
          s ||
            ((s = new fS({
              cache: this,
              queryKey: o,
              queryHash: i,
              options: t.defaultQueryOptions(n),
              state: r,
              defaultOptions: t.getQueryDefaults(o),
            })),
            this.add(s)),
          s
        );
      }
      add(t) {
        N(this, Pt).has(t.queryHash) ||
          (N(this, Pt).set(t.queryHash, t),
          this.notify({ type: "added", query: t }));
      }
      remove(t) {
        const n = N(this, Pt).get(t.queryHash);
        n &&
          (t.destroy(),
          n === t && N(this, Pt).delete(t.queryHash),
          this.notify({ type: "removed", query: t }));
      }
      clear() {
        Le.batch(() => {
          this.getAll().forEach((t) => {
            this.remove(t);
          });
        });
      }
      get(t) {
        return N(this, Pt).get(t);
      }
      getAll() {
        return [...N(this, Pt).values()];
      }
      find(t) {
        const n = { exact: !0, ...t };
        return this.getAll().find((r) => Hd(n, r));
      }
      findAll(t = {}) {
        const n = this.getAll();
        return Object.keys(t).length > 0 ? n.filter((r) => Hd(t, r)) : n;
      }
      notify(t) {
        Le.batch(() => {
          this.listeners.forEach((n) => {
            n(t);
          });
        });
      }
      onFocus() {
        Le.batch(() => {
          this.getAll().forEach((t) => {
            t.onFocus();
          });
        });
      }
      onOnline() {
        Le.batch(() => {
          this.getAll().forEach((t) => {
            t.onOnline();
          });
        });
      }
    }),
    (Pt = new WeakMap()),
    cf),
  Nt,
  Oe,
  Hn,
  Tt,
  on,
  df,
  gS =
    ((df = class extends Xm {
      constructor(t) {
        super();
        q(this, Tt);
        q(this, Nt);
        q(this, Oe);
        q(this, Hn);
        (this.mutationId = t.mutationId),
          V(this, Oe, t.mutationCache),
          V(this, Nt, []),
          (this.state = t.state || vS()),
          this.setOptions(t.options),
          this.scheduleGc();
      }
      setOptions(t) {
        (this.options = t), this.updateGcTime(this.options.gcTime);
      }
      get meta() {
        return this.options.meta;
      }
      addObserver(t) {
        N(this, Nt).includes(t) ||
          (N(this, Nt).push(t),
          this.clearGcTimeout(),
          N(this, Oe).notify({
            type: "observerAdded",
            mutation: this,
            observer: t,
          }));
      }
      removeObserver(t) {
        V(
          this,
          Nt,
          N(this, Nt).filter((n) => n !== t)
        ),
          this.scheduleGc(),
          N(this, Oe).notify({
            type: "observerRemoved",
            mutation: this,
            observer: t,
          });
      }
      optionalRemove() {
        N(this, Nt).length ||
          (this.state.status === "pending"
            ? this.scheduleGc()
            : N(this, Oe).remove(this));
      }
      continue() {
        var t;
        return (
          ((t = N(this, Hn)) == null ? void 0 : t.continue()) ??
          this.execute(this.state.variables)
        );
      }
      async execute(t) {
        var o, i, s, l, a, u, d, f, c, v, x, g, S, h, p, m, k, E, b, P;
        V(
          this,
          Hn,
          Ym({
            fn: () =>
              this.options.mutationFn
                ? this.options.mutationFn(t)
                : Promise.reject(new Error("No mutationFn found")),
            onFail: (T, I) => {
              Ne(this, Tt, on).call(this, {
                type: "failed",
                failureCount: T,
                error: I,
              });
            },
            onPause: () => {
              Ne(this, Tt, on).call(this, { type: "pause" });
            },
            onContinue: () => {
              Ne(this, Tt, on).call(this, { type: "continue" });
            },
            retry: this.options.retry ?? 0,
            retryDelay: this.options.retryDelay,
            networkMode: this.options.networkMode,
            canRun: () => N(this, Oe).canRun(this),
          })
        );
        const n = this.state.status === "pending",
          r = !N(this, Hn).canStart();
        try {
          if (!n) {
            Ne(this, Tt, on).call(this, {
              type: "pending",
              variables: t,
              isPaused: r,
            }),
              await ((i = (o = N(this, Oe).config).onMutate) == null
                ? void 0
                : i.call(o, t, this));
            const I = await ((l = (s = this.options).onMutate) == null
              ? void 0
              : l.call(s, t));
            I !== this.state.context &&
              Ne(this, Tt, on).call(this, {
                type: "pending",
                context: I,
                variables: t,
                isPaused: r,
              });
          }
          const T = await N(this, Hn).start();
          return (
            await ((u = (a = N(this, Oe).config).onSuccess) == null
              ? void 0
              : u.call(a, T, t, this.state.context, this)),
            await ((f = (d = this.options).onSuccess) == null
              ? void 0
              : f.call(d, T, t, this.state.context)),
            await ((v = (c = N(this, Oe).config).onSettled) == null
              ? void 0
              : v.call(
                  c,
                  T,
                  null,
                  this.state.variables,
                  this.state.context,
                  this
                )),
            await ((g = (x = this.options).onSettled) == null
              ? void 0
              : g.call(x, T, null, t, this.state.context)),
            Ne(this, Tt, on).call(this, { type: "success", data: T }),
            T
          );
        } catch (T) {
          try {
            throw (
              (await ((h = (S = N(this, Oe).config).onError) == null
                ? void 0
                : h.call(S, T, t, this.state.context, this)),
              await ((m = (p = this.options).onError) == null
                ? void 0
                : m.call(p, T, t, this.state.context)),
              await ((E = (k = N(this, Oe).config).onSettled) == null
                ? void 0
                : E.call(
                    k,
                    void 0,
                    T,
                    this.state.variables,
                    this.state.context,
                    this
                  )),
              await ((P = (b = this.options).onSettled) == null
                ? void 0
                : P.call(b, void 0, T, t, this.state.context)),
              T)
            );
          } finally {
            Ne(this, Tt, on).call(this, { type: "error", error: T });
          }
        } finally {
          N(this, Oe).runNext(this);
        }
      }
    }),
    (Nt = new WeakMap()),
    (Oe = new WeakMap()),
    (Hn = new WeakMap()),
    (Tt = new WeakSet()),
    (on = function (t) {
      const n = (r) => {
        switch (t.type) {
          case "failed":
            return {
              ...r,
              failureCount: t.failureCount,
              failureReason: t.error,
            };
          case "pause":
            return { ...r, isPaused: !0 };
          case "continue":
            return { ...r, isPaused: !1 };
          case "pending":
            return {
              ...r,
              context: t.context,
              data: void 0,
              failureCount: 0,
              failureReason: null,
              error: null,
              isPaused: t.isPaused,
              status: "pending",
              variables: t.variables,
              submittedAt: Date.now(),
            };
          case "success":
            return {
              ...r,
              data: t.data,
              failureCount: 0,
              failureReason: null,
              error: null,
              status: "success",
              isPaused: !1,
            };
          case "error":
            return {
              ...r,
              data: void 0,
              error: t.error,
              failureCount: r.failureCount + 1,
              failureReason: t.error,
              isPaused: !1,
              status: "error",
            };
        }
      };
      (this.state = n(this.state)),
        Le.batch(() => {
          N(this, Nt).forEach((r) => {
            r.onMutationUpdate(t);
          }),
            N(this, Oe).notify({ mutation: this, type: "updated", action: t });
        });
    }),
    df);
function vS() {
  return {
    context: void 0,
    data: void 0,
    error: null,
    failureCount: 0,
    failureReason: null,
    isPaused: !1,
    status: "idle",
    variables: void 0,
    submittedAt: 0,
  };
}
var He,
  Xo,
  ff,
  yS =
    ((ff = class extends qs {
      constructor(t = {}) {
        super();
        q(this, He);
        q(this, Xo);
        (this.config = t), V(this, He, new Map()), V(this, Xo, Date.now());
      }
      build(t, n, r) {
        const o = new gS({
          mutationCache: this,
          mutationId: ++ci(this, Xo)._,
          options: t.defaultMutationOptions(n),
          state: r,
        });
        return this.add(o), o;
      }
      add(t) {
        const n = _i(t),
          r = N(this, He).get(n) ?? [];
        r.push(t),
          N(this, He).set(n, r),
          this.notify({ type: "added", mutation: t });
      }
      remove(t) {
        var r;
        const n = _i(t);
        if (N(this, He).has(n)) {
          const o =
            (r = N(this, He).get(n)) == null
              ? void 0
              : r.filter((i) => i !== t);
          o && (o.length === 0 ? N(this, He).delete(n) : N(this, He).set(n, o));
        }
        this.notify({ type: "removed", mutation: t });
      }
      canRun(t) {
        var r;
        const n =
          (r = N(this, He).get(_i(t))) == null
            ? void 0
            : r.find((o) => o.state.status === "pending");
        return !n || n === t;
      }
      runNext(t) {
        var r;
        const n =
          (r = N(this, He).get(_i(t))) == null
            ? void 0
            : r.find((o) => o !== t && o.state.isPaused);
        return (n == null ? void 0 : n.continue()) ?? Promise.resolve();
      }
      clear() {
        Le.batch(() => {
          this.getAll().forEach((t) => {
            this.remove(t);
          });
        });
      }
      getAll() {
        return [...N(this, He).values()].flat();
      }
      find(t) {
        const n = { exact: !0, ...t };
        return this.getAll().find((r) => Qd(n, r));
      }
      findAll(t = {}) {
        return this.getAll().filter((n) => Qd(t, n));
      }
      notify(t) {
        Le.batch(() => {
          this.listeners.forEach((n) => {
            n(t);
          });
        });
      }
      resumePausedMutations() {
        const t = this.getAll().filter((n) => n.state.isPaused);
        return Le.batch(() =>
          Promise.all(t.map((n) => n.continue().catch(dt)))
        );
      }
    }),
    (He = new WeakMap()),
    (Xo = new WeakMap()),
    ff);
function _i(e) {
  var t;
  return (
    ((t = e.options.scope) == null ? void 0 : t.id) ?? String(e.mutationId)
  );
}
function Yd(e) {
  return {
    onFetch: (t, n) => {
      var d, f, c, v, x;
      const r = t.options,
        o =
          (c =
            (f = (d = t.fetchOptions) == null ? void 0 : d.meta) == null
              ? void 0
              : f.fetchMore) == null
            ? void 0
            : c.direction,
        i = ((v = t.state.data) == null ? void 0 : v.pages) || [],
        s = ((x = t.state.data) == null ? void 0 : x.pageParams) || [];
      let l = { pages: [], pageParams: [] },
        a = 0;
      const u = async () => {
        let g = !1;
        const S = (m) => {
            Object.defineProperty(m, "signal", {
              enumerable: !0,
              get: () => (
                t.signal.aborted
                  ? (g = !0)
                  : t.signal.addEventListener("abort", () => {
                      g = !0;
                    }),
                t.signal
              ),
            });
          },
          h = Hm(t.options, t.fetchOptions),
          p = async (m, k, E) => {
            if (g) return Promise.reject();
            if (k == null && m.pages.length) return Promise.resolve(m);
            const b = {
              queryKey: t.queryKey,
              pageParam: k,
              direction: E ? "backward" : "forward",
              meta: t.options.meta,
            };
            S(b);
            const P = await h(b),
              { maxPages: T } = t.options,
              I = E ? sS : iS;
            return {
              pages: I(m.pages, P, T),
              pageParams: I(m.pageParams, k, T),
            };
          };
        if (o && i.length) {
          const m = o === "backward",
            k = m ? xS : Xd,
            E = { pages: i, pageParams: s },
            b = k(r, E);
          l = await p(E, b, m);
        } else {
          const m = e ?? i.length;
          do {
            const k = a === 0 ? s[0] ?? r.initialPageParam : Xd(r, l);
            if (a > 0 && k == null) break;
            (l = await p(l, k)), a++;
          } while (a < m);
        }
        return l;
      };
      t.options.persister
        ? (t.fetchFn = () => {
            var g, S;
            return (S = (g = t.options).persister) == null
              ? void 0
              : S.call(
                  g,
                  u,
                  {
                    queryKey: t.queryKey,
                    meta: t.options.meta,
                    signal: t.signal,
                  },
                  n
                );
          })
        : (t.fetchFn = u);
    },
  };
}
function Xd(e, { pages: t, pageParams: n }) {
  const r = t.length - 1;
  return t.length > 0 ? e.getNextPageParam(t[r], t, n[r], n) : void 0;
}
function xS(e, { pages: t, pageParams: n }) {
  var r;
  return t.length > 0
    ? (r = e.getPreviousPageParam) == null
      ? void 0
      : r.call(e, t[0], t, n[0], n)
    : void 0;
}
var de,
  fn,
  pn,
  Mr,
  Lr,
  hn,
  Ir,
  Dr,
  pf,
  wS =
    ((pf = class {
      constructor(e = {}) {
        q(this, de);
        q(this, fn);
        q(this, pn);
        q(this, Mr);
        q(this, Lr);
        q(this, hn);
        q(this, Ir);
        q(this, Dr);
        V(this, de, e.queryCache || new mS()),
          V(this, fn, e.mutationCache || new yS()),
          V(this, pn, e.defaultOptions || {}),
          V(this, Mr, new Map()),
          V(this, Lr, new Map()),
          V(this, hn, 0);
      }
      mount() {
        ci(this, hn)._++,
          N(this, hn) === 1 &&
            (V(
              this,
              Ir,
              Qm.subscribe(async (e) => {
                e &&
                  (await this.resumePausedMutations(), N(this, de).onFocus());
              })
            ),
            V(
              this,
              Dr,
              Cs.subscribe(async (e) => {
                e &&
                  (await this.resumePausedMutations(), N(this, de).onOnline());
              })
            ));
      }
      unmount() {
        var e, t;
        ci(this, hn)._--,
          N(this, hn) === 0 &&
            ((e = N(this, Ir)) == null || e.call(this),
            V(this, Ir, void 0),
            (t = N(this, Dr)) == null || t.call(this),
            V(this, Dr, void 0));
      }
      isFetching(e) {
        return N(this, de).findAll({ ...e, fetchStatus: "fetching" }).length;
      }
      isMutating(e) {
        return N(this, fn).findAll({ ...e, status: "pending" }).length;
      }
      getQueryData(e) {
        var n;
        const t = this.defaultQueryOptions({ queryKey: e });
        return (n = N(this, de).get(t.queryHash)) == null
          ? void 0
          : n.state.data;
      }
      ensureQueryData(e) {
        const t = this.getQueryData(e.queryKey);
        if (t === void 0) return this.fetchQuery(e);
        {
          const n = this.defaultQueryOptions(e),
            r = N(this, de).build(this, n);
          return (
            e.revalidateIfStale &&
              r.isStaleByTime(Vd(n.staleTime, r)) &&
              this.prefetchQuery(n),
            Promise.resolve(t)
          );
        }
      }
      getQueriesData(e) {
        return N(this, de)
          .findAll(e)
          .map(({ queryKey: t, state: n }) => {
            const r = n.data;
            return [t, r];
          });
      }
      setQueryData(e, t, n) {
        const r = this.defaultQueryOptions({ queryKey: e }),
          o = N(this, de).get(r.queryHash),
          i = o == null ? void 0 : o.state.data,
          s = Z1(t, i);
        if (s !== void 0)
          return N(this, de)
            .build(this, r)
            .setData(s, { ...n, manual: !0 });
      }
      setQueriesData(e, t, n) {
        return Le.batch(() =>
          N(this, de)
            .findAll(e)
            .map(({ queryKey: r }) => [r, this.setQueryData(r, t, n)])
        );
      }
      getQueryState(e) {
        var n;
        const t = this.defaultQueryOptions({ queryKey: e });
        return (n = N(this, de).get(t.queryHash)) == null ? void 0 : n.state;
      }
      removeQueries(e) {
        const t = N(this, de);
        Le.batch(() => {
          t.findAll(e).forEach((n) => {
            t.remove(n);
          });
        });
      }
      resetQueries(e, t) {
        const n = N(this, de),
          r = { type: "active", ...e };
        return Le.batch(
          () => (
            n.findAll(e).forEach((o) => {
              o.reset();
            }),
            this.refetchQueries(r, t)
          )
        );
      }
      cancelQueries(e = {}, t = {}) {
        const n = { revert: !0, ...t },
          r = Le.batch(() =>
            N(this, de)
              .findAll(e)
              .map((o) => o.cancel(n))
          );
        return Promise.all(r).then(dt).catch(dt);
      }
      invalidateQueries(e = {}, t = {}) {
        return Le.batch(() => {
          if (
            (N(this, de)
              .findAll(e)
              .forEach((r) => {
                r.invalidate();
              }),
            e.refetchType === "none")
          )
            return Promise.resolve();
          const n = { ...e, type: e.refetchType ?? e.type ?? "active" };
          return this.refetchQueries(n, t);
        });
      }
      refetchQueries(e = {}, t) {
        const n = {
            ...t,
            cancelRefetch: (t == null ? void 0 : t.cancelRefetch) ?? !0,
          },
          r = Le.batch(() =>
            N(this, de)
              .findAll(e)
              .filter((o) => !o.isDisabled())
              .map((o) => {
                let i = o.fetch(void 0, n);
                return (
                  n.throwOnError || (i = i.catch(dt)),
                  o.state.fetchStatus === "paused" ? Promise.resolve() : i
                );
              })
          );
        return Promise.all(r).then(dt);
      }
      fetchQuery(e) {
        const t = this.defaultQueryOptions(e);
        t.retry === void 0 && (t.retry = !1);
        const n = N(this, de).build(this, t);
        return n.isStaleByTime(Vd(t.staleTime, n))
          ? n.fetch(t)
          : Promise.resolve(n.state.data);
      }
      prefetchQuery(e) {
        return this.fetchQuery(e).then(dt).catch(dt);
      }
      fetchInfiniteQuery(e) {
        return (e.behavior = Yd(e.pages)), this.fetchQuery(e);
      }
      prefetchInfiniteQuery(e) {
        return this.fetchInfiniteQuery(e).then(dt).catch(dt);
      }
      ensureInfiniteQueryData(e) {
        return (e.behavior = Yd(e.pages)), this.ensureQueryData(e);
      }
      resumePausedMutations() {
        return Cs.isOnline()
          ? N(this, fn).resumePausedMutations()
          : Promise.resolve();
      }
      getQueryCache() {
        return N(this, de);
      }
      getMutationCache() {
        return N(this, fn);
      }
      getDefaultOptions() {
        return N(this, pn);
      }
      setDefaultOptions(e) {
        V(this, pn, e);
      }
      setQueryDefaults(e, t) {
        N(this, Mr).set(Ho(e), { queryKey: e, defaultOptions: t });
      }
      getQueryDefaults(e) {
        const t = [...N(this, Mr).values()];
        let n = {};
        return (
          t.forEach((r) => {
            Qo(e, r.queryKey) && (n = { ...n, ...r.defaultOptions });
          }),
          n
        );
      }
      setMutationDefaults(e, t) {
        N(this, Lr).set(Ho(e), { mutationKey: e, defaultOptions: t });
      }
      getMutationDefaults(e) {
        const t = [...N(this, Lr).values()];
        let n = {};
        return (
          t.forEach((r) => {
            Qo(e, r.mutationKey) && (n = { ...n, ...r.defaultOptions });
          }),
          n
        );
      }
      defaultQueryOptions(e) {
        if (e._defaulted) return e;
        const t = {
          ...N(this, pn).queries,
          ...this.getQueryDefaults(e.queryKey),
          ...e,
          _defaulted: !0,
        };
        return (
          t.queryHash || (t.queryHash = rc(t.queryKey, t)),
          t.refetchOnReconnect === void 0 &&
            (t.refetchOnReconnect = t.networkMode !== "always"),
          t.throwOnError === void 0 && (t.throwOnError = !!t.suspense),
          !t.networkMode && t.persister && (t.networkMode = "offlineFirst"),
          t.enabled !== !0 && t.queryFn === oc && (t.enabled = !1),
          t
        );
      }
      defaultMutationOptions(e) {
        return e != null && e._defaulted
          ? e
          : {
              ...N(this, pn).mutations,
              ...((e == null ? void 0 : e.mutationKey) &&
                this.getMutationDefaults(e.mutationKey)),
              ...e,
              _defaulted: !0,
            };
      }
      clear() {
        N(this, de).clear(), N(this, fn).clear();
      }
    }),
    (de = new WeakMap()),
    (fn = new WeakMap()),
    (pn = new WeakMap()),
    (Mr = new WeakMap()),
    (Lr = new WeakMap()),
    (hn = new WeakMap()),
    (Ir = new WeakMap()),
    (Dr = new WeakMap()),
    pf),
  SS = y.createContext(void 0),
  kS = ({ client: e, children: t }) => (
    y.useEffect(
      () => (
        e.mount(),
        () => {
          e.unmount();
        }
      ),
      [e]
    ),
    w.jsx(SS.Provider, { value: e, children: t })
  );
/**
 * @remix-run/router v1.20.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */ function Ko() {
  return (
    (Ko = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)
              Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        }),
    Ko.apply(this, arguments)
  );
}
var vn;
(function (e) {
  (e.Pop = "POP"), (e.Push = "PUSH"), (e.Replace = "REPLACE");
})(vn || (vn = {}));
const qd = "popstate";
function ES(e) {
  e === void 0 && (e = {});
  function t(r, o) {
    let { pathname: i, search: s, hash: l } = r.location;
    return Ha(
      "",
      { pathname: i, search: s, hash: l },
      (o.state && o.state.usr) || null,
      (o.state && o.state.key) || "default"
    );
  }
  function n(r, o) {
    return typeof o == "string" ? o : bs(o);
  }
  return bS(t, n, null, e);
}
function me(e, t) {
  if (e === !1 || e === null || typeof e > "u") throw new Error(t);
}
function qm(e, t) {
  if (!e) {
    typeof console < "u" && console.warn(t);
    try {
      throw new Error(t);
    } catch {}
  }
}
function CS() {
  return Math.random().toString(36).substr(2, 8);
}
function Jd(e, t) {
  return { usr: e.state, key: e.key, idx: t };
}
function Ha(e, t, n, r) {
  return (
    n === void 0 && (n = null),
    Ko(
      { pathname: typeof e == "string" ? e : e.pathname, search: "", hash: "" },
      typeof t == "string" ? Zr(t) : t,
      { state: n, key: (t && t.key) || r || CS() }
    )
  );
}
function bs(e) {
  let { pathname: t = "/", search: n = "", hash: r = "" } = e;
  return (
    n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n),
    r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r),
    t
  );
}
function Zr(e) {
  let t = {};
  if (e) {
    let n = e.indexOf("#");
    n >= 0 && ((t.hash = e.substr(n)), (e = e.substr(0, n)));
    let r = e.indexOf("?");
    r >= 0 && ((t.search = e.substr(r)), (e = e.substr(0, r))),
      e && (t.pathname = e);
  }
  return t;
}
function bS(e, t, n, r) {
  r === void 0 && (r = {});
  let { window: o = document.defaultView, v5Compat: i = !1 } = r,
    s = o.history,
    l = vn.Pop,
    a = null,
    u = d();
  u == null && ((u = 0), s.replaceState(Ko({}, s.state, { idx: u }), ""));
  function d() {
    return (s.state || { idx: null }).idx;
  }
  function f() {
    l = vn.Pop;
    let S = d(),
      h = S == null ? null : S - u;
    (u = S), a && a({ action: l, location: g.location, delta: h });
  }
  function c(S, h) {
    l = vn.Push;
    let p = Ha(g.location, S, h);
    u = d() + 1;
    let m = Jd(p, u),
      k = g.createHref(p);
    try {
      s.pushState(m, "", k);
    } catch (E) {
      if (E instanceof DOMException && E.name === "DataCloneError") throw E;
      o.location.assign(k);
    }
    i && a && a({ action: l, location: g.location, delta: 1 });
  }
  function v(S, h) {
    l = vn.Replace;
    let p = Ha(g.location, S, h);
    u = d();
    let m = Jd(p, u),
      k = g.createHref(p);
    s.replaceState(m, "", k),
      i && a && a({ action: l, location: g.location, delta: 0 });
  }
  function x(S) {
    let h = o.location.origin !== "null" ? o.location.origin : o.location.href,
      p = typeof S == "string" ? S : bs(S);
    return (
      (p = p.replace(/ $/, "%20")),
      me(
        h,
        "No window.location.(origin|href) available to create URL for href: " +
          p
      ),
      new URL(p, h)
    );
  }
  let g = {
    get action() {
      return l;
    },
    get location() {
      return e(o, s);
    },
    listen(S) {
      if (a) throw new Error("A history only accepts one active listener");
      return (
        o.addEventListener(qd, f),
        (a = S),
        () => {
          o.removeEventListener(qd, f), (a = null);
        }
      );
    },
    createHref(S) {
      return t(o, S);
    },
    createURL: x,
    encodeLocation(S) {
      let h = x(S);
      return { pathname: h.pathname, search: h.search, hash: h.hash };
    },
    push: c,
    replace: v,
    go(S) {
      return s.go(S);
    },
  };
  return g;
}
var Zd;
(function (e) {
  (e.data = "data"),
    (e.deferred = "deferred"),
    (e.redirect = "redirect"),
    (e.error = "error");
})(Zd || (Zd = {}));
function PS(e, t, n) {
  return n === void 0 && (n = "/"), NS(e, t, n, !1);
}
function NS(e, t, n, r) {
  let o = typeof t == "string" ? Zr(t) : t,
    i = ic(o.pathname || "/", n);
  if (i == null) return null;
  let s = Jm(e);
  TS(s);
  let l = null;
  for (let a = 0; l == null && a < s.length; ++a) {
    let u = FS(i);
    l = DS(s[a], u, r);
  }
  return l;
}
function Jm(e, t, n, r) {
  t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = "");
  let o = (i, s, l) => {
    let a = {
      relativePath: l === void 0 ? i.path || "" : l,
      caseSensitive: i.caseSensitive === !0,
      childrenIndex: s,
      route: i,
    };
    a.relativePath.startsWith("/") &&
      (me(
        a.relativePath.startsWith(r),
        'Absolute route path "' +
          a.relativePath +
          '" nested under path ' +
          ('"' + r + '" is not valid. An absolute child route path ') +
          "must start with the combined path of all its parent routes."
      ),
      (a.relativePath = a.relativePath.slice(r.length)));
    let u = Pn([r, a.relativePath]),
      d = n.concat(a);
    i.children &&
      i.children.length > 0 &&
      (me(
        i.index !== !0,
        "Index routes must not have child routes. Please remove " +
          ('all child routes from route path "' + u + '".')
      ),
      Jm(i.children, t, d, u)),
      !(i.path == null && !i.index) &&
        t.push({ path: u, score: LS(u, i.index), routesMeta: d });
  };
  return (
    e.forEach((i, s) => {
      var l;
      if (i.path === "" || !((l = i.path) != null && l.includes("?"))) o(i, s);
      else for (let a of Zm(i.path)) o(i, s, a);
    }),
    t
  );
}
function Zm(e) {
  let t = e.split("/");
  if (t.length === 0) return [];
  let [n, ...r] = t,
    o = n.endsWith("?"),
    i = n.replace(/\?$/, "");
  if (r.length === 0) return o ? [i, ""] : [i];
  let s = Zm(r.join("/")),
    l = [];
  return (
    l.push(...s.map((a) => (a === "" ? i : [i, a].join("/")))),
    o && l.push(...s),
    l.map((a) => (e.startsWith("/") && a === "" ? "/" : a))
  );
}
function TS(e) {
  e.sort((t, n) =>
    t.score !== n.score
      ? n.score - t.score
      : IS(
          t.routesMeta.map((r) => r.childrenIndex),
          n.routesMeta.map((r) => r.childrenIndex)
        )
  );
}
const RS = /^:[\w-]+$/,
  AS = 3,
  jS = 2,
  _S = 1,
  OS = 10,
  MS = -2,
  ef = (e) => e === "*";
function LS(e, t) {
  let n = e.split("/"),
    r = n.length;
  return (
    n.some(ef) && (r += MS),
    t && (r += jS),
    n
      .filter((o) => !ef(o))
      .reduce((o, i) => o + (RS.test(i) ? AS : i === "" ? _S : OS), r)
  );
}
function IS(e, t) {
  return e.length === t.length && e.slice(0, -1).every((r, o) => r === t[o])
    ? e[e.length - 1] - t[t.length - 1]
    : 0;
}
function DS(e, t, n) {
  let { routesMeta: r } = e,
    o = {},
    i = "/",
    s = [];
  for (let l = 0; l < r.length; ++l) {
    let a = r[l],
      u = l === r.length - 1,
      d = i === "/" ? t : t.slice(i.length) || "/",
      f = tf(
        { path: a.relativePath, caseSensitive: a.caseSensitive, end: u },
        d
      ),
      c = a.route;
    if (
      (!f &&
        u &&
        n &&
        !r[r.length - 1].route.index &&
        (f = tf(
          { path: a.relativePath, caseSensitive: a.caseSensitive, end: !1 },
          d
        )),
      !f)
    )
      return null;
    Object.assign(o, f.params),
      s.push({
        params: o,
        pathname: Pn([i, f.pathname]),
        pathnameBase: WS(Pn([i, f.pathnameBase])),
        route: c,
      }),
      f.pathnameBase !== "/" && (i = Pn([i, f.pathnameBase]));
  }
  return s;
}
function tf(e, t) {
  typeof e == "string" && (e = { path: e, caseSensitive: !1, end: !0 });
  let [n, r] = zS(e.path, e.caseSensitive, e.end),
    o = t.match(n);
  if (!o) return null;
  let i = o[0],
    s = i.replace(/(.)\/+$/, "$1"),
    l = o.slice(1);
  return {
    params: r.reduce((u, d, f) => {
      let { paramName: c, isOptional: v } = d;
      if (c === "*") {
        let g = l[f] || "";
        s = i.slice(0, i.length - g.length).replace(/(.)\/+$/, "$1");
      }
      const x = l[f];
      return (
        v && !x ? (u[c] = void 0) : (u[c] = (x || "").replace(/%2F/g, "/")), u
      );
    }, {}),
    pathname: i,
    pathnameBase: s,
    pattern: e,
  };
}
function zS(e, t, n) {
  t === void 0 && (t = !1),
    n === void 0 && (n = !0),
    qm(
      e === "*" || !e.endsWith("*") || e.endsWith("/*"),
      'Route path "' +
        e +
        '" will be treated as if it were ' +
        ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') +
        "always follow a `/` in the pattern. To get rid of this warning, " +
        ('please change the route path to "' + e.replace(/\*$/, "/*") + '".')
    );
  let r = [],
    o =
      "^" +
      e
        .replace(/\/*\*?$/, "")
        .replace(/^\/*/, "/")
        .replace(/[\\.*+^${}|()[\]]/g, "\\$&")
        .replace(
          /\/:([\w-]+)(\?)?/g,
          (s, l, a) => (
            r.push({ paramName: l, isOptional: a != null }),
            a ? "/?([^\\/]+)?" : "/([^\\/]+)"
          )
        );
  return (
    e.endsWith("*")
      ? (r.push({ paramName: "*" }),
        (o += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$"))
      : n
      ? (o += "\\/*$")
      : e !== "" && e !== "/" && (o += "(?:(?=\\/|$))"),
    [new RegExp(o, t ? void 0 : "i"), r]
  );
}
function FS(e) {
  try {
    return e
      .split("/")
      .map((t) => decodeURIComponent(t).replace(/\//g, "%2F"))
      .join("/");
  } catch (t) {
    return (
      qm(
        !1,
        'The URL path "' +
          e +
          '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' +
          ("encoding (" + t + ").")
      ),
      e
    );
  }
}
function ic(e, t) {
  if (t === "/") return e;
  if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
  let n = t.endsWith("/") ? t.length - 1 : t.length,
    r = e.charAt(n);
  return r && r !== "/" ? null : e.slice(n) || "/";
}
function $S(e, t) {
  t === void 0 && (t = "/");
  let {
    pathname: n,
    search: r = "",
    hash: o = "",
  } = typeof e == "string" ? Zr(e) : e;
  return {
    pathname: n ? (n.startsWith("/") ? n : US(n, t)) : t,
    search: VS(r),
    hash: HS(o),
  };
}
function US(e, t) {
  let n = t.replace(/\/+$/, "").split("/");
  return (
    e.split("/").forEach((o) => {
      o === ".." ? n.length > 1 && n.pop() : o !== "." && n.push(o);
    }),
    n.length > 1 ? n.join("/") : "/"
  );
}
function Fl(e, t, n, r) {
  return (
    "Cannot include a '" +
    e +
    "' character in a manually specified " +
    ("`to." +
      t +
      "` field [" +
      JSON.stringify(r) +
      "].  Please separate it out to the ") +
    ("`to." + n + "` field. Alternatively you may provide the full path as ") +
    'a string in <Link to="..."> and the router will parse it for you.'
  );
}
function BS(e) {
  return e.filter(
    (t, n) => n === 0 || (t.route.path && t.route.path.length > 0)
  );
}
function eg(e, t) {
  let n = BS(e);
  return t
    ? n.map((r, o) => (o === n.length - 1 ? r.pathname : r.pathnameBase))
    : n.map((r) => r.pathnameBase);
}
function tg(e, t, n, r) {
  r === void 0 && (r = !1);
  let o;
  typeof e == "string"
    ? (o = Zr(e))
    : ((o = Ko({}, e)),
      me(
        !o.pathname || !o.pathname.includes("?"),
        Fl("?", "pathname", "search", o)
      ),
      me(
        !o.pathname || !o.pathname.includes("#"),
        Fl("#", "pathname", "hash", o)
      ),
      me(!o.search || !o.search.includes("#"), Fl("#", "search", "hash", o)));
  let i = e === "" || o.pathname === "",
    s = i ? "/" : o.pathname,
    l;
  if (s == null) l = n;
  else {
    let f = t.length - 1;
    if (!r && s.startsWith("..")) {
      let c = s.split("/");
      for (; c[0] === ".."; ) c.shift(), (f -= 1);
      o.pathname = c.join("/");
    }
    l = f >= 0 ? t[f] : "/";
  }
  let a = $S(o, l),
    u = s && s !== "/" && s.endsWith("/"),
    d = (i || s === ".") && n.endsWith("/");
  return !a.pathname.endsWith("/") && (u || d) && (a.pathname += "/"), a;
}
const Pn = (e) => e.join("/").replace(/\/\/+/g, "/"),
  WS = (e) => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
  VS = (e) => (!e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e),
  HS = (e) => (!e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e);
function QS(e) {
  return (
    e != null &&
    typeof e.status == "number" &&
    typeof e.statusText == "string" &&
    typeof e.internal == "boolean" &&
    "data" in e
  );
}
const ng = ["post", "put", "patch", "delete"];
new Set(ng);
const KS = ["get", ...ng];
new Set(KS);
/**
 * React Router v6.27.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */ function Go() {
  return (
    (Go = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)
              Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        }),
    Go.apply(this, arguments)
  );
}
const sc = y.createContext(null),
  GS = y.createContext(null),
  nr = y.createContext(null),
  Zs = y.createContext(null),
  rr = y.createContext({ outlet: null, matches: [], isDataRoute: !1 }),
  rg = y.createContext(null);
function YS(e, t) {
  let { relative: n } = t === void 0 ? {} : t;
  oi() || me(!1);
  let { basename: r, navigator: o } = y.useContext(nr),
    { hash: i, pathname: s, search: l } = ig(e, { relative: n }),
    a = s;
  return (
    r !== "/" && (a = s === "/" ? r : Pn([r, s])),
    o.createHref({ pathname: a, search: l, hash: i })
  );
}
function oi() {
  return y.useContext(Zs) != null;
}
function ii() {
  return oi() || me(!1), y.useContext(Zs).location;
}
function og(e) {
  y.useContext(nr).static || y.useLayoutEffect(e);
}
function XS() {
  let { isDataRoute: e } = y.useContext(rr);
  return e ? uk() : qS();
}
function qS() {
  oi() || me(!1);
  let e = y.useContext(sc),
    { basename: t, future: n, navigator: r } = y.useContext(nr),
    { matches: o } = y.useContext(rr),
    { pathname: i } = ii(),
    s = JSON.stringify(eg(o, n.v7_relativeSplatPath)),
    l = y.useRef(!1);
  return (
    og(() => {
      l.current = !0;
    }),
    y.useCallback(
      function (u, d) {
        if ((d === void 0 && (d = {}), !l.current)) return;
        if (typeof u == "number") {
          r.go(u);
          return;
        }
        let f = tg(u, JSON.parse(s), i, d.relative === "path");
        e == null &&
          t !== "/" &&
          (f.pathname = f.pathname === "/" ? t : Pn([t, f.pathname])),
          (d.replace ? r.replace : r.push)(f, d.state, d);
      },
      [t, r, s, i, e]
    )
  );
}
function ig(e, t) {
  let { relative: n } = t === void 0 ? {} : t,
    { future: r } = y.useContext(nr),
    { matches: o } = y.useContext(rr),
    { pathname: i } = ii(),
    s = JSON.stringify(eg(o, r.v7_relativeSplatPath));
  return y.useMemo(() => tg(e, JSON.parse(s), i, n === "path"), [e, s, i, n]);
}
function JS(e, t) {
  return ZS(e, t);
}
function ZS(e, t, n, r) {
  oi() || me(!1);
  let { navigator: o } = y.useContext(nr),
    { matches: i } = y.useContext(rr),
    s = i[i.length - 1],
    l = s ? s.params : {};
  s && s.pathname;
  let a = s ? s.pathnameBase : "/";
  s && s.route;
  let u = ii(),
    d;
  if (t) {
    var f;
    let S = typeof t == "string" ? Zr(t) : t;
    a === "/" || ((f = S.pathname) != null && f.startsWith(a)) || me(!1),
      (d = S);
  } else d = u;
  let c = d.pathname || "/",
    v = c;
  if (a !== "/") {
    let S = a.replace(/^\//, "").split("/");
    v = "/" + c.replace(/^\//, "").split("/").slice(S.length).join("/");
  }
  let x = PS(e, { pathname: v }),
    g = ok(
      x &&
        x.map((S) =>
          Object.assign({}, S, {
            params: Object.assign({}, l, S.params),
            pathname: Pn([
              a,
              o.encodeLocation
                ? o.encodeLocation(S.pathname).pathname
                : S.pathname,
            ]),
            pathnameBase:
              S.pathnameBase === "/"
                ? a
                : Pn([
                    a,
                    o.encodeLocation
                      ? o.encodeLocation(S.pathnameBase).pathname
                      : S.pathnameBase,
                  ]),
          })
        ),
      i,
      n,
      r
    );
  return t && g
    ? y.createElement(
        Zs.Provider,
        {
          value: {
            location: Go(
              {
                pathname: "/",
                search: "",
                hash: "",
                state: null,
                key: "default",
              },
              d
            ),
            navigationType: vn.Pop,
          },
        },
        g
      )
    : g;
}
function ek() {
  let e = ak(),
    t = QS(e)
      ? e.status + " " + e.statusText
      : e instanceof Error
      ? e.message
      : JSON.stringify(e),
    n = e instanceof Error ? e.stack : null,
    o = { padding: "0.5rem", backgroundColor: "rgba(200,200,200, 0.5)" };
  return y.createElement(
    y.Fragment,
    null,
    y.createElement("h2", null, "Unexpected Application Error!"),
    y.createElement("h3", { style: { fontStyle: "italic" } }, t),
    n ? y.createElement("pre", { style: o }, n) : null,
    null
  );
}
const tk = y.createElement(ek, null);
class nk extends y.Component {
  constructor(t) {
    super(t),
      (this.state = {
        location: t.location,
        revalidation: t.revalidation,
        error: t.error,
      });
  }
  static getDerivedStateFromError(t) {
    return { error: t };
  }
  static getDerivedStateFromProps(t, n) {
    return n.location !== t.location ||
      (n.revalidation !== "idle" && t.revalidation === "idle")
      ? { error: t.error, location: t.location, revalidation: t.revalidation }
      : {
          error: t.error !== void 0 ? t.error : n.error,
          location: n.location,
          revalidation: t.revalidation || n.revalidation,
        };
  }
  componentDidCatch(t, n) {
    console.error(
      "React Router caught the following error during render",
      t,
      n
    );
  }
  render() {
    return this.state.error !== void 0
      ? y.createElement(
          rr.Provider,
          { value: this.props.routeContext },
          y.createElement(rg.Provider, {
            value: this.state.error,
            children: this.props.component,
          })
        )
      : this.props.children;
  }
}
function rk(e) {
  let { routeContext: t, match: n, children: r } = e,
    o = y.useContext(sc);
  return (
    o &&
      o.static &&
      o.staticContext &&
      (n.route.errorElement || n.route.ErrorBoundary) &&
      (o.staticContext._deepestRenderedBoundaryId = n.route.id),
    y.createElement(rr.Provider, { value: t }, r)
  );
}
function ok(e, t, n, r) {
  var o;
  if (
    (t === void 0 && (t = []),
    n === void 0 && (n = null),
    r === void 0 && (r = null),
    e == null)
  ) {
    var i;
    if (!n) return null;
    if (n.errors) e = n.matches;
    else if (
      (i = r) != null &&
      i.v7_partialHydration &&
      t.length === 0 &&
      !n.initialized &&
      n.matches.length > 0
    )
      e = n.matches;
    else return null;
  }
  let s = e,
    l = (o = n) == null ? void 0 : o.errors;
  if (l != null) {
    let d = s.findIndex(
      (f) => f.route.id && (l == null ? void 0 : l[f.route.id]) !== void 0
    );
    d >= 0 || me(!1), (s = s.slice(0, Math.min(s.length, d + 1)));
  }
  let a = !1,
    u = -1;
  if (n && r && r.v7_partialHydration)
    for (let d = 0; d < s.length; d++) {
      let f = s[d];
      if (
        ((f.route.HydrateFallback || f.route.hydrateFallbackElement) && (u = d),
        f.route.id)
      ) {
        let { loaderData: c, errors: v } = n,
          x =
            f.route.loader &&
            c[f.route.id] === void 0 &&
            (!v || v[f.route.id] === void 0);
        if (f.route.lazy || x) {
          (a = !0), u >= 0 ? (s = s.slice(0, u + 1)) : (s = [s[0]]);
          break;
        }
      }
    }
  return s.reduceRight((d, f, c) => {
    let v,
      x = !1,
      g = null,
      S = null;
    n &&
      ((v = l && f.route.id ? l[f.route.id] : void 0),
      (g = f.route.errorElement || tk),
      a &&
        (u < 0 && c === 0
          ? ((x = !0), (S = null))
          : u === c &&
            ((x = !0), (S = f.route.hydrateFallbackElement || null))));
    let h = t.concat(s.slice(0, c + 1)),
      p = () => {
        let m;
        return (
          v
            ? (m = g)
            : x
            ? (m = S)
            : f.route.Component
            ? (m = y.createElement(f.route.Component, null))
            : f.route.element
            ? (m = f.route.element)
            : (m = d),
          y.createElement(rk, {
            match: f,
            routeContext: { outlet: d, matches: h, isDataRoute: n != null },
            children: m,
          })
        );
      };
    return n && (f.route.ErrorBoundary || f.route.errorElement || c === 0)
      ? y.createElement(nk, {
          location: n.location,
          revalidation: n.revalidation,
          component: g,
          error: v,
          children: p(),
          routeContext: { outlet: null, matches: h, isDataRoute: !0 },
        })
      : p();
  }, null);
}
var sg = (function (e) {
    return (
      (e.UseBlocker = "useBlocker"),
      (e.UseRevalidator = "useRevalidator"),
      (e.UseNavigateStable = "useNavigate"),
      e
    );
  })(sg || {}),
  Ps = (function (e) {
    return (
      (e.UseBlocker = "useBlocker"),
      (e.UseLoaderData = "useLoaderData"),
      (e.UseActionData = "useActionData"),
      (e.UseRouteError = "useRouteError"),
      (e.UseNavigation = "useNavigation"),
      (e.UseRouteLoaderData = "useRouteLoaderData"),
      (e.UseMatches = "useMatches"),
      (e.UseRevalidator = "useRevalidator"),
      (e.UseNavigateStable = "useNavigate"),
      (e.UseRouteId = "useRouteId"),
      e
    );
  })(Ps || {});
function ik(e) {
  let t = y.useContext(sc);
  return t || me(!1), t;
}
function sk(e) {
  let t = y.useContext(GS);
  return t || me(!1), t;
}
function lk(e) {
  let t = y.useContext(rr);
  return t || me(!1), t;
}
function lg(e) {
  let t = lk(),
    n = t.matches[t.matches.length - 1];
  return n.route.id || me(!1), n.route.id;
}
function ak() {
  var e;
  let t = y.useContext(rg),
    n = sk(Ps.UseRouteError),
    r = lg(Ps.UseRouteError);
  return t !== void 0 ? t : (e = n.errors) == null ? void 0 : e[r];
}
function uk() {
  let { router: e } = ik(sg.UseNavigateStable),
    t = lg(Ps.UseNavigateStable),
    n = y.useRef(!1);
  return (
    og(() => {
      n.current = !0;
    }),
    y.useCallback(
      function (o, i) {
        i === void 0 && (i = {}),
          n.current &&
            (typeof o == "number"
              ? e.navigate(o)
              : e.navigate(o, Go({ fromRouteId: t }, i)));
      },
      [e, t]
    )
  );
}
function Gi(e) {
  me(!1);
}
function ck(e) {
  let {
    basename: t = "/",
    children: n = null,
    location: r,
    navigationType: o = vn.Pop,
    navigator: i,
    static: s = !1,
    future: l,
  } = e;
  oi() && me(!1);
  let a = t.replace(/^\/*/, "/"),
    u = y.useMemo(
      () => ({
        basename: a,
        navigator: i,
        static: s,
        future: Go({ v7_relativeSplatPath: !1 }, l),
      }),
      [a, l, i, s]
    );
  typeof r == "string" && (r = Zr(r));
  let {
      pathname: d = "/",
      search: f = "",
      hash: c = "",
      state: v = null,
      key: x = "default",
    } = r,
    g = y.useMemo(() => {
      let S = ic(d, a);
      return S == null
        ? null
        : {
            location: { pathname: S, search: f, hash: c, state: v, key: x },
            navigationType: o,
          };
    }, [a, d, f, c, v, x, o]);
  return g == null
    ? null
    : y.createElement(
        nr.Provider,
        { value: u },
        y.createElement(Zs.Provider, { children: n, value: g })
      );
}
function dk(e) {
  let { children: t, location: n } = e;
  return JS(Qa(t), n);
}
new Promise(() => {});
function Qa(e, t) {
  t === void 0 && (t = []);
  let n = [];
  return (
    y.Children.forEach(e, (r, o) => {
      if (!y.isValidElement(r)) return;
      let i = [...t, o];
      if (r.type === y.Fragment) {
        n.push.apply(n, Qa(r.props.children, i));
        return;
      }
      r.type !== Gi && me(!1), !r.props.index || !r.props.children || me(!1);
      let s = {
        id: r.props.id || i.join("-"),
        caseSensitive: r.props.caseSensitive,
        element: r.props.element,
        Component: r.props.Component,
        index: r.props.index,
        path: r.props.path,
        loader: r.props.loader,
        action: r.props.action,
        errorElement: r.props.errorElement,
        ErrorBoundary: r.props.ErrorBoundary,
        hasErrorBoundary:
          r.props.ErrorBoundary != null || r.props.errorElement != null,
        shouldRevalidate: r.props.shouldRevalidate,
        handle: r.props.handle,
        lazy: r.props.lazy,
      };
      r.props.children && (s.children = Qa(r.props.children, i)), n.push(s);
    }),
    n
  );
}
/**
 * React Router DOM v6.27.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */ function Ka() {
  return (
    (Ka = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)
              Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        }),
    Ka.apply(this, arguments)
  );
}
function fk(e, t) {
  if (e == null) return {};
  var n = {},
    r = Object.keys(e),
    o,
    i;
  for (i = 0; i < r.length; i++)
    (o = r[i]), !(t.indexOf(o) >= 0) && (n[o] = e[o]);
  return n;
}
function pk(e) {
  return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey);
}
function hk(e, t) {
  return e.button === 0 && (!t || t === "_self") && !pk(e);
}
const mk = [
    "onClick",
    "relative",
    "reloadDocument",
    "replace",
    "state",
    "target",
    "to",
    "preventScrollReset",
    "viewTransition",
  ],
  gk = "6";
try {
  window.__reactRouterVersion = gk;
} catch {}
const vk = "startTransition",
  nf = Hg[vk];
function yk(e) {
  let { basename: t, children: n, future: r, window: o } = e,
    i = y.useRef();
  i.current == null && (i.current = ES({ window: o, v5Compat: !0 }));
  let s = i.current,
    [l, a] = y.useState({ action: s.action, location: s.location }),
    { v7_startTransition: u } = r || {},
    d = y.useCallback(
      (f) => {
        u && nf ? nf(() => a(f)) : a(f);
      },
      [a, u]
    );
  return (
    y.useLayoutEffect(() => s.listen(d), [s, d]),
    y.createElement(ck, {
      basename: t,
      children: n,
      location: l.location,
      navigationType: l.action,
      navigator: s,
      future: r,
    })
  );
}
const xk =
    typeof window < "u" &&
    typeof window.document < "u" &&
    typeof window.document.createElement < "u",
  wk = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
  ag = y.forwardRef(function (t, n) {
    let {
        onClick: r,
        relative: o,
        reloadDocument: i,
        replace: s,
        state: l,
        target: a,
        to: u,
        preventScrollReset: d,
        viewTransition: f,
      } = t,
      c = fk(t, mk),
      { basename: v } = y.useContext(nr),
      x,
      g = !1;
    if (typeof u == "string" && wk.test(u) && ((x = u), xk))
      try {
        let m = new URL(window.location.href),
          k = u.startsWith("//") ? new URL(m.protocol + u) : new URL(u),
          E = ic(k.pathname, v);
        k.origin === m.origin && E != null
          ? (u = E + k.search + k.hash)
          : (g = !0);
      } catch {}
    let S = YS(u, { relative: o }),
      h = Sk(u, {
        replace: s,
        state: l,
        target: a,
        preventScrollReset: d,
        relative: o,
        viewTransition: f,
      });
    function p(m) {
      r && r(m), m.defaultPrevented || h(m);
    }
    return y.createElement(
      "a",
      Ka({}, c, { href: x || S, onClick: g || i ? r : p, ref: n, target: a })
    );
  });
var rf;
(function (e) {
  (e.UseScrollRestoration = "useScrollRestoration"),
    (e.UseSubmit = "useSubmit"),
    (e.UseSubmitFetcher = "useSubmitFetcher"),
    (e.UseFetcher = "useFetcher"),
    (e.useViewTransitionState = "useViewTransitionState");
})(rf || (rf = {}));
var of;
(function (e) {
  (e.UseFetcher = "useFetcher"),
    (e.UseFetchers = "useFetchers"),
    (e.UseScrollRestoration = "useScrollRestoration");
})(of || (of = {}));
function Sk(e, t) {
  let {
      target: n,
      replace: r,
      state: o,
      preventScrollReset: i,
      relative: s,
      viewTransition: l,
    } = t === void 0 ? {} : t,
    a = XS(),
    u = ii(),
    d = ig(e, { relative: s });
  return y.useCallback(
    (f) => {
      if (hk(f, n)) {
        f.preventDefault();
        let c = r !== void 0 ? r : bs(u) === bs(d);
        a(e, {
          replace: c,
          state: o,
          preventScrollReset: i,
          relative: s,
          viewTransition: l,
        });
      }
    },
    [u, a, d, r, o, n, e, i, s, l]
  );
}
var lc = "Avatar",
  [kk, Wk] = Bu(lc),
  [Ek, ug] = kk(lc),
  cg = y.forwardRef((e, t) => {
    const { __scopeAvatar: n, ...r } = e,
      [o, i] = y.useState("idle");
    return w.jsx(Ek, {
      scope: n,
      imageLoadingStatus: o,
      onImageLoadingStatusChange: i,
      children: w.jsx(be.span, { ...r, ref: t }),
    });
  });
cg.displayName = lc;
var dg = "AvatarImage",
  fg = y.forwardRef((e, t) => {
    const {
        __scopeAvatar: n,
        src: r,
        onLoadingStatusChange: o = () => {},
        ...i
      } = e,
      s = ug(dg, n),
      l = Ck(r, i.referrerPolicy),
      a = xt((u) => {
        o(u), s.onImageLoadingStatusChange(u);
      });
    return (
      Qt(() => {
        l !== "idle" && a(l);
      }, [l, a]),
      l === "loaded" ? w.jsx(be.img, { ...i, ref: t, src: r }) : null
    );
  });
fg.displayName = dg;
var pg = "AvatarFallback",
  hg = y.forwardRef((e, t) => {
    const { __scopeAvatar: n, delayMs: r, ...o } = e,
      i = ug(pg, n),
      [s, l] = y.useState(r === void 0);
    return (
      y.useEffect(() => {
        if (r !== void 0) {
          const a = window.setTimeout(() => l(!0), r);
          return () => window.clearTimeout(a);
        }
      }, [r]),
      s && i.imageLoadingStatus !== "loaded"
        ? w.jsx(be.span, { ...o, ref: t })
        : null
    );
  });
hg.displayName = pg;
function Ck(e, t) {
  const [n, r] = y.useState("idle");
  return (
    Qt(() => {
      if (!e) {
        r("error");
        return;
      }
      let o = !0;
      const i = new window.Image(),
        s = (l) => () => {
          o && r(l);
        };
      return (
        r("loading"),
        (i.onload = s("loaded")),
        (i.onerror = s("error")),
        (i.src = e),
        t && (i.referrerPolicy = t),
        () => {
          o = !1;
        }
      );
    }, [e, t]),
    n
  );
}
var mg = cg,
  gg = fg,
  vg = hg;
const yg = y.forwardRef(({ className: e, ...t }, n) =>
  w.jsx(mg, {
    ref: n,
    className: Ot(
      "relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full",
      e
    ),
    ...t,
  })
);
yg.displayName = mg.displayName;
const xg = y.forwardRef(({ className: e, ...t }, n) =>
  w.jsx(gg, { ref: n, className: Ot("aspect-square h-full w-full", e), ...t })
);
xg.displayName = gg.displayName;
const wg = y.forwardRef(({ className: e, ...t }, n) =>
  w.jsx(vg, {
    ref: n,
    className: Ot(
      "flex h-full w-full items-center justify-center rounded-full bg-muted",
      e
    ),
    ...t,
  })
);
wg.displayName = vg.displayName;
const bk = () =>
    w.jsx("section", {
      className: "min-h-screen flex items-center justify-center px-4 py-20",
      children: w.jsxs("div", {
        className: "text-center max-w-4xl mx-auto",
        children: [
          w.jsx("div", {
            className: "mb-8 flex justify-center",
            children: w.jsxs(yg, {
              className:
                "w-32 h-32 md:w-40 md:h-40 border-4 border-blue-600 shadow-lg",
              children: [
                w.jsx(xg, {
                  src: "/lovable-uploads/c0d5e8c6-c08b-44fd-bee8-1b56cd149c9d.png",
                  alt: "Atul Kr Prasad",
                  className: "object-cover scale-110",
                }),
                w.jsx(wg, {
                  className: "text-2xl font-bold bg-blue-100 text-blue-800",
                  children: "AKP",
                }),
              ],
            }),
          }),
          w.jsx("h1", {
            className:
              "text-5xl md:text-7xl font-bold text-gray-800 dark:text-white mb-6 animate-fade-in",
            children: "Atul Kr Prasad",
          }),
          w.jsx("div", {
            className:
              "text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-4",
            children: w.jsx("p", { children: "Data Science" }),
          }),
          w.jsxs("div", {
            className:
              "flex items-center justify-center text-gray-500 dark:text-gray-400 mb-8",
            children: [
              w.jsx(ax, { className: "w-5 h-5 mr-2" }),
              w.jsx("span", { children: "Kolkata, India" }),
            ],
          }),
          w.jsxs("div", {
            className: "flex flex-wrap gap-4 justify-center mb-8",
            children: [
              w.jsxs("a", {
                href: "/resume.pdf",
                download: !0,
                className:
                  "flex items-center gap-2 px-6 py-3 border border-amber-300 rounded-lg text-amber-800 hover:bg-amber-50 transition-colors shadow-sm",
                children: [w.jsx(ox, { className: "w-4 h-4" }), "Resume"],
              }),
              w.jsx("a", {
                href: "https://www.linkedin.com/in/atul-kr-prasad-515835266",
                target: "_blank",
                rel: "noopener noreferrer",
                className:
                  "p-3 border border-amber-300 rounded-lg text-amber-800 hover:bg-amber-50 transition-colors shadow-sm",
                children: w.jsx(im, { className: "w-5 h-5" }),
              }),
              w.jsx("a", {
                href: "mailto:atulkumarprasad62@gmail.com",
                className:
                  "p-3 border border-amber-300 rounded-lg text-amber-800 hover:bg-amber-50 transition-colors shadow-sm",
                children: w.jsx(sm, { className: "w-5 h-5" }),
              }),
              w.jsx("a", {
                href: "https://github.com/KrAtulHub",
                target: "_blank",
                rel: "noopener noreferrer",
                className:
                  "p-3 border border-amber-300 rounded-lg text-amber-800 hover:bg-amber-50 transition-colors shadow-sm",
                children: w.jsx(om, { className: "w-5 h-5" }),
              }),
            ],
          }),
        ],
      }),
    }),
  Pk = () => {
    const [e, t] = y.useState("work"),
      o =
        e === "work"
          ? [
              {
                company: "Agilite",
                role: "Senior Software Developer",
                period: "Oct 2023 - Feb 2024",
                logo: "🚀",
              },
              {
                company: "MeasureUp",
                role: "Freelancer",
                period: "June 2023 - July 2023",
                logo: "📊",
              },
              {
                company: "Maximi Labs",
                role: "Senior Software Developer",
                period: "Oct 2021 - Jul 2022",
                logo: "⚡",
              },
              {
                company: "Oracle Solution Services (India)",
                role: "Staff Consultant",
                period: "Aug 2018 - Jul 2021",
                logo: "🔴",
              },
              {
                company: "Unified Mentor Pvt. Ltd",
                role: "Data Science Intern",
                period: "Jun 2025 - July 2025",
                logo: "/lovable-uploads/42862951-9d4b-441a-a947-43ca569b410a.png",
              },
            ]
          : [
              {
                institution: "B.P.Poddar Institute of Management Technology",
                degree: "Bachelor in Computer Application",
                period: "2023 - 2027",
                logo: "/lovable-uploads/b34325a1-777d-4a59-9119-ed32a911fca1.png",
              },
              {
                institution: "Aditya Birla Vani Bharti",
                degree: "Higher Secondary Education",
                period: "2020 - 2022",
                logo: "/lovable-uploads/9126d2f5-85a9-4452-b5a3-2fc1e2f89dd9.png",
              },
            ];
    return w.jsx("section", {
      className: "py-20 px-4",
      children: w.jsxs("div", {
        className: "max-w-6xl mx-auto",
        children: [
          w.jsx("div", {
            className: "flex justify-center mb-12",
            children: w.jsxs("div", {
              className:
                "flex bg-gradient-to-br from-amber-50 to-orange-100 dark:bg-white rounded-lg p-2 shadow-lg border border-gray-200 dark:border-gray-700",
              children: [
                w.jsx("button", {
                  onClick: () => t("work"),
                  className: `px-6 py-2 rounded-lg font-medium transition-colors ${
                    e === "work"
                      ? "bg-orange-500 text-white"
                      : "text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white"
                  }`,
                  children: "Work",
                }),
                w.jsx("button", {
                  onClick: () => t("education"),
                  className: `px-6 py-2 rounded-lg font-medium transition-colors ${
                    e === "education"
                      ? "bg-orange-500 text-white"
                      : "text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white"
                  }`,
                  children: "Education",
                }),
              ],
            }),
          }),
          w.jsx("div", {
            className: "max-w-4xl mx-auto",
            children: w.jsxs("div", {
              className: "relative",
              children: [
                w.jsx("div", {
                  className:
                    "absolute left-8 top-0 bottom-0 w-px bg-gray-300 dark:bg-gray-700",
                }),
                o.map((i, s) =>
                  w.jsxs(
                    "div",
                    {
                      className: "relative flex items-start mb-12 last:mb-0",
                      children: [
                        w.jsx("div", {
                          className:
                            "flex-shrink-0 w-16 h-16 bg-gradient-to-br from-amber-50 to-orange-100 dark:bg-white rounded-full flex items-center justify-center text-2xl border-4 border-orange-200 dark:border-gray-900 shadow-lg overflow-hidden",
                          children: i.logo.startsWith("/")
                            ? w.jsx("img", {
                                src: i.logo,
                                alt: i.company || i.institution,
                                className: "w-full h-full object-cover",
                              })
                            : i.logo,
                        }),
                        w.jsxs("div", {
                          className: "ml-8 flex-grow",
                          children: [
                            w.jsx("div", {
                              className:
                                "text-sm text-orange-600 dark:text-gray-400 mb-1 font-medium",
                              children: i.period,
                            }),
                            w.jsx("h3", {
                              className:
                                "text-xl font-semibold text-gray-800 dark:text-white mb-1",
                              children:
                                e === "work" ? i.company : i.institution,
                            }),
                            w.jsx("p", {
                              className: "text-gray-600 dark:text-gray-300",
                              children: e === "work" ? i.role : i.degree,
                            }),
                          ],
                        }),
                      ],
                    },
                    s
                  )
                ),
              ],
            }),
          }),
        ],
      }),
    });
  },
  Nk = () => {
    const e = [
      {
        name: "PYTHON",
        color: "bg-gradient-to-r from-blue-500 to-blue-600",
        textColor: "text-white",
        icon: w.jsx(Ad, { className: "w-4 h-4" }),
      },
      {
        name: "R",
        color: "bg-gradient-to-r from-blue-600 to-blue-700",
        textColor: "text-white",
        icon: w.jsx(Rd, { className: "w-4 h-4" }),
      },
      {
        name: "PANDAS",
        color: "bg-gradient-to-r from-purple-600 to-purple-700",
        textColor: "text-white",
        icon: w.jsx(Ml, { className: "w-4 h-4" }),
      },
      {
        name: "NUMPY",
        color: "bg-gradient-to-r from-blue-500 to-blue-600",
        textColor: "text-white",
        icon: w.jsx(Ad, { className: "w-4 h-4" }),
      },
      {
        name: "SEABORN",
        color: "bg-gradient-to-r from-gray-600 to-gray-700",
        textColor: "text-white",
        icon: w.jsx(rx, { className: "w-4 h-4" }),
      },
      {
        name: "MATPLOTLIB",
        color: "bg-gradient-to-r from-green-500 to-green-600",
        textColor: "text-white",
        icon: w.jsx(Rd, { className: "w-4 h-4" }),
      },
      {
        name: "POWER BI",
        color: "bg-gradient-to-r from-yellow-500 to-yellow-600",
        textColor: "text-black",
        icon: w.jsx(fx, { className: "w-4 h-4" }),
      },
      {
        name: "MYSQL",
        color: "bg-gradient-to-r from-orange-500 to-orange-600",
        textColor: "text-white",
        icon: w.jsx(Ml, { className: "w-4 h-4" }),
      },
      {
        name: "POSTGRESQL",
        color: "bg-gradient-to-r from-blue-700 to-blue-800",
        textColor: "text-white",
        icon: w.jsx(Ml, { className: "w-4 h-4" }),
      },
      {
        name: "ANACONDA",
        color: "bg-gradient-to-r from-green-500 to-green-600",
        textColor: "text-white",
        icon: w.jsx(sx, { className: "w-4 h-4" }),
      },
      {
        name: "HTML5",
        color: "bg-gradient-to-r from-orange-500 to-red-500",
        textColor: "text-white",
        icon: w.jsx(lx, { className: "w-4 h-4" }),
      },
      {
        name: "CSS3",
        color: "bg-gradient-to-r from-blue-500 to-blue-600",
        textColor: "text-white",
        icon: w.jsx(ix, { className: "w-4 h-4" }),
      },
    ];
    return w.jsx("section", {
      className: "py-20 px-4",
      children: w.jsxs("div", {
        className: "max-w-6xl mx-auto",
        children: [
          w.jsx("h2", {
            className:
              "text-4xl font-bold text-black dark:text-white text-center mb-12",
            children: "Skills",
          }),
          w.jsx("div", {
            className: "flex flex-wrap gap-2 justify-center items-center",
            children: e.map((t, n) =>
              w.jsxs(
                "div",
                {
                  className: `px-4 py-2 ${t.color} ${t.textColor} font-bold text-sm rounded-md shadow-sm hover:shadow-md transition-all duration-200 hover:scale-105 uppercase tracking-wide flex items-center gap-2`,
                  children: [t.icon, t.name],
                },
                n
              )
            ),
          }),
        ],
      }),
    });
  },
  Tk = () => {
    const e = [
      {
        title: "SudoResume",
        description:
          "AI-Powered Platform for ATS-Friendly and Optimized Resumes.",
        image: "🤖",
        tags: [
          "NextJS",
          "TypeScript",
          "Tailwind",
          "Prisma",
          "HTML",
          "Langchain",
        ],
        type: "Website",
      },
      {
        title: "AI Text Detection Model",
        description:
          "Fine-tuned RoBERTa based model for accurate detection of AI-generated text.",
        image: "🔍",
        tags: ["Python", "Machine Learning", "PyTorch", "Pandas", "Numpy"],
        type: "Model",
      },
      {
        title: "Ask The Web",
        description:
          "This search allows you search the entire page, chat with it ask questions to it.",
        image: "🌐",
        tags: [
          "NextJS",
          "Tailwind",
          "TypeScript",
          "NextUI",
          "HTML",
          "UpstashI",
        ],
        type: "Website",
      },
    ];
    return w.jsx("section", {
      className: "py-20 px-4",
      children: w.jsxs("div", {
        className: "max-w-6xl mx-auto",
        children: [
          w.jsx("h2", {
            className:
              "text-4xl font-bold text-gray-800 dark:text-white text-center mb-12",
            children: "Projects",
          }),
          w.jsx("div", {
            className: "grid md:grid-cols-2 lg:grid-cols-3 gap-8",
            children: e.map((t, n) =>
              w.jsxs(
                "div",
                {
                  className:
                    "bg-gradient-to-br from-amber-50 to-orange-100 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden hover:border-orange-300 dark:hover:border-gray-600 transition-colors shadow-lg hover:shadow-xl",
                  children: [
                    w.jsx("div", {
                      className:
                        "aspect-video bg-gradient-to-br from-orange-100 to-amber-100 dark:bg-gray-700 flex items-center justify-center text-6xl cursor-pointer hover:scale-105 transform transition-transform duration-300 hover:bg-gradient-to-br hover:from-orange-200 hover:to-amber-200 dark:hover:bg-gray-600",
                      children: t.image,
                    }),
                    w.jsxs("div", {
                      className: "p-6",
                      children: [
                        w.jsx("h3", {
                          className: "text-xl font-semibold text-black mb-2",
                          children: t.title,
                        }),
                        w.jsx("p", {
                          className:
                            "text-gray-600 dark:text-gray-400 mb-4 text-sm leading-relaxed",
                          children: t.description,
                        }),
                        w.jsx("div", {
                          className: "flex flex-wrap gap-2 mb-4",
                          children: t.tags.map((r, o) =>
                            w.jsx(
                              "span",
                              {
                                className:
                                  "px-2 py-1 bg-orange-100 dark:bg-gray-700 text-orange-700 dark:text-gray-300 rounded text-xs",
                                children: r,
                              },
                              o
                            )
                          ),
                        }),
                        w.jsxs("button", {
                          className:
                            "flex items-center gap-2 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-sm",
                          children: ["🌐 ", t.type],
                        }),
                      ],
                    }),
                  ],
                },
                n
              )
            ),
          }),
          w.jsx("div", {
            className: "text-center mt-12",
            children: w.jsxs(ag, {
              to: "/projects",
              className:
                "inline-flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-orange-600 dark:hover:text-white transition-colors cursor-pointer",
              children: [
                w.jsx("span", {
                  className: "text-lg",
                  children: "More Projects",
                }),
                w.jsx("span", { className: "text-xl", children: "→" }),
              ],
            }),
          }),
        ],
      }),
    });
  },
  Rk = () => {
    const [e, t] = y.useState({ name: "", email: "", message: "" }),
      n = async (o) => {
        o.preventDefault();
        const i = `Message from ${e.name} - Portfolio Contact`,
          s = `Name: ${e.name}
Email: ${e.email}

Message:
${e.message}`,
          l = `mailto:atulkumarprasad62@gmail.com?subject=${encodeURIComponent(
            i
          )}&body=${encodeURIComponent(s)}`;
        (window.location.href = l),
          fw.success("Opening your email client..."),
          t({ name: "", email: "", message: "" });
      },
      r = (o) => {
        t({ ...e, [o.target.name]: o.target.value });
      };
    return w.jsx("section", {
      className: "py-20 px-4",
      children: w.jsxs("div", {
        className: "max-w-4xl mx-auto",
        children: [
          w.jsx("h2", {
            className:
              "text-4xl font-bold text-black dark:text-white text-center mb-12",
            children: "Get In Touch",
          }),
          w.jsx("div", {
            className:
              "bg-gradient-to-br from-amber-50 to-orange-100 dark:bg-white rounded-lg border border-gray-200 dark:border-gray-700 p-8 shadow-lg",
            children: w.jsxs("form", {
              onSubmit: n,
              className: "space-y-6",
              children: [
                w.jsxs("div", {
                  className: "grid md:grid-cols-2 gap-6",
                  children: [
                    w.jsxs("div", {
                      children: [
                        w.jsx("label", {
                          htmlFor: "name",
                          className:
                            "block text-black dark:text-black font-bold mb-2",
                          children: "Name",
                        }),
                        w.jsx("input", {
                          type: "text",
                          id: "name",
                          name: "name",
                          value: e.name,
                          onChange: r,
                          required: !0,
                          className:
                            "w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:border-orange-500 dark:focus:border-blue-500 transition-colors",
                          placeholder: "Your name",
                        }),
                      ],
                    }),
                    w.jsxs("div", {
                      children: [
                        w.jsx("label", {
                          htmlFor: "email",
                          className:
                            "block text-black dark:text-black font-bold mb-2",
                          children: "Email",
                        }),
                        w.jsx("input", {
                          type: "email",
                          id: "email",
                          name: "email",
                          value: e.email,
                          onChange: r,
                          required: !0,
                          className:
                            "w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:border-orange-500 dark:focus:border-blue-500 transition-colors",
                          placeholder: "your@email.com",
                        }),
                      ],
                    }),
                  ],
                }),
                w.jsxs("div", {
                  children: [
                    w.jsx("label", {
                      htmlFor: "message",
                      className:
                        "block text-black dark:text-black font-bold mb-2",
                      children: "Message",
                    }),
                    w.jsx("textarea", {
                      id: "message",
                      name: "message",
                      value: e.message,
                      onChange: r,
                      required: !0,
                      rows: 6,
                      className:
                        "w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:border-orange-500 dark:focus:border-blue-500 transition-colors",
                      placeholder: "Your message...",
                    }),
                  ],
                }),
                w.jsx("button", {
                  type: "submit",
                  className:
                    "w-full px-8 py-4 bg-orange-600 hover:bg-orange-700 dark:bg-blue-600 dark:hover:bg-blue-700 text-white rounded-lg transition-colors font-medium",
                  children: "Send Message",
                }),
              ],
            }),
          }),
        ],
      }),
    });
  },
  Ak = () =>
    w.jsx("footer", {
      className: "py-12 px-4 border-t border-amber-200",
      children: w.jsxs("div", {
        className: "max-w-6xl mx-auto",
        children: [
          w.jsxs("div", {
            className: "flex flex-col md:flex-row justify-between items-center",
            children: [
              w.jsx("div", {
                className: "mb-6 md:mb-0",
                children: w.jsx("div", {
                  className: "text-6xl mb-4",
                  children: "🏎️",
                }),
              }),
              w.jsxs("div", {
                className: "flex gap-6",
                children: [
                  w.jsx("a", {
                    href: "https://www.linkedin.com/in/atul-kr-prasad-515835266",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className:
                      "text-amber-600 hover:text-amber-800 transition-colors",
                    children: w.jsx(im, { className: "w-6 h-6" }),
                  }),
                  w.jsx("a", {
                    href: "mailto:atulkumarprasad62@gmail.com",
                    className:
                      "text-amber-600 hover:text-amber-800 transition-colors",
                    children: w.jsx(sm, { className: "w-6 h-6" }),
                  }),
                  w.jsx("a", {
                    href: "https://github.com/KrAtulHub",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className:
                      "text-amber-600 hover:text-amber-800 transition-colors",
                    children: w.jsx(om, { className: "w-6 h-6" }),
                  }),
                ],
              }),
            ],
          }),
          w.jsx("div", {
            className:
              "text-center text-amber-700 mt-8 pt-8 border-t border-amber-200",
            children: w.jsx("p", {
              children: "© 2024 Atul Kr Prasad. All rights reserved.",
            }),
          }),
        ],
      }),
    }),
  Sg = ({ isDarkMode: e, toggleTheme: t }) =>
    w.jsx("button", {
      onClick: t,
      className:
        "fixed top-6 right-6 z-50 p-3 bg-gray-800 dark:bg-gray-700 border border-gray-700 dark:border-gray-600 rounded-lg text-white hover:bg-gray-700 dark:hover:bg-gray-600 transition-colors",
      "aria-label": "Toggle theme",
      children: e
        ? w.jsx(cx, { className: "w-5 h-5" })
        : w.jsx(ux, { className: "w-5 h-5" }),
    }),
  jk = ({ isDarkMode: e }) => {
    const n = ((r) =>
      Array.from({ length: r }, (o, i) => ({
        id: i,
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: Math.random() * 3 + 1,
        delay: Math.random() * 3,
        duration: Math.random() * 3 + 2,
      })))(50);
    return w.jsxs("div", {
      className: "absolute inset-0 overflow-hidden pointer-events-none",
      children: [
        n.map((r) =>
          w.jsx(
            "div",
            {
              className: `absolute rounded-full ${
                e ? "bg-white" : "bg-gray-400"
              } animate-twinkle opacity-60`,
              style: {
                left: `${r.left}%`,
                top: `${r.top}%`,
                width: `${r.size}px`,
                height: `${r.size}px`,
                animationDelay: `${r.delay}s`,
                animationDuration: `${r.duration}s`,
              },
            },
            r.id
          )
        ),
        w.jsx("div", {
          className: `absolute w-1 h-8 ${
            e ? "bg-blue-300" : "bg-blue-500"
          } rounded-full animate-falling-star opacity-80`,
          style: { top: "-50px", left: "30%", animationDelay: "2s" },
        }),
        w.jsx("div", {
          className: `absolute w-1 h-1 ${
            e ? "bg-purple-300" : "bg-purple-500"
          } rounded-full animate-shooting-star opacity-80`,
          style: { top: "60%", left: "-100px", animationDelay: "8s" },
        }),
        w.jsx("div", {
          className: `absolute w-1 h-1 ${
            e ? "bg-pink-300" : "bg-pink-500"
          } rounded-full animate-shooting-star opacity-80`,
          style: { top: "40%", left: "-100px", animationDelay: "14s" },
        }),
      ],
    });
  },
  _k = () => {
    const [e, t] = y.useState(!0);
    y.useEffect(() => {
      document.documentElement.classList.add("dark");
    }, []);
    const n = () => {
      t(!e), document.documentElement.classList.toggle("dark");
    };
    return w.jsxs("div", {
      className: `min-h-screen transition-colors duration-300 ${
        e ? "dark bg-gray-900" : "bg-white"
      }`,
      children: [
        w.jsx(Sg, { isDarkMode: e, toggleTheme: n }),
        w.jsxs("div", {
          className: "relative",
          children: [w.jsx(jk, { isDarkMode: e }), w.jsx(bk, {})],
        }),
        w.jsx(Pk, {}),
        w.jsx(Nk, {}),
        w.jsx(Tk, {}),
        w.jsx(Rk, {}),
        w.jsx(Ak, {}),
      ],
    });
  },
  Ok = () => {
    const [e, t] = y.useState(!0),
      n = () => {
        t(!e), document.documentElement.classList.toggle("dark");
      },
      r = [
        {
          title: "SudoResume",
          description:
            "AI-Powered Platform for ATS-Friendly and Optimized Resumes.",
          image: "🤖",
          tags: [
            "NextJS",
            "TypeScript",
            "Tailwind",
            "Prisma",
            "HTML",
            "Langchain",
          ],
          type: "Website",
        },
        {
          title: "AI Text Detection Model",
          description:
            "Fine-tuned RoBERTa based model for accurate detection of AI-generated text.",
          image: "🔍",
          tags: ["Python", "Machine Learning", "PyTorch", "Pandas", "Numpy"],
          type: "Model",
        },
        {
          title: "Ask The Web",
          description:
            "This search allows you search the entire page, chat with it ask questions to it.",
          image: "🌐",
          tags: [
            "NextJS",
            "Tailwind",
            "TypeScript",
            "NextUI",
            "HTML",
            "UpstashI",
          ],
          type: "Website",
        },
        {
          title: "Smart Code Assistant",
          description:
            "Intelligent code completion and bug detection tool powered by advanced AI algorithms.",
          image: "💻",
          tags: ["React", "TypeScript", "OpenAI", "Node.js", "Express"],
          type: "Tool",
        },
        {
          title: "Weather Analytics Dashboard",
          description:
            "Real-time weather data visualization with predictive analytics and climate insights.",
          image: "🌤️",
          tags: ["Vue.js", "D3.js", "Python", "FastAPI", "PostgreSQL"],
          type: "Dashboard",
        },
        {
          title: "E-commerce Optimizer",
          description:
            "Machine learning platform that optimizes product recommendations and pricing strategies.",
          image: "🛒",
          tags: ["React", "Python", "TensorFlow", "Redis", "Docker"],
          type: "Platform",
        },
      ];
    return w.jsxs("div", {
      className: `min-h-screen transition-colors duration-300 ${
        e ? "dark bg-gray-900" : "bg-white"
      }`,
      children: [
        w.jsx(Sg, { isDarkMode: e, toggleTheme: n }),
        w.jsx("section", {
          className: "py-20 px-4",
          children: w.jsxs("div", {
            className: "max-w-6xl mx-auto",
            children: [
              w.jsx("div", {
                className: "flex items-center gap-4 mb-8",
                children: w.jsxs(ag, {
                  to: "/",
                  className:
                    "flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-orange-600 dark:hover:text-white transition-colors",
                  children: [
                    w.jsx(nx, { className: "w-5 h-5" }),
                    w.jsx("span", { children: "Back to Home" }),
                  ],
                }),
              }),
              w.jsx("h1", {
                className:
                  "text-4xl font-bold text-gray-800 dark:text-white text-center mb-12",
                children: "All Projects",
              }),
              w.jsx("div", {
                className: "grid md:grid-cols-2 lg:grid-cols-3 gap-8",
                children: r.map((o, i) =>
                  w.jsxs(
                    "div",
                    {
                      className:
                        "bg-gradient-to-br from-amber-50 to-orange-100 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden hover:border-orange-300 dark:hover:border-gray-600 transition-colors shadow-lg hover:shadow-xl",
                      children: [
                        w.jsx("div", {
                          className:
                            "aspect-video bg-gradient-to-br from-orange-100 to-amber-100 dark:bg-gray-700 flex items-center justify-center text-6xl cursor-pointer hover:scale-105 transform transition-transform duration-300 hover:bg-gradient-to-br hover:from-orange-200 hover:to-amber-200 dark:hover:bg-gray-600",
                          children: o.image,
                        }),
                        w.jsxs("div", {
                          className: "p-6",
                          children: [
                            w.jsx("h3", {
                              className:
                                "text-xl font-semibold text-black mb-2",
                              children: o.title,
                            }),
                            w.jsx("p", {
                              className:
                                "text-gray-600 dark:text-gray-400 mb-4 text-sm leading-relaxed",
                              children: o.description,
                            }),
                            w.jsx("div", {
                              className: "flex flex-wrap gap-2 mb-4",
                              children: o.tags.map((s, l) =>
                                w.jsx(
                                  "span",
                                  {
                                    className:
                                      "px-2 py-1 bg-orange-100 dark:bg-gray-700 text-orange-700 dark:text-gray-300 rounded text-xs",
                                    children: s,
                                  },
                                  l
                                )
                              ),
                            }),
                            w.jsxs("button", {
                              className:
                                "flex items-center gap-2 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-sm",
                              children: ["🌐 ", o.type],
                            }),
                          ],
                        }),
                      ],
                    },
                    i
                  )
                ),
              }),
            ],
          }),
        }),
      ],
    });
  },
  Mk = () => {
    const e = ii();
    return (
      y.useEffect(() => {
        console.error(
          "404 Error: User attempted to access non-existent route:",
          e.pathname
        );
      }, [e.pathname]),
      w.jsx("div", {
        className: "min-h-screen flex items-center justify-center bg-gray-100",
        children: w.jsxs("div", {
          className: "text-center",
          children: [
            w.jsx("h1", {
              className: "text-4xl font-bold mb-4",
              children: "404",
            }),
            w.jsx("p", {
              className: "text-xl text-gray-600 mb-4",
              children: "Oops! Page not found",
            }),
            w.jsx("a", {
              href: "/",
              className: "text-blue-500 hover:text-blue-700 underline",
              children: "Return to Home",
            }),
          ],
        }),
      })
    );
  },
  Lk = new wS(),
  Ik = () =>
    w.jsx(kS, {
      client: Lk,
      children: w.jsxs(q1, {
        children: [
          w.jsx(Gx, {}),
          w.jsx(Cw, {}),
          w.jsx(yk, {
            children: w.jsxs(dk, {
              children: [
                w.jsx(Gi, { path: "/", element: w.jsx(_k, {}) }),
                w.jsx(Gi, { path: "/projects", element: w.jsx(Ok, {}) }),
                w.jsx(Gi, { path: "*", element: w.jsx(Mk, {}) }),
              ],
            }),
          }),
        ],
      }),
    });
Th(document.getElementById("root")).render(w.jsx(Ik, {}));
